r"""Problem 1 foundation: data dictionary, quality checks, and segment physics.

The script reads the supplied workbooks and the GeoTIFF without changing them.
It writes machine-readable CSV/JSON outputs that can be consumed by the later
Q1-Q4 optimizers.

Default source root:
    G:\数学建模大赛\中文题目\D

Example:
    python q1_foundation.py --out-dir outputs\q1_foundation
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from openpyxl import load_workbook
from PIL import Image
from pyproj import Geod


G = 9.80665
EARTH_RADIUS_M = 6_371_008.8
WGS84 = Geod(ellps="WGS84")


def clean(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    return value


def as_float(value: Any, field: str) -> float:
    if value is None or value == "":
        raise ValueError(f"missing numeric value: {field}")
    return float(value)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8-sig")
        return
    fields: list[str] = []
    for row in rows:
        for field in row:
            if field not in fields:
                fields.append(field)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_rows(path: Path, sheet_name: str, header_row: int = 1) -> list[dict[str, Any]]:
    wb = load_workbook(path, data_only=True, read_only=True)
    if sheet_name not in wb.sheetnames:
        raise KeyError(f"{path.name}: missing sheet {sheet_name}")
    ws = wb[sheet_name]
    headers = [clean(cell.value) for cell in ws[header_row]]
    rows: list[dict[str, Any]] = []
    for values in ws.iter_rows(min_row=header_row + 1, values_only=True):
        vals = [clean(value) for value in values]
        if not any(value not in (None, "") for value in vals):
            continue
        row = {str(headers[i]): vals[i] for i in range(min(len(headers), len(vals))) if headers[i] not in (None, "")}
        rows.append(row)
    return rows


@dataclass(frozen=True)
class Node:
    node_id: str
    name: str
    lon_deg: float
    lat_deg: float
    ground_m: float
    population: int | None
    kind: str

    @property
    def operation_height_m(self) -> float:
        return self.ground_m if self.kind == "origin" else self.ground_m + 30.0


@dataclass(frozen=True)
class TransportModel:
    model_id: str
    name: str
    empty_mass_kg: float
    max_payload_kg: float
    volume_m3: float
    cruise_speed_mps: float
    empty_range_m: float
    full_range_m: float
    battery_kwh: float
    return_soc_min: float
    prep_s: float
    load_box_s: float
    handover_base_s: float
    handover_box_s: float
    climb_speed_mps: float
    descend_speed_mps: float
    climb_efficiency: float
    descend_efficiency: float


@dataclass(frozen=True)
class RelayModel:
    model_id: str
    name: str
    empty_mass_kg: float
    communication_module_mass_kg: float
    takeoff_mass_kg: float
    cruise_speed_mps: float
    cruise_power_kw: float
    energy_kwh: float
    return_soc_min: float
    prep_s: float
    link_setup_s: float
    turnaround_s: float
    climb_speed_mps: float
    descend_speed_mps: float
    climb_efficiency: float
    descend_efficiency: float
    hover_power_kw: float
    communication_power_kw: float
    max_hover_agl_m: float


class DemGrid:
    """Small GeoTIFF reader sufficient for this scenario.

    The supplied DEM is PixelIsPoint, WGS84 (EPSG:4326). Pillow reads the
    numeric raster and GeoTIFF tags; no source file is modified.
    """

    def __init__(self, path: Path):
        self.path = path
        with Image.open(path) as image:
            self.array = np.asarray(image, dtype=np.float64)
            tags = image.tag_v2
            scale = list(tags.get(33550, ()))
            tie = list(tags.get(33922, ()))
            keys = list(tags.get(34735, ()))
        if len(scale) < 2 or len(tie) < 6:
            raise ValueError("DEM lacks ModelPixelScale/ModelTiepoint tags")
        self.pixel_lon = float(scale[0])
        self.pixel_lat = float(scale[1])
        self.tie_lon = float(tie[3])
        self.tie_lat = float(tie[4])
        self.width = int(self.array.shape[1])
        self.height = int(self.array.shape[0])
        keymap={keys[i]:keys[i+3] for i in range(4,len(keys),4) if keys[i+1]==0}
        self.crs_epsg = keymap.get(2048)
        self.pixel_is_point = keymap.get(1025)==2
        if self.crs_epsg!=4326 or not self.pixel_is_point:
            raise ValueError('Expected WGS84 PixelIsPoint GeoTIFF; inspect metadata before using another raster')

    def index(self, lon_deg: float, lat_deg: float) -> tuple[float, float]:
        col = (lon_deg - self.tie_lon) / self.pixel_lon
        row = (self.tie_lat - lat_deg) / self.pixel_lat
        return col, row

    def inside(self, lon_deg: float, lat_deg: float) -> bool:
        col, row = self.index(lon_deg, lat_deg)
        return 0.0 <= col <= self.width - 1 and 0.0 <= row <= self.height - 1

    def nearest(self, lon_deg: float, lat_deg: float) -> float:
        if not self.inside(lon_deg,lat_deg):raise ValueError('Point outside DEM')
        col, row = self.index(lon_deg, lat_deg)
        c = int(np.clip(round(col), 0, self.width - 1))
        r = int(np.clip(round(row), 0, self.height - 1))
        return float(self.array[r, c])

    def line_cells(self, a: Node, b: Node) -> np.ndarray:
        azimuth, _, distance = WGS84.inv(a.lon_deg, a.lat_deg, b.lon_deg, b.lat_deg)
        start=np.array(self.index(a.lon_deg, a.lat_deg)); end=np.array(self.index(b.lon_deg, b.lat_deg))
        probes=np.linspace(0.0, distance, 33)
        probe_lon, probe_lat, _ = WGS84.fwd(np.full(33,a.lon_deg), np.full(33,a.lat_deg), np.full(33,azimuth), probes)
        if not (np.all(np.diff(probe_lon)*np.sign(b.lon_deg-a.lon_deg)>=-1e-12) and np.all(np.diff(probe_lat)*np.sign(b.lat_deg-a.lat_deg)>=-1e-12)):
            raise ValueError('Unexpected non-monotone local geodesic')
        crossings=[0.0,distance]
        for axis in (0,1):
            low,high=sorted([start[axis],end[axis]])
            bounds=np.arange(math.ceil(low-.5),math.floor(high-.5)+1)+.5
            if not len(bounds):
                continue
            left=np.zeros(len(bounds)); right=np.full(len(bounds),distance); direction=np.sign(end[axis]-start[axis])
            for _ in range(48):
                mid=(left+right)/2
                lon,lat,_=WGS84.fwd(np.full(len(mid),a.lon_deg),np.full(len(mid),a.lat_deg),np.full(len(mid),azimuth),mid)
                value=(np.asarray(lon)-self.tie_lon)/self.pixel_lon if axis==0 else (self.tie_lat-np.asarray(lat))/self.pixel_lat
                left_side=(value-bounds)*direction<0
                left=np.where(left_side,mid,left); right=np.where(left_side,right,mid)
            crossings.extend(((left+right)/2).tolist())
        crossings=np.unique(crossings)
        positions=np.r_[crossings,(crossings[:-1]+crossings[1:])/2]
        lon,lat,_=WGS84.fwd(np.full(len(positions),a.lon_deg),np.full(len(positions),a.lat_deg),np.full(len(positions),azimuth),positions)
        col=(np.asarray(lon)-self.tie_lon)/self.pixel_lon; row=(self.tie_lat-np.asarray(lat))/self.pixel_lat; cells=set()
        for x,y in zip(col,row):
            for c in {math.floor(x+.5-1e-8),math.floor(x+.5+1e-8)}:
                for r in {math.floor(y+.5-1e-8),math.floor(y+.5+1e-8)}:
                    cells.add((c,r))
        result=np.array(sorted(cells),dtype=int)
        if (result[:,0]<0).any() or (result[:,0]>=self.width).any() or (result[:,1]<0).any() or (result[:,1]>=self.height).any():
            raise ValueError('Segment outside DEM; do not silently clamp')
        return result

    def line_cells_max(self, a: Node, b: Node) -> tuple[float, int]:
        cells=self.line_cells(a,b); heights=self.array[cells[:,1],cells[:,0]]
        if not np.isfinite(heights).all() or np.any(heights==-32767):
            raise ValueError('Segment encounters NoData; do not silently discard')
        return float(heights.max()),len(cells)


def horizontal_distance_m(a: Node, b: Node) -> float:
    _, _, distance = WGS84.inv(a.lon_deg, a.lat_deg, b.lon_deg, b.lat_deg)
    return float(distance)


def equivalent_range(model: TransportModel, payload_kg: float) -> float:
    if not math.isfinite(payload_kg) or payload_kg < 0 or payload_kg > model.max_payload_kg + 1e-9:
        raise ValueError(f"payload {payload_kg} outside {model.model_id} range")
    ratio = max(0.0, payload_kg / model.max_payload_kg)
    return model.empty_range_m - (model.empty_range_m - model.full_range_m) * ratio ** 1.5


def transport_segment_metrics(arc: dict[str, Any], model: TransportModel, payload_kg: float) -> dict[str, float | bool]:
    eq_range = equivalent_range(model, payload_kg)
    distance = float(arc["horizontal_distance_m"])
    climb = float(arc["climb_m"])
    descend = float(arc["descent_m"])
    total_mass = model.empty_mass_kg + payload_kg
    horizontal_s = distance / model.cruise_speed_mps
    climb_s = climb / model.climb_speed_mps
    descent_s = descend / model.descend_speed_mps
    horizontal_kwh = model.battery_kwh * distance / eq_range
    climb_kwh = total_mass * G * climb / (model.climb_efficiency * 3_600_000.0)
    descent_kwh = 0.0 if model.descend_efficiency == 0 else total_mass * G * descend / (model.descend_efficiency * 3_600_000.0)
    energy = horizontal_kwh + climb_kwh + descent_kwh
    usable = (1.0 - model.return_soc_min) * model.battery_kwh
    return {
        "equivalent_range_m": eq_range,
        "flight_time_s": horizontal_s + climb_s + descent_s,
        "horizontal_energy_kwh": horizontal_kwh,
        "climb_energy_kwh": climb_kwh,
        "descent_energy_kwh": descent_kwh,
        "energy_kwh": energy,
        "energy_limit_kwh": usable,
        "return_soc": 1.0 - energy / model.battery_kwh,
        "segment_energy_feasible": energy <= usable + 1e-9,
    }


def transport_route_metrics(
    arcs: list[dict[str, Any]],
    model: TransportModel,
    payload_by_arc_kg: list[float],
    box_count: int = 0,
    deliveries_per_stop: list[int] | None = None,
) -> dict[str, float | bool]:
    if len(arcs) != len(payload_by_arc_kg):
        raise ValueError("arcs and payload_by_arc_kg must have equal length")
    metrics = [transport_segment_metrics(arc, model, payload) for arc, payload in zip(arcs, payload_by_arc_kg)]
    energy = sum(float(item["energy_kwh"]) for item in metrics)
    flight_s = sum(float(item["flight_time_s"]) for item in metrics)
    if deliveries_per_stop is None or sum(deliveries_per_stop)!=box_count:
        raise ValueError('Supply deliveries_per_stop summing to box_count to include handover time')
    operation_s = model.prep_s + box_count * model.load_box_s + sum(model.handover_base_s+n*model.handover_box_s for n in deliveries_per_stop)
    return {
        "flight_time_s": flight_s,
        "operation_time_s": operation_s,
        "total_time_s": flight_s + operation_s,
        "energy_kwh": energy,
        "energy_limit_kwh": (1.0 - model.return_soc_min) * model.battery_kwh,
        "return_soc": 1.0 - energy / model.battery_kwh,
        "route_energy_feasible": energy <= (1.0 - model.return_soc_min) * model.battery_kwh + 1e-9,
    }


def charge_time_s(soc: float, full_charge_s: float) -> float:
    if not math.isfinite(soc) or not 0 <= soc <= 1 or full_charge_s<=0:
        raise ValueError('SOC must be within [0,1]; charging time must be positive')
    soc = float(soc)
    if soc < 0.90:
        return full_charge_s * (0.65 * (0.90 - soc) / 0.90 + 0.35)
    return full_charge_s * 0.35 * (1.0 - soc) / 0.10


def relay_sortie_metrics(
    arc: dict[str, Any],
    model: RelayModel,
    hover_agl_m: float,
    service_s: float,
) -> dict[str, float | bool]:
    if hover_agl_m < 0 or hover_agl_m > model.max_hover_agl_m:
        raise ValueError("relay hover AGL outside model limit")
    travel_alt_m = float(arc["max_dem_m"]) + 50.0
    hover_alt_m = float(arc['to_ground_m']) + hover_agl_m
    if hover_alt_m > travel_alt_m + 1e-8:
        raise ValueError('Hover altitude above specified cruise altitude; choose a different hover point/height')
    # Reuse the route geometry but replace endpoint operation heights with the
    # selected hover point's altitude. The caller supplies the O01->hover arc.
    climb = max(0.0, travel_alt_m - float(arc["start_operation_m"]))
    descent = max(0.0, travel_alt_m - hover_alt_m)
    distance = float(arc["horizontal_distance_m"])
    cruise_s = distance / model.cruise_speed_mps
    flight_s = 2*cruise_s + (climb+descent)/model.climb_speed_mps + (descent+climb)/model.descend_speed_mps
    climb_kwh = model.takeoff_mass_kg * G * (climb+descent) / (model.climb_efficiency * 3_600_000.0)
    cruise_kwh = 2.0 * model.cruise_power_kw * cruise_s / 3600.0
    service_kwh = (model.hover_power_kw + model.communication_power_kw) * (service_s+model.link_setup_s) / 3600.0
    energy = climb_kwh + cruise_kwh + service_kwh
    limit = (1.0 - model.return_soc_min) * model.energy_kwh
    return {
        "flight_time_s": flight_s,
        "service_time_s": service_s,
        "total_time_s": model.prep_s + model.link_setup_s + service_s + model.turnaround_s + flight_s,
        "energy_kwh": energy,
        "energy_limit_kwh": limit,
        "return_soc": 1.0 - energy / model.energy_kwh,
        "energy_feasible": energy <= limit + 1e-9,
    }


def parse_models(root: Path) -> tuple[list[TransportModel], list[RelayModel], list[dict[str, Any]], list[dict[str, Any]]]:
    transport_path = root / "数据" / "无人机应急物资运输基础数据" / "运输无人机数据.xlsx"
    relay_path = root / "数据" / "无人机应急物资运输基础数据" / "中继无人机数据.xlsx"
    raw_t = read_rows(transport_path, "数据", 2)
    transport = [
        TransportModel(
            model_id=str(row["机型编号"]), name=str(row["机型名称"]), empty_mass_kg=as_float(row["含电池空载总质量（kg）"], "empty_mass"),
            max_payload_kg=as_float(row["最大载货质量（kg）"], "max_payload"), volume_m3=as_float(row["可用装载体积（m³）"], "volume"),
            cruise_speed_mps=as_float(row["计划巡航速度（m/s）"], "cruise_speed"), empty_range_m=as_float(row["空载标准航程（m）"], "empty_range"),
            full_range_m=as_float(row["满载标准航程（m）"], "full_range"), battery_kwh=as_float(row["电池可用能量（kWh）"], "battery"),
            return_soc_min=as_float(row["返航电量下限（%）"], "return_soc") / 100.0, prep_s=as_float(row["工位固定准备时间（s）"], "prep"),
            load_box_s=as_float(row["每箱装载时间（s）"], "load_box"), handover_base_s=as_float(row["接收点基础交接时间（s）"], "handover_base"),
            handover_box_s=as_float(row["每箱增加交接时间（s）"], "handover_box"), climb_speed_mps=as_float(row["最大爬升速度（m/s）"], "climb_speed"),
            descend_speed_mps=as_float(row["最大下降速度（m/s）"], "descend_speed"), climb_efficiency=as_float(row["爬升能耗效率"], "climb_eff"),
            descend_efficiency=as_float(row["下降能耗效率"], "descend_eff"),
        )
        for row in raw_t if row.get("机型编号") in {"A", "B", "C"} and isinstance(row.get("最大载货质量（kg）"), (int, float))
    ]
    raw_r = read_rows(relay_path, "数据", 2)
    relay = [
        RelayModel(
            model_id=str(row["机型编号"]), name=str(row["机型名称"]), empty_mass_kg=as_float(row["含能源组件空载总质量（kg）"], "relay_empty"),
            communication_module_mass_kg=as_float(row["中继通信模块质量（kg）"], "relay_module"), takeoff_mass_kg=as_float(row["计划起飞总质量（kg）"], "relay_takeoff"),
            cruise_speed_mps=as_float(row["计划巡航速度（m/s）"], "relay_speed"), cruise_power_kw=as_float(row["巡航功率（kW）"], "relay_cruise_power"),
            energy_kwh=as_float(row["能源组件可用能量（kWh）"], "relay_energy"), return_soc_min=as_float(row["返航电量下限（%）"], "relay_soc") / 100.0,
            prep_s=as_float(row["工位固定准备时间（s）"], "relay_prep"), link_setup_s=as_float(row["建链时间（s）"], "relay_link"),
            turnaround_s=as_float(row["架次周转时间（s）"], "relay_turnaround"), climb_speed_mps=as_float(row["最大爬升速度（m/s）"], "relay_climb_speed"),
            descend_speed_mps=as_float(row["最大下降速度（m/s）"], "relay_descend_speed"), climb_efficiency=as_float(row["爬升能耗效率"], "relay_climb_eff"),
            descend_efficiency=as_float(row["下降能耗效率"], "relay_descend_eff"), hover_power_kw=as_float(row["悬停功率（kW）"], "relay_hover"),
            communication_power_kw=as_float(row["通信附加功率（kW）"], "relay_comm"), max_hover_agl_m=as_float(row["最大悬停离地高度（m）"], "relay_hover_max"),
        )
        for row in raw_r if row.get("机型编号") == "R" and isinstance(row.get("能源组件可用能量（kWh）"), (int, float))
    ]
    drone_rows = [r for r in read_rows(transport_path, "数据", 8) if str(r.get('无人机编号','')).startswith('U') and r.get('初始位置')=='O01']
    battery_rows = read_rows(transport_path, "数据", 19)
    relay_drone_rows = [r for r in read_rows(relay_path, "数据", 6) if r.get('中继无人机编号') in {'R01','R02'} and r.get('初始位置')=='O01']
    relay_energy_rows = read_rows(relay_path, "数据", 11)
    return transport, relay, drone_rows + relay_drone_rows, battery_rows + relay_energy_rows


def parse_nodes(root: Path) -> list[Node]:
    path = root / "数据" / "无人机应急物资运输基础数据" / "调度中心与服务区.xlsx"
    rows = read_rows(path, "数据", 2)
    origin_rows = [row for row in rows if row.get("调度中心编号") == "O01" and isinstance(row.get("经度（°）"), (int, float))]
    nodes = [Node(str(row["调度中心编号"]), str(row["调度中心名称"]), as_float(row["经度（°）"], "origin_lon"), as_float(row["纬度（°）"], "origin_lat"), as_float(row["海拔（m）"], "origin_ground"), None, "origin") for row in origin_rows]
    service_rows = [row for row in read_rows(path, "数据", 6) if row.get("服务区编号") and isinstance(row.get("经度（°）"), (int, float))]
    nodes += [Node(str(row["服务区编号"]), str(row["服务区名称"]), as_float(row["经度（°）"], "service_lon"), as_float(row["纬度（°）"], "service_lat"), as_float(row["海拔（m）"], "service_ground"), int(row["本次需保障人口（人）"]), "service") for row in service_rows]
    return nodes


def parse_boxes(root: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    path = root / "数据" / "无人机应急物资运输基础数据" / "物资需求与配送时限.xlsx"
    summary = read_rows(path, "数据", 1)
    boxes = read_rows(path, "逐箱货箱清单", 1)
    return summary, boxes


def parse_communication(root: Path) -> list[dict[str, Any]]:
    path = root / "数据" / "无人机应急物资运输基础数据" / "通信链路参数.xlsx"
    return read_rows(path, "数据", 2)


def make_arcs(nodes: list[Node], dem: DemGrid) -> list[dict[str, Any]]:
    arcs: list[dict[str, Any]] = []
    for a in nodes:
        for b in nodes:
            if a.node_id == b.node_id:
                continue
            max_dem, cells = dem.line_cells_max(a, b)
            cruise = max_dem + 50.0
            if cruise < max(a.operation_height_m,b.operation_height_m):
                raise ValueError('Specified cruise altitude below an endpoint; resolve geometry explicitly')
            arcs.append({
                "from_node": a.node_id, "to_node": b.node_id,
                "horizontal_distance_m": horizontal_distance_m(a, b),
                "max_dem_m": max_dem, "dem_cells": cells,
                "from_ground_m": a.ground_m, "to_ground_m": b.ground_m,
                "start_operation_m": a.operation_height_m, "end_operation_m": b.operation_height_m,
                "cruise_altitude_m": cruise,
                "climb_m": cruise - a.operation_height_m,
                "descent_m": cruise - b.operation_height_m,
                "min_cruise_clearance_m": cruise - max_dem,
            })
    return arcs


def quality_checks(root: Path, nodes: list[Node], boxes: list[dict[str, Any]], summary: list[dict[str, Any]], transport: list[TransportModel], relay: list[RelayModel], dem: DemGrid, comm: list[dict[str, Any]]) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    def add(check_id: str, category: str, status: str, observed: Any, rule: str, detail: str = ""):
        checks.append({"check_id": check_id, "category": category, "status": status, "observed": observed, "rule": rule, "detail": detail})

    expected = [
        root / "数据" / "无人机应急物资运输基础数据" / "调度中心与服务区.xlsx",
        root / "数据" / "无人机应急物资运输基础数据" / "物资需求与配送时限.xlsx",
        root / "数据" / "无人机应急物资运输基础数据" / "运输无人机数据.xlsx",
        root / "数据" / "无人机应急物资运输基础数据" / "中继无人机数据.xlsx",
        root / "数据" / "无人机应急物资运输基础数据" / "通信链路参数.xlsx",
        root / "数据" / "镇龙乡地理空间数据" / "镇龙乡及周边地理数据" / "数字高程模型数据（DEM）" / "镇龙乡及周边30米DEM.tif",
        root / "结果提交模板.xlsx",
    ]
    add("FILES", "file", "PASS" if all(p.exists() for p in expected) else "FAIL", sum(p.exists() for p in expected), "all required source files exist", "; ".join(str(p) for p in expected if not p.exists()))
    node_ids = [node.node_id for node in nodes]
    add("NODE_COUNT", "nodes", "PASS" if len(nodes) == 16 else "FAIL", len(nodes), "1 origin + 15 service zones")
    add("NODE_UNIQUE", "nodes", "PASS" if len(node_ids) == len(set(node_ids)) else "FAIL", len(node_ids) - len(set(node_ids)), "no duplicate node IDs")
    add("NODE_DEM", "nodes", "PASS" if all(dem.inside(node.lon_deg, node.lat_deg) for node in nodes) else "FAIL", sum(dem.inside(node.lon_deg, node.lat_deg) for node in nodes), "all nodes within DEM raster")
    box_ids = [str(row.get("货箱编号")) for row in boxes]
    add("BOX_COUNT", "boxes", "PASS" if len(boxes) == 80 else "FAIL", len(boxes), "80 indivisible boxes")
    add("BOX_UNIQUE", "boxes", "PASS" if len(box_ids) == len(set(box_ids)) else "FAIL", len(box_ids) - len(set(box_ids)), "no duplicate box IDs")
    node_set = set(node_ids[1:])
    bad_services = sorted({row.get("服务区编号") for row in boxes} - node_set)
    add("BOX_SERVICE_REF", "boxes", "PASS" if not bad_services else "FAIL", bad_services or "none", "every box service zone exists")
    invalid_box = [row.get("货箱编号") for row in boxes if as_float(row.get("单箱质量（kg）"), "box_mass") <= 0 or as_float(row.get("单箱体积（m³）"), "box_volume") <= 0]
    add("BOX_POSITIVE", "boxes", "PASS" if not invalid_box else "FAIL", len(invalid_box), "mass and volume are positive")
    first_batch = sum(row.get("是否首批保障") == "是" for row in boxes)
    add("BOX_FIRST_BATCH", "boxes", "PASS" if first_batch == 30 else "FAIL", first_batch, "first-batch box count is 30")
    by_service: dict[str, dict[str, float]] = {}
    for row in boxes:
        item = by_service.setdefault(str(row["服务区编号"]), {"count": 0, "mass": 0.0, "volume": 0.0, "first": 0})
        item["count"] += 1
        item["mass"] += as_float(row["单箱质量（kg）"], "box_mass")
        item["volume"] += as_float(row["单箱体积（m³）"], "box_volume")
        item["first"] += int(row.get("是否首批保障") == "是")
    summary_map: dict[str, dict[str, int]] = {}
    for row in summary:
        item = summary_map.setdefault(str(row["服务区编号"]), {"count": 0, "first": 0})
        item["count"] += int(row["总需求箱数"])
        item["first"] += int(row["首批必须送达箱数"])
    summary_mismatch = []
    for service, item in by_service.items():
        s = summary_map.get(service)
        if s is None or s["count"] != item["count"] or s["first"] != item["first"]:
            summary_mismatch.append(service)
    add("BOX_SUMMARY_RECON", "boxes", "PASS" if not summary_mismatch else "FAIL", summary_mismatch or "all services", "summary demand reconciles to itemized boxes")
    add("TRANSPORT_MODELS", "fleet", "PASS" if len(transport) == 3 else "FAIL", len(transport), "A, B, C transport models")
    add("RELAY_MODELS", "fleet", "PASS" if len(relay) == 1 else "FAIL", len(relay), "one relay model R")
    add("DEM_WGS84", "dem", "PASS" if dem.crs_epsg == 4326 and dem.pixel_is_point else "WARN", {"epsg": dem.crs_epsg, "pixel_is_point": dem.pixel_is_point}, "DEM uses WGS84 PixelIsPoint")
    add("DEM_FINITE", "dem", "PASS" if np.isfinite(dem.array).all() else "WARN", int(np.isfinite(dem.array).sum()), "DEM pixels are finite")
    bad_transport = [model.model_id for model in transport if model.max_payload_kg <= 0 or model.battery_kwh <= 0 or model.empty_range_m <= model.full_range_m or not (0 <= model.return_soc_min < 1)]
    add("TRANSPORT_PARAMS", "fleet", "PASS" if not bad_transport else "FAIL", bad_transport or "all valid", "transport parameter ranges are valid")
    bad_relay = [model.model_id for model in relay if model.energy_kwh <= 0 or not (0 <= model.return_soc_min < 1) or model.max_hover_agl_m <= 0]
    add("RELAY_PARAMS", "fleet", "PASS" if not bad_relay else "FAIL", bad_relay or "all valid", "relay parameter ranges are valid")
    add("COMM_PARAMS", "communication", "PASS" if len(comm) >= 14 else "WARN", len(comm), "communication parameter table is populated")
    add("GEO_DESCRIPTION", "geodata", "WARN", "PDF supplied", "description file is referenced as DOCX in the task text", "The actual supplied description is 镇龙乡地理空间数据说明.pdf; no calculation impact.")
    return checks


def data_dictionary() -> list[dict[str, Any]]:
    rows = [
        ("nodes", "node_id", "string", "none", "unique identifier for O01 or S001-S015", "调度中心与服务区.xlsx / 数据", "required"),
        ("nodes", "lon_deg", "float", "degree", "WGS84 longitude", "调度中心与服务区.xlsx / 数据", "required"),
        ("nodes", "lat_deg", "float", "degree", "WGS84 latitude", "调度中心与服务区.xlsx / 数据", "required"),
        ("nodes", "ground_m", "float", "m", "given ground elevation used for operation height", "调度中心与服务区.xlsx / 数据", "required"),
        ("nodes", "operation_height_m", "derived float", "m", "O01 ground elevation; service ground elevation + 30", "task Appendix 2", "derived"),
        ("boxes", "box_id", "string", "none", "indivisible cargo box ID", "物资需求与配送时限.xlsx / 逐箱货箱清单", "required"),
        ("boxes", "service_id", "string", "none", "delivery service zone", "物资需求与配送时限.xlsx / 逐箱货箱清单", "required"),
        ("boxes", "mass_kg", "float", "kg", "single-box mass", "物资需求与配送时限.xlsx / 逐箱货箱清单", "required"),
        ("boxes", "volume_m3", "float", "m3", "single-box volume", "物资需求与配送时限.xlsx / 逐箱货箱清单", "required"),
        ("boxes", "first_batch", "boolean", "none", "whether box is first-batch protected", "物资需求与配送时限.xlsx / 逐箱货箱清单", "required"),
        ("boxes", "deadline_s", "float", "s", "first-batch deadline if present", "物资需求与配送时限.xlsx / 逐箱货箱清单", "required when first_batch"),
        ("boxes", "desired_delivery_s", "float", "s", "desired delivery time", "物资需求与配送时限.xlsx / 逐箱货箱清单", "required"),
        ("boxes", "priority", "float", "none", "emergency priority coefficient", "物资需求与配送时限.xlsx / 逐箱货箱清单", "required"),
        ("transport_models", "max_payload_kg", "float", "kg", "maximum cargo mass", "运输无人机数据.xlsx / 数据", "required"),
        ("transport_models", "volume_m3", "float", "m3", "usable loading volume", "运输无人机数据.xlsx / 数据", "required"),
        ("transport_models", "empty_range_m", "float", "m", "empty standard range", "运输无人机数据.xlsx / 数据", "required"),
        ("transport_models", "full_range_m", "float", "m", "full-load standard range", "运输无人机数据.xlsx / 数据", "required"),
        ("transport_models", "battery_kwh", "float", "kWh", "available energy per battery", "运输无人机数据.xlsx / 数据", "required"),
        ("transport_models", "return_soc_min", "float", "fraction", "minimum return SOC", "运输无人机数据.xlsx / 数据", "required"),
        ("arcs", "horizontal_distance_m", "float", "m", "great-circle horizontal distance between node centers", "derived", "derived"),
        ("arcs", "max_dem_m", "float", "m", "maximum DEM elevation along straight raster path", "DEM GeoTIFF", "derived"),
        ("arcs", "cruise_altitude_m", "float", "m", "max_dem_m + 50", "task Appendix 2", "derived"),
        ("arcs", "climb_m", "float", "m", "cruise altitude minus start operation height", "task Appendix 2", "derived"),
        ("arcs", "descent_m", "float", "m", "cruise altitude minus end operation height", "task Appendix 2", "derived"),
        ("transport_physics", "equivalent_range_m", "float", "m", "load-dependent equivalent range", "task Appendix 2", "derived"),
        ("transport_physics", "flight_time_s", "float", "s", "climb + cruise + descent flight time", "task Appendix 2", "derived"),
        ("transport_physics", "energy_kwh", "float", "kWh", "horizontal + climb + descent energy", "task Appendix 2", "derived"),
        ("transport_physics", "return_soc", "float", "fraction", "1 - energy / battery energy", "task Appendix 2", "derived"),
    ]
    return [
        {"object": a, "field": b, "data_type": c, "unit": d, "definition": e, "source_or_rule": f, "status": g}
        for a, b, c, d, e, f, g in rows
    ]


def build_outputs(root: Path, out_dir: Path) -> dict[str, Any]:
    nodes = parse_nodes(root)
    summary, boxes = parse_boxes(root)
    transport, relay, fleet_rows, energy_rows = parse_models(root)
    comm = parse_communication(root)
    dem_path = root / "数据" / "镇龙乡地理空间数据" / "镇龙乡及周边地理数据" / "数字高程模型数据（DEM）" / "镇龙乡及周边30米DEM.tif"
    dem = DemGrid(dem_path)
    arcs = make_arcs(nodes, dem)
    checks = quality_checks(root, nodes, boxes, summary, transport, relay, dem, comm)

    node_rows = []
    for node in nodes:
        node_rows.append({**asdict(node), "operation_height_m": node.operation_height_m, "dem_nearest_m": dem.nearest(node.lon_deg, node.lat_deg), "dem_difference_m": dem.nearest(node.lon_deg, node.lat_deg) - node.ground_m, "inside_dem": dem.inside(node.lon_deg, node.lat_deg)})
    box_rows = []
    for row in boxes:
        box_rows.append({
            "box_id": row["货箱编号"], "service_id": row["服务区编号"], "material_type": row["物资类型"], "mass_kg": float(row["单箱质量（kg）"]), "volume_m3": float(row["单箱体积（m³）"]), "first_batch": row.get("是否首批保障") == "是", "deadline_s": row.get("首批截止时间（s）"), "desired_delivery_s": float(row["期望送达时间（s）"]), "priority": float(row["应急优先系数"]),
        })
    transport_rows = [asdict(model) for model in transport]
    relay_rows = [asdict(model) for model in relay]
    physics_rows = []
    for arc in arcs:
        for model in transport:
            for payload in (0.0, model.max_payload_kg / 2.0, model.max_payload_kg):
                physics_rows.append({**arc, "model_id": model.model_id, "payload_kg": payload, **transport_segment_metrics(arc, model, payload)})

    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(out_dir / "data_dictionary.csv", data_dictionary())
    write_csv(out_dir / "quality_checks.csv", checks)
    write_csv(out_dir / "nodes_clean.csv", node_rows)
    write_csv(out_dir / "boxes_clean.csv", box_rows)
    write_csv(out_dir / "transport_models.csv", transport_rows)
    write_csv(out_dir / "relay_models.csv", relay_rows)
    write_csv(out_dir / "arc_geometry.csv", arcs)
    write_csv(out_dir / "arc_physics_reference.csv", physics_rows)
    write_csv(out_dir / "fleet_inventory_raw.csv", fleet_rows)
    write_csv(out_dir / "energy_inventory_raw.csv", energy_rows)
    write_csv(out_dir / "communication_parameters_raw.csv", comm)
    metadata = {
        "source_root": str(root), "node_count": len(nodes), "box_count": len(boxes), "arc_count": len(arcs), "physics_reference_rows": len(physics_rows), "dem": {"path": str(dem_path), "width": dem.width, "height": dem.height, "crs_epsg": dem.crs_epsg, "pixel_is_point": dem.pixel_is_point, "min_m": float(np.nanmin(dem.array)), "max_m": float(np.nanmax(dem.array))},
        "model_assumptions": [
            "Horizontal energy = battery_kwh * horizontal_distance / load-dependent equivalent range.",
            "Climb energy = total_mass * g * climb_height / (climb_efficiency * 3,600,000), kWh.",
            "Descent energy is zero when the supplied descent efficiency equals zero.",
            "Cruise altitude = max DEM elevation of every crossed/touched pixel + 50 m; reject routes whose endpoints exceed it.",
            "Horizontal and climb energy component formulas are explicit modeling completions; the task specifies their sum but does not expand both components.",
            "A reference table uses payloads 0, 50% of model maximum, and model maximum; the engine accepts continuous payloads.",
        ],
    }
    (out_dir / "foundation_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return metadata


def self_test(root: Path) -> None:
    nodes = parse_nodes(root)
    transport, relay, _, _ = parse_models(root)
    dem = DemGrid(root / "数据" / "镇龙乡地理空间数据" / "镇龙乡及周边地理数据" / "数字高程模型数据（DEM）" / "镇龙乡及周边30米DEM.tif")
    arcs = make_arcs(nodes, dem)
    assert len(nodes) == 16
    assert len(arcs) == 16 * 15
    arc_by_pair = {(r["from_node"], r["to_node"]): r for r in arcs}
    for a in nodes:
        for b in nodes:
            if a.node_id == b.node_id:
                continue
            assert abs(arc_by_pair[(a.node_id, b.node_id)]["horizontal_distance_m"] - arc_by_pair[(b.node_id, a.node_id)]["horizontal_distance_m"]) < 1e-6
    for model in transport:
        ranges = [equivalent_range(model, q) for q in (0.0, model.max_payload_kg / 2, model.max_payload_kg)]
        assert ranges[0] >= ranges[1] >= ranges[2] > 0
        metric0 = transport_segment_metrics(arc_by_pair["O01", "S001"], model, 0.0)
        metric1 = transport_segment_metrics(arc_by_pair["O01", "S001"], model, model.max_payload_kg)
        assert metric1["energy_kwh"] >= metric0["energy_kwh"]
    assert relay and charge_time_s(1.0, 1800) == 0.0


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(r"G:\数学建模大赛\中文题目\D"))
    parser.add_argument("--out-dir", type=Path, default=Path(r"G:\数学建模大赛\D题\01_数据与物理底座"))
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test(args.root)
        print("SELF_TEST_PASS")
    metadata = build_outputs(args.root, args.out_dir)
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
