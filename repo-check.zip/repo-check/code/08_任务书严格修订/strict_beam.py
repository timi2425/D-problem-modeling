from strict_q3_v2 import *
import copy

def beam_schedule(w,variants,bases,sites,order,width=12,gap=1000):
    names={'A':['U01','U02','U03','U04'],'B':['U05','U06'],'C':['U07','U08']};full={'A':1800,'B':2400,'C':3000}
    beam=[dict(dr={g:[0.]*len(ns) for g,ns in names.items()},bt={g:[0.]*n for g,n in [('A',6),('B',4),('C',4)]},ts=[],rs=[])]
    for step,ix in enumerate(order):
        successors=[]
        for state in beam:
            for v in variants[ix]:
                g=v['model'];di=min(range(len(state['dr'][g])),key=lambda i:state['dr'][g][i]);bi=min(range(len(state['bt'][g])),key=lambda i:state['bt'][g][i])
                earliest=max(state['dr'][g][di],state['bt'][g][bi],max([0.]+[sites[c['site']]['lead']-c['start'] for c in v['certificates'] if c['site']>=0]));latest=min((hard_deadline(w.boxes[x])-t for x,t in v['deliveries'].items()),default=math.inf)
                for t in np.arange(math.ceil(earliest/20)*20,min(latest,40000)+.01,40):
                    tr=dict(v,start=float(t),end=float(t)+v['duration'],drone=names[g][di],battery=f'{g}-BAT-{bi+1:02d}',base_index=ix)
                    rr=relay_schedule(w,state['ts']+[tr],sites,gap)
                    if rr is None:continue
                    new=dict(dr={g:list(x) for g,x in state['dr'].items()},bt={g:list(x) for g,x in state['bt'].items()},ts=state['ts']+[tr],rs=rr)
                    new['dr'][g][di]=tr['end'];new['bt'][g][bi]=tr['end']+f.charge_time_s(tr['soc'],full[g])
                    late=sum(w.boxes[x]['应急优先系数']*max(0,u['start']+off-w.boxes[x]['期望送达时间（s）']) for u in new['ts'] for x,off in u['deliveries'].items() if w.boxes[x]['物资类型']!='医疗物资')
                    finish=max([x['end'] for x in new['ts']]+[r['end'] for r in rr]);score=late/10000+finish/100+sum(r['energy'] for r in rr)*4+len(rr)*12+sum(u['energy'] for u in new['ts'])*2
                    successors.append((score,new));break
        if not successors:print('beam fail step',step,'route',ix,flush=True);return None
        successors.sort(key=lambda x:x[0]);beam=[];signatures=set()
        for score,state in successors:
            signature=tuple((r['site'],round(r['service_start']),round(r['service_end'])) for r in state['rs'])+tuple((g,tuple(round(t) for t in state['dr'][g])) for g in 'ABC')
            if signature in signatures:continue
            signatures.add(signature);beam.append(state)
            if len(beam)>=width:break
        print('beam step',step,'states',len(beam),'best',successors[0][0],flush=True)
    result=[]
    for state in beam:
        ts=state['ts'];rs=state['rs'];late=sum(w.boxes[x]['应急优先系数']*max(0,u['start']+off-w.boxes[x]['期望送达时间（s）']) for u in ts for x,off in u['deliveries'].items() if w.boxes[x]['物资类型']!='医疗物资');finish=max([x['end'] for x in ts]+[r['end'] for r in rs]);te=sum(t['energy'] for t in ts);re=sum(r['energy'] for r in rs);den=sum(b['应急优先系数']*b['期望送达时间（s）'] for b in w.boxes.values() if b['物资类型']!='医疗物资');score=.5*late/den+.2*finish/14400+.2*(te+re)/70+.1*(len(ts)+len(rs))/25
        result.append(dict(transports=ts,relays=rs,sites=sites,weighted_late=late,makespan=finish,transport_energy=te,relay_energy=re,score=score,gap=gap))
    return min(result,key=lambda a:a['score'])
def main():
    w=World();data=json.loads((OUT/'work'/'strict_variants.json').read_text(encoding='utf8'));v=data['variants'];b=data['bases'];ss=data['sites'];rng=random.Random(927);best=None
    for k in range(8):
        order=sorted(range(len(b)),key=lambda i:(min(hard_deadline(w.boxes[x]) for x in b[i]['boxes']),min(w.boxes[x]['期望送达时间（s）'] for x in b[i]['boxes'])*rng.uniform(.5,1.5)))
        ans=beam_schedule(w,v,b,ss,order,width=16,gap=[500,1000,2000,300][k%4])
        if ans and (best is None or ans['score']<best['score']):best=ans;(OUT/'work'/'strict_best.json').write_text(json.dumps(best,ensure_ascii=False,indent=2),encoding='utf8');print('BEAM BEST',best['score'],len(best['relays']),flush=True)
    assert best
if __name__=='__main__':main()
