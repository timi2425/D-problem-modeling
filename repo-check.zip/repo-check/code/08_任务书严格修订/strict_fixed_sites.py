from strict_beam import *
def main():
    w=World();all_data=json.loads((OUT/'work'/'strict_variants.json').read_text(encoding='utf8'));bases=all_data['bases'];pair=json.loads((BASE/'08_任务书严格修订'/'early_pair.json').read_text(encoding='utf8'))['pairs'][0]['sites'];coarse=json.loads((BASE/'08_任务书严格修订'/'strict_sites.json').read_text(encoding='utf8'))['selected'];sites=[relay_physics(w,s) for s in pair+coarse];vss=[]
    for v in bases:
        variants=[]
        for g in w.mod:
            for perm in itertools.permutations(v['stops']):
                ev=w.evaluate(v['boxes'],perm,g)
                if not ev:continue
                for subset in list(itertools.combinations(range(len(sites)),1))+[(0,1)]+list(itertools.combinations(range(len(sites)),2)):
                    try:
                        cs=certificates(w,ev,[sites[j] for j in subset]);
                        for c in cs:
                            if c['site']>=0:c['site']=subset[c['site']]
                        variants.append(dict(ev,certificates=cs))
                    except ValueError:pass
        vss.append(variants)
    (OUT/'work'/'fixed_variants.json').write_text(json.dumps(dict(bases=bases,variants=vss,sites=sites),ensure_ascii=False),encoding='utf8')
    run(w,bases,vss,sites)
def run(w,bases,vss,sites):
    rng=random.Random(9991);best=None
    for k in range(20):
        order=sorted(range(len(bases)),key=lambda i:(min(hard_deadline(w.boxes[x]) for x in bases[i]['boxes']), 0 if bases[i]['stops']==['S007'] else 2 if bases[i]['stops']==['S002'] else 1,rng.random()))
        ans=beam_schedule(w,vss,bases,sites,order,width=10,gap=[1000,2000,500][k%3])
        if ans and (best is None or ans['score']<best['score']):best=ans;(OUT/'work'/'strict_best.json').write_text(json.dumps(best,ensure_ascii=False,indent=2),encoding='utf8');print('FOUND',best['score'],flush=True)
    assert best
if __name__=='__main__':main()
