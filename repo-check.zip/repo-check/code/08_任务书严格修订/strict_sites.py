from pathlib import Path
import sys,json
BASE=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(BASE/'04_问题三'))
from q3_joint import *
def main():
    w=World();routes=q2_routes(w);points=samples(routes,10);direct=w.sample_margin(w.gateway,points,'direct');need=points[direct<.05];print('need',len(need),flush=True)
    sites=[];coverage=[]
    for lon in np.arange(109.165,109.3001,.004):
        for lat in np.arange(23.000,23.0901,.004):
            ground=w.dem.nearest(lon,lat);p=np.array([lon,lat,ground]);H=w.terrain_max(w.o,p)+50;alt=min(ground+300,H)
            if alt<ground+15:continue
            p[2]=alt
            if w.sample_margin(w.gateway,p[None,:],'backhaul')[0]<.05:continue
            m=w.sample_margin(p,need,'access');count=int((m>=.05).sum())
            if count:sites.append(dict(lon=float(lon),lat=float(lat),altitude=alt,ground=ground,agl=alt-ground));coverage.append(m)
    # Include service-local candidates to repair discrete search blindspots.
    for n in w.nodes[1:]:
        for dx in [0,-.001,.001]:
            for dy in [0,-.001,.001]:
                lon=n.lon_deg+dx;lat=n.lat_deg+dy;g=w.dem.nearest(lon,lat);p=np.array([lon,lat,g]);H=w.terrain_max(w.o,p)+50;p[2]=min(g+300,H)
                if w.sample_margin(w.gateway,p[None,:],'backhaul')[0]<.05:continue
                sites.append(dict(lon=lon,lat=lat,altitude=float(p[2]),ground=g,agl=float(p[2]-g)));coverage.append(w.sample_margin(p,need,'access'))
    mat=np.array(coverage);uncovered=np.ones(len(need),bool);selected=[]
    while uncovered.any():
        counts=((mat>=.05)&uncovered).sum(axis=1);i=int(counts.argmax())
        if counts[i]==0:break
        selected.append(sites[i]);uncovered &= mat[i]<.05
    print('sites',len(sites),'selected',len(selected),'uncovered',uncovered.sum(),flush=True)
    (BASE/'08_任务书严格修订'/'strict_sites.json').write_text(json.dumps(dict(selected=selected,all=sites,uncovered=need[uncovered].tolist()),ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
