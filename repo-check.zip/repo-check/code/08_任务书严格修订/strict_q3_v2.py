from strict_sites import *
import random,itertools,time

def main():
    w=World();data=json.loads((BASE/'08_任务书严格修订'/'strict_sites.json').read_text(encoding='utf8'));sites=[relay_physics(w,s) for s in data['all']];sites=[s for s in sites if s['backhaul']>.02]
    bases=q2_routes(w);variants=[]
    allpts=samples(bases,15);allneed=allpts[w.sample_margin(w.gateway,allpts,'direct')<.02]
    popularity=[int((w.sample_margin(np.array(s['point']),allneed,'access')>=.02).sum()) for s in sites]
    for i,v in enumerate(bases):
        pts=samples([v],10);need=pts[w.sample_margin(w.gateway,pts,'direct')<.02]
        ranking=[]
        for j,s in enumerate(sites):
            m=w.sample_margin(np.array(s['point']),need,'access') if len(need) else np.array([50.]);ranking.append((int((m>=.02).sum()),popularity[j]+float(m.min())*.001,j))
        ranking.sort(reverse=True);vs=[]
        # Best site must cover the entire radio-demand subset. Partial sites
        # can combine in a pair; evaluate finalists by rigorous certificates.
        finalist=[j for _,_,j in ranking[:16]]
        sets=[(j,) for j in finalist]+list(itertools.combinations(finalist[:5],2))
        if not len(need):sets=[(0,)]
        for g in w.mod:
            for stops in itertools.permutations(v['stops']):
                ev=w.evaluate(v['boxes'],stops,g)
                if not ev:continue
                accepted=0
                for subset in sets:
                    try:
                        cs=certificates(w,ev,[sites[z] for z in subset])
                        for c in cs:
                            if c['site']>=0:c['site']=subset[c['site']]
                        vs.append(dict(ev,certificates=cs));accepted+=1
                        if accepted>=12:break
                    except ValueError:pass
        variants.append(vs);print('route',i,'alternatives',len(vs),'single site sampled',ranking[0][:2],len(need),flush=True)
    (OUT/'work'/'strict_variants.json').write_text(json.dumps(dict(variants=variants,bases=bases,sites=sites),ensure_ascii=False),encoding='utf8')
    if any(not v for v in variants):raise RuntimeError('uncovered route')
    run(w,variants,bases,sites)

def run(w,variants,bases,sites):
    rng=random.Random(31159);best=None;history=[]
    for k in range(220):
        order=sorted(range(len(bases)),key=lambda i:(min(hard_deadline(w.boxes[x]) for x in bases[i]['boxes']),min(w.boxes[x]['期望送达时间（s）'] for x in bases[i]['boxes'])*rng.uniform(.3,1.7)))
        ans=schedule(w,variants,sites,order,gap=[60,200,500,1000,2000][k%5])
        if ans:
            h=dict(iteration=k,score=ans['score'],makespan=ans['makespan'],energy=ans['transport_energy']+ans['relay_energy'],weighted_late=ans['weighted_late'],relay_sorties=len(ans['relays']));history.append(h)
            if best is None or ans['score']<best['score']:
                best=ans;(OUT/'work'/'strict_best.json').write_text(json.dumps(best,ensure_ascii=False,indent=2),encoding='utf8');print('BEST',h,flush=True)
        if k%20==0:print('iteration',k,'feasible',len(history),flush=True)
    dumpcsv(OUT/'Q3_严格修订候选.csv',history)
    if best is None:raise RuntimeError('No feasible schedule')
if __name__=='__main__':main()
