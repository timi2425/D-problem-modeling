# 問題一：WGS84 橢球版

`q1_solver.py` 使用精確子集枚舉和位掩碼動態規劃，目標順序為最少架次、最低能耗、最短累計作業時間。`q1_foundation.py` 使用 WGS84 橢球反解和 WGS84 測地線逐像元 DEM 邊界求交。

運行示例：

```powershell
python q1_solver.py --root "G:/數學建模大賽/中文題目/D" --output-dir result
```

20% 安全余量下的已驗證結果：18 架次、59.130423267 kWh、32776.015749 s。
