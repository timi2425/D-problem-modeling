from q3_joint import *
from functools import lru_cache

def main():
    w=World();best=json.loads((OUT/'work'/'best.json').read_text(encoding='utf8'));sites=best['sites'];rng=random.Random(733)
    @lru_cache(None)
    def variants(ids):
        stops=sorted({w.boxes[x]['服务区编号'] for x in ids});vs=[]
        if len(stops)>4:return []
        for g in w.mod:
            for perm in itertools.permutations(stops):
                v=w.evaluate(ids,perm,g)
                if v:
                    try:v['certificates']=certificates(w,v,sites);vs.append(v)
                    except ValueError:pass
        return vs
    history=[]
    for k in range(110):
        trs=best['transports'];groups=[tuple(t['boxes']) for t in trs]
        late=[]
        for i,t in enumerate(trs):
            for x,off in t['deliveries'].items():
                b=w.boxes[x];pen=b['应急优先系数']*max(0,t['start']+off-b['期望送达时间（s）'])
                if hard_deadline(b)==math.inf and pen>0 and len(groups[i])>1:late.append((pen,i,x))
        if not late:break
        late.sort(reverse=True);_,ix,x=rng.choice(late[:min(18,len(late))]);groups[ix]=tuple(z for z in groups[ix] if z!=x)
        if k%3==0:
            dests=[i for i,g in enumerate(groups) if i!=ix and len(g)<7 and (w.boxes[x]['服务区编号'] in {w.boxes[z]['服务区编号'] for z in g})]
            if dests:di=rng.choice(dests);groups[di]=tuple(sorted(groups[di]+(x,)))
            else:groups.append((x,))
        else:
            moved=[x];other=[z for z in groups[ix] if w.boxes[z]['服务区编号']==w.boxes[x]['服务区编号'] and hard_deadline(w.boxes[z])==math.inf]
            if k%2==0 and other:
                z=rng.choice(other)
                if w.boxes[z]['单箱质量（kg）']+w.boxes[x]['单箱质量（kg）']<=30 and w.boxes[z]['单箱体积（m³）']+w.boxes[x]['单箱体积（m³）']<=.073:
                    moved.append(z);groups[ix]=tuple(a for a in groups[ix] if a!=z)
            groups.append(tuple(sorted(moved)))
        groups=[tuple(sorted(g)) for g in groups if g];vs=[variants(g) for g in groups]
        if any(not v for v in vs):continue
        for trial in range(3):
            order=sorted(range(len(groups)),key=lambda i:(min(hard_deadline(w.boxes[x]) for x in groups[i]),min(w.boxes[x]['期望送达时间（s）'] for x in groups[i])*rng.uniform(.7,1.3)))
            ans=schedule(w,vs,sites,order,1000)
            if ans and ans['score']<best['score']-1e-8:
                best=ans;(OUT/'work'/'best.json').write_text(json.dumps(best,ensure_ascii=False,indent=2),encoding='utf8')
                h=dict(iteration=k,score=ans['score'],makespan=ans['makespan'],weighted_late=ans['weighted_late'],energy=ans['transport_energy']+ans['relay_energy'],transport_sorties=len(ans['transports']),relay_sorties=len(ans['relays']));history.append(h);print('improved',h,flush=True)
        if k%10==0:print('local iteration',k,flush=True)
    dumpcsv(OUT/'Q3_组批改进记录.csv',history)
    print('FINAL',best['score'],len(best['transports']),len(best['relays']),flush=True)
if __name__=='__main__':main()
