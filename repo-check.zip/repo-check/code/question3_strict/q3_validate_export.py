from q3_joint import *

def main():
    w=World();ans=json.loads((OUT/'work'/'best.json').read_text(encoding='utf8'));ts=ans['transports'];rs=ans['relays'];sites=ans['sites'];checks=[]
    def check(name,condition,evidence):
        checks.append(dict(检查项=name,状态='PASS' if condition else 'FAIL',证据=str(evidence)))
    flights=[];boxes=[];comms=[];certs=[];bats=[];relays=[];resources=[];seen=[];margins=[];recomputedE=0.;recomputedLate=0.
    for i,t in enumerate(ts):
        t['id']=f'Q3-T{i+1:03d}';m=w.mod[t['model']];v=w.evaluate(t['boxes'],t['stops'],t['model']);check(t['id']+'运输物理重算',v is not None and abs(v['duration']-(t['end']-t['start']))<1e-6 and abs(v['energy']-t['energy'])<1e-8,t['energy'])
        recomputedE+=v['energy'];seen+=t['boxes']
        ready=t['end']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[t['model']])
        flights.append(dict(架次编号=t['id'],无人机编号=t['drone'],机型编号=t['model'],电池编号=t['battery'],开始时刻s=t['start'],访问服务区顺序='→'.join(t['stops']),返回O01时刻s=t['end'],架次能耗kWh=v['energy'],返航SOC=v['soc'],质量kg=v['mass'],体积m3=v['volume'],货箱列表=','.join(t['boxes'])))
        bats.append(dict(电池编号=t['battery'],架次编号=t['id'],占用开始s=t['start'],返回s=t['end'],返航SOC=v['soc'],充电结束s=ready))
        for x,off in v['deliveries'].items():
            b=w.boxes[x];arr=t['start']+off;hard=hard_deadline(b);delay=max(0,arr-b['期望送达时间（s）']);late=0 if b['物资类型']=='医疗物资' else b['应急优先系数']*delay;recomputedLate+=late
            boxes.append(dict(货箱编号=x,架次编号=t['id'],服务区编号=b['服务区编号'],交付完成时刻s=arr,物资类型=b['物资类型'],硬截止s=None if math.isinf(hard) else hard,期望s=b['期望送达时间（s）'],迟到s=delay,加权迟到=late))
            check(x+'硬时限',arr<=hard+1e-7,arr)
        cs=sorted(t['certificates'],key=lambda c:c['start']);cursor=v['phases'][0]['start']
        for j,c in enumerate(cs):
            a=np.array(c['p0']);b=np.array(c['p1']);ca=t['start']+c['start'];cb=t['start']+c['end'];k=c['site'];rid='';back=None
            check(t['id']+f'通信区间{j}连续',abs(c['start']-cursor)<1e-6,(cursor,c['start']));cursor=c['end']
            # Check certificate interval endpoints against recomputed flight/hover trajectory.
            ph=next(p for p in v['phases'] if p['start']<=c['start']+1e-6 and p['end']>=c['end']-1e-6)
            def at(ti):return np.array(ph['p0'])+(np.array(ph['p1'])-np.array(ph['p0']))*((ti-ph['start'])/(ph['end']-ph['start']))
            check(t['id']+f'轨迹{j}',np.max(np.abs(at(c['start'])-a))<1e-6 and np.max(np.abs(at(c['end'])-b))<1e-6,ph['phase'])
            if k<0:margin,proof=w.certificate(w.gateway,a,b,'direct');mode='直连'
            else:
                mode='中继';site=sites[k];p=np.array(site['point']);access,proof=w.certificate(p,a,b,'access');back,_=w.certificate(w.gateway,p,p,'backhaul');margin=min(access,back)
                hits=[r for r in rs if r['site']==k and r['service_start']<=ca+1e-6 and r['service_end']>=cb-1e-6];check(t['id']+f'中继时段{j}',len(hits)>0,(ca,cb));rid=hits[0]['id'] if hits else 'MISSING'
            margins.append(margin);check(t['id']+f'链路界{j}',margin>=-1e-8,margin)
            certs.append(dict(架次编号=t['id'],阶段=c['phase'],开始s=ca,结束s=cb,保障方式=mode,中继架次=rid,余量下界dB=margin,回传余量dB=back,证明方式=proof,起点lon=float(a[0]),起点lat=float(a[1]),起点海拔=float(a[2]),终点lon=float(b[0]),终点lat=float(b[1]),终点海拔=float(b[2])))
            if comms and comms[-1]['运输架次编号']==t['id'] and comms[-1]['通信阶段']==c['phase'] and comms[-1]['中继架次编号']==rid and abs(comms[-1]['结束时刻s']-ca)<1e-6:
                comms[-1]['结束时刻s']=cb;comms[-1]['最小保证余量dB']=min(comms[-1]['最小保证余量dB'],margin)
            else:comms.append(dict(运输架次编号=t['id'],通信阶段=c['phase'],开始时刻s=ca,结束时刻s=cb,保障方式=mode,中继架次编号=rid,最小保证余量dB=margin))
        check(t['id']+'通信至落地',abs(cursor-v['duration'])<1e-6,cursor)
    check('80箱唯一覆盖',len(seen)==80 and len(set(seen))==80 and set(seen)==set(w.boxes),len(seen))
    for r in rs:
        s=relay_physics(w,sites[r['site']]);energy=s['travel_energy']+(r['service_end']-r['service_start']+w.r.link_setup_s)*(w.r.hover_power_kw+w.r.communication_power_kw)/3600
        check(r['id']+'时间能耗',abs(r['start']+s['lead']-r['service_start'])<1e-6 and abs(r['service_end']+s['travel_back']-r['end'])<1e-6 and abs(energy-r['energy'])<1e-8 and energy<=.8*w.r.energy_kwh+1e-8,energy)
        check(r['id']+'能源充电',abs(r['component_ready']-r['end']-f.charge_time_s(1-energy/w.r.energy_kwh,1800))<1e-6,r['component_ready'])
        H=w.terrain_max(w.o,np.array(s['point']))+50
        check(r['id']+'固定巡航及离地上限',s['altitude']<=H+1e-8 and 0<s['altitude']-w.dem.nearest(s['lon'],s['lat'])<=300+1e-8,dict(cruise=H,hover=s['altitude'],agl=s['agl']))
        relays.append(dict(中继架次编号=r['id'],中继无人机编号=r['drone'],能源组件编号=r['component'],开始时刻s=r['start'],悬停经度=s['lon'],悬停纬度=s['lat'],悬停海拔m=s['altitude'],建链完成时刻s=r['service_start'],服务结束时刻s=r['service_end'],返回O01时刻s=r['end'],架次能耗kWh=energy,返航SOC=1-energy/w.r.energy_kwh,周转结束s=r['drone_ready'],充电结束s=r['component_ready'],悬停离地m=s['agl'],点位='P'+str(r['site']+1)))
    def no_overlap(rows,key,start,end,label):
        groups=defaultdict(list)
        for r in rows:groups[r[key]].append(r)
        for k,group in groups.items():
            group.sort(key=lambda r:r[start]);ok=all(b[start]>=a[end]-1e-6 for a,b in zip(group,group[1:]));check(label+k,ok,len(group))
    no_overlap(ts,'drone','start','end','运输机占用');no_overlap(bats,'电池编号','占用开始s','充电结束s','运输电池占用充电')
    no_overlap(rs,'drone','start','drone_ready','中继机含300秒周转');no_overlap(rs,'component','start','component_ready','能源组件充电')
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:
        actualdr=len({t['drone'] for t in ts if t['model']==g});actualb=len({t['battery'] for t in ts if t['model']==g});check(g+'库存',actualdr<=n and actualb<=b,(actualdr,actualb));resources.append(dict(资源=g+'运输无人机',使用数量=actualdr,库存=n));resources.append(dict(资源=g+'共享电池',使用数量=actualb,库存=b))
    check('中继库存',len({r['drone'] for r in rs})<=2 and len({r['component'] for r in rs})<=6,'2机6组件')
    resources.extend([dict(资源='中继无人机',使用数量=len({r['drone'] for r in rs}),库存=2),dict(资源='中继能源组件',使用数量=len({r['component'] for r in rs}),库存=6)])
    for name,rows in [('运输架次',flights),('逐箱交付',boxes),('中继架次',relays),('通信保障',comms),('区间证明',certs),('运输电池',bats),('库存使用',resources),('完整复核',checks)]:dumpcsv(OUT/f'Q3_{name}.csv',rows)
    summary=dict(transport_sorties=len(ts),relay_sorties=len(rs),boxes=len(seen),transport_energy_kwh=recomputedE,relay_energy_kwh=sum(r['energy'] for r in rs),joint_energy_kwh=recomputedE+sum(r['energy'] for r in rs),transport_finish_s=max(t['end'] for t in ts),joint_finish_s=max([t['end'] for t in ts]+[r['end'] for r in rs]),weighted_tardiness=recomputedLate,late_boxes=sum(b['迟到s']>1e-6 for b in boxes),certificate_intervals=len(certs),min_link_margin_db=min(margins),checks=len(checks),failed_checks=sum(r['状态']=='FAIL' for r in checks),scope='有限候选点、邻域组批和20秒起始时刻网格内的启发式可行解；未证明全局最优',sites=sites,resources=resources)
    (OUT/'Q3_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    (OUT/'work'/'workbook_data.json').write_text(json.dumps(dict(summary=summary,flights=flights,boxes=boxes,relays=relays,comms=comms,certs=certs,batteries=bats,resources=resources,checks=checks),ensure_ascii=False),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2));assert summary['failed_checks']==0
if __name__=='__main__':main()
