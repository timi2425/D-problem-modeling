"""CP-SAT rescheduling, fixed verified routes and radio site certificates.
One-second conservative scheduling lattice; exported physics is exact float.
This restricted scheduling model is not the global joint routing problem.
"""
from pathlib import Path
import sys,json,math,copy,time,argparse
from collections import defaultdict
BASE=Path(__file__).resolve().parent.parent.parent
sys.path.insert(0,str(BASE/'question3_strict'))
from q3_joint import World,hard_deadline,relay_physics,f
from ortools.sat.python import cp_model
OUT=Path(__file__).resolve().parent

def color(rows,key,start,end,names):
    avail={n:0. for n in names}
    for row in sorted(rows,key=lambda r:r[start]):
        name=min(avail,key=avail.get)
        assert avail[name]<=row[start]+1e-6,(key,name,avail[name],row[start])
        row[key]=name;avail[name]=row[end]

def solve(question,seconds,flex=False,cap=False):
    w=World();model=cp_model.CpModel();H=40000
    if question==3:
        old=json.loads((BASE/'04_问题三/work/best.json').read_text(encoding='utf8'));ts=copy.deepcopy(old['transports']);sites=old['sites'];rs=copy.deepcopy(old['relays'])
    else:
        import csv
        rows=list(csv.DictReader((BASE/'03_问题二/Q2_运输架次.csv').open(encoding='utf-8-sig')))
        ts=[];sites=[];rs=[];old={}
        for i,r in enumerate(rows):
            v=w.evaluate(r['货箱编号列表'].split(','),r['访问服务区顺序'].split('→'),r['机型编号']);v.update(start=float(r['开始时刻s']),end=float(r['返回O01时刻s']),base_index=i);ts.append(v)
    starts=[];ends=[];bends=[];dr=defaultdict(list);bt=defaultdict(list);tards=[];relaystarts=[];relayends=[];services=[];rint=[];cint=[]
    for i,t in enumerate(ts):
        v=w.evaluate(t['boxes'],t['stops'],t['model']);t.update(v)
        st=model.new_int_var(0,H,f't{i}');dur=math.ceil(v['duration']);en=model.new_int_var(0,H+10000,f'te{i}');model.add(en==st+dur)
        iv=model.new_interval_var(st,dur,en,f'transport{i}');dr[t['model']].append(iv)
        charge=f.charge_time_s(t['soc'],{'A':1800,'B':2400,'C':3000}[t['model']]);bd=math.ceil(v['duration']+charge);be=model.new_int_var(0,H+15000,f'be{i}');model.add(be==st+bd);bt[t['model']].append(model.new_interval_var(st,bd,be,f'battery{i}'))
        starts.append(st);ends.append(en);bends.append(be)
        for x,off in v['deliveries'].items():
            b=w.boxes[x];deadline=hard_deadline(b)
            if math.isfinite(deadline):model.add(st<=math.floor(deadline-off))
            if b['物资类型']!='医疗物资':
                tard=model.new_int_var(0,H+10000,'late'+x);model.add_max_equality(tard,[0,st+math.ceil(off)-int(b['期望送达时间（s）'])]);tards.append((int(b['应急优先系数']),tard))
        model.add_hint(st,round(t['start']))
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:
        model.add_cumulative(dr[g],[1]*len(dr[g]),n);model.add_cumulative(bt[g],[1]*len(bt[g]),b)
    memberships=defaultdict(list)
    for i,t in enumerate(ts):
        for c in t.get('certificates',[]):
            if c['site']<0:continue
            hits=[j for j,r in enumerate(rs) if r['site']==c['site'] and r['service_start']<=t['start']+c['start']+1e-6 and r['service_end']>=t['start']+c['end']-1e-6]
            assert hits
            memberships[hits[0]].append((i,c))
    for j,r in enumerate(rs):
        site=relay_physics(w,sites[r['site']]);ss=model.new_int_var(0,H,f'ss{j}');se=model.new_int_var(0,H,f'se{j}');length=model.new_int_var(1,math.floor(site['max_service']),f'length{j}');model.add(length==se-ss)
        if not flex:
            for i,c in memberships[j]:
                model.add(ss<=starts[i]+math.floor(c['start']));model.add(se>=starts[i]+math.ceil(c['end']))
        lead=math.ceil(site['lead']);back=math.ceil(site['travel_back']);rst=model.new_int_var(0,H,f'rs{j}');ren=model.new_int_var(0,H+10000,f're{j}');model.add(rst==ss-lead);model.add(ren==se+back)
        rend=model.new_int_var(0,H+12000,f'rd{j}');model.add(rend==ren+math.ceil(w.r.turnaround_s));rdur=model.new_int_var(0,H+12000,f'rdu{j}');model.add(rdur==rend-rst);rint.append(model.new_interval_var(rst,rdur,rend,f'relay{j}'))
        # For s<0.9 the charge is 500+1300*(E/3.2); this affine
        # extension also upper-bounds exact charge if residual SOC>=0.9.
        power=w.r.hover_power_kw+w.r.communication_power_kw
        alpha=1300*power/(3600*w.r.energy_kwh);beta=500+1300*(site['travel_energy']+power*w.r.link_setup_s/3600)/w.r.energy_kwh
        charge=model.new_int_var(0,5000,f'rc{j}');scale=10**6
        model.add(scale*charge>=math.ceil(alpha*scale)*length+math.ceil(beta*scale))
        ce=model.new_int_var(0,H+15000,f'rce{j}');model.add(ce==ren+charge);cd=model.new_int_var(0,H+15000,f'rcd{j}');model.add(cd==ce-rst);cint.append(model.new_interval_var(rst,cd,ce,f'component{j}'))
        services.append((ss,se,length));relaystarts.append(rst);relayends.append(ren)
        model.add_hint(ss,math.floor(r['service_start']));model.add_hint(se,math.ceil(r['service_end']))
    if flex and rs:
        for i,t in enumerate(ts):
            # Join adjacent intervals at the same site, preserving exact certified coverage.
            chunks=[]
            for c in t['certificates']:
                if c['site']<0:continue
                if chunks and chunks[-1]['site']==c['site'] and abs(chunks[-1]['end']-c['start'])<1e-6:chunks[-1]['end']=c['end']
                else:chunks.append(dict(c))
            for z,c in enumerate(chunks):
                choices=[]
                for j,r in enumerate(rs):
                    if r['site']!=c['site']:continue
                    use=model.new_bool_var(f'assign{i}_{z}_{j}');choices.append(use);ss,se,_=services[j]
                    model.add(ss<=starts[i]+math.floor(c['start'])).only_enforce_if(use);model.add(se>=starts[i]+math.ceil(c['end'])).only_enforce_if(use)
                model.add_exactly_one(choices)
        for site in range(len(sites)):
            js=[j for j,r in enumerate(rs) if r['site']==site]
            for a,b in zip(js,js[1:]):model.add(services[a][0]<=services[b][0])
    if rs:model.add_cumulative(rint,[1]*len(rs),2);model.add_cumulative(cint,[1]*len(rs),6)
    finish=model.new_int_var(0,H+10000,'finish');model.add_max_equality(finish,ends+relayends)
    if cap and question==3:model.add(finish<=math.floor(old['makespan']))
    # Preserve prior continuous weighted objective; coefficients are floating
    # only in objective, all capacity/timing inequalities are integer-safe.
    den=sum(b['应急优先系数']*b['期望送达时间（s）'] for b in w.boxes.values() if b['物资类型']!='医疗物资')
    energy_den=70 if question==3 else 60
    objective=sum(.5*a/den*b for a,b in tards)+.2/14400*finish
    if rs:objective+=sum(.2/energy_den*(w.r.hover_power_kw+w.r.communication_power_kw)/3600*length for ss,se,length in services)
    model.minimize(objective)
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds;solver.parameters.num_search_workers=8;solver.parameters.random_seed=20260924
    class Callback(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.last=-100
        def on_solution_callback(self):
            if self.wall_time-self.last>10:print('INCUMBENT',question,round(self.wall_time,1),self.objective_value,flush=True);self.last=self.wall_time
    status=solver.solve(model,Callback());print('SOLVER',question,solver.status_name(status),solver.objective_value,solver.best_objective_bound,flush=True)
    assert status in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    for i,t in enumerate(ts):t['start']=float(solver.value(starts[i]));t['end']=t['start']+t['duration'];t['battery_ready']=t['end']+f.charge_time_s(t['soc'],{'A':1800,'B':2400,'C':3000}[t['model']])
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:
        group=[t for t in ts if t['model']==g];names={'A':['U01','U02','U03','U04'],'B':['U05','U06'],'C':['U07','U08']}[g]
        color(group,'drone','start','end',names);color(group,'battery','start','battery_ready',[f'{g}-BAT-{i+1:02d}' for i in range(b)])
    for j,r in enumerate(rs):
        ss,se,_=services[j];ss=float(solver.value(ss));se=float(solver.value(se));site=relay_physics(w,sites[r['site']]);energy=site['travel_energy']+(se-ss+w.r.link_setup_s)*(w.r.hover_power_kw+w.r.communication_power_kw)/3600
        end=se+site['travel_back'];r.update(start=ss-site['lead'],service_start=ss,service_end=se,end=end,energy=energy,soc=1-energy/w.r.energy_kwh,drone_ready=end+w.r.turnaround_s,component_ready=end+f.charge_time_s(1-energy/w.r.energy_kwh,1800))
    color(rs,'drone','start','drone_ready',['R01','R02']);color(rs,'component','start','component_ready',[f'RE-{i+1:02d}' for i in range(6)])
    late=sum(w.boxes[x]['应急优先系数']*max(0,t['start']+off-w.boxes[x]['期望送达时间（s）']) for t in ts for x,off in t['deliveries'].items() if w.boxes[x]['物资类型']!='医疗物资');makespan=max(t['end'] for t in ts+rs);te=sum(t['energy'] for t in ts);re=sum(r['energy'] for r in rs)
    score=.5*late/den+.2*makespan/14400+.2*(te+re)/energy_den+.1*(len(ts)+len(rs))/(25 if question==3 else 18)
    ans=dict(transports=ts,relays=rs,sites=sites,weighted_late=late,makespan=makespan,transport_energy=te,relay_energy=re,score=score,solver_status=solver.status_name(status),restricted_objective_bound=solver.best_objective_bound,restricted_objective=solver.objective_value,scope='fixed routes, types, certificates, relay mission membership; resource reassignment and joint rescheduling; conservative 1s lattice')
    ans.update(flexible_mission_membership=flex,finish_capped=cap)
    dest=OUT/(f'Q{question}_cp'+('_flex' if flex else '')+('_cap' if cap else ''));(dest/'work').mkdir(parents=True,exist_ok=True);(dest/'work/best.json').write_text(json.dumps(ans,ensure_ascii=False,indent=2),encoding='utf8')
    print('RESULT',question,{k:v for k,v in ans.items() if k not in ['transports','relays','sites']},flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--question',type=int,choices=[2,3],required=True);p.add_argument('--seconds',type=float,default=90);p.add_argument('--flex',action='store_true');p.add_argument('--cap',action='store_true');a=p.parse_args();solve(a.question,a.seconds,a.flex,a.cap)
