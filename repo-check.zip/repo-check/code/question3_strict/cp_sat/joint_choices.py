"""Optional-interval CP-SAT chooses type, order, radio pattern and relay use.
Preserves 27 original box groups; finite verified site/trajectory candidates.
"""
from pathlib import Path
import sys,json,math,copy,argparse
from collections import defaultdict
BASE=Path(__file__).resolve().parent.parent.parent;OUT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(BASE/'question3_strict'));sys.path.insert(0,str(OUT))
from q3_joint import World,hard_deadline,relay_physics,f
from optimize_schedule import color
from ortools.sat.python import cp_model

def run(seconds,question=3,finish_limit=None):
    w=World();raw=json.loads((BASE/'04_问题三/work/fixed_variants.json').read_text(encoding='utf8'))
    sites=[];mapping={}
    for i,s in enumerate(raw['sites']):
        match=next((j for j,a in enumerate(sites) if a['point']==s['point']),None)
        if match is None:match=len(sites);sites.append(relay_physics(w,s))
        mapping[i]=match
    variants=[]
    for group in raw['variants']:
        dedup={}
        for v in group:
            v=copy.deepcopy(v)
            for c in v['certificates']:
                if c['site']>=0:c['site']=mapping[c['site']]
            chunks=[]
            for c in v['certificates']:
                if c['site']<0:continue
                if chunks and chunks[-1]['site']==c['site'] and abs(chunks[-1]['end']-c['start'])<1e-6:chunks[-1]['end']=c['end']
                else:chunks.append(dict(c))
            key=(v['model'],tuple(v['stops']),tuple((c['site'],c['start'],c['end']) for c in chunks))
            v['chunks']=chunks;dedup[key]=v
        variants.append(list(dedup.values()))
    if question==2:
        variants=[]
        import itertools
        for base in raw['bases']:
            group=[]
            for g in w.mod:
                for stops in itertools.permutations(base['stops']):
                    v=w.evaluate(base['boxes'],stops,g)
                    if v:group.append(dict(v,certificates=[],chunks=[]))
            variants.append(group)
        sites=[]
    print('UNIQUE_VARIANTS',question,[len(g) for g in variants],len(sites),flush=True)
    m=cp_model.CpModel();H=14000
    starts=[m.new_int_var(0,H,f't{i}') for i in range(len(variants))];ends=[];chosen=[];dr=defaultdict(list);bt=defaultdict(list);late_terms=[];energy_terms=[]
    slots=[];rints=[];cints=[];relay_energies=[]
    # Three potential sorties per candidate site, optional; all share two aircraft.
    for k,s in enumerate(sites):
        prev=None
        for n in range(3):
            on=m.new_bool_var(f'r{k}_{n}');ss=m.new_int_var(0,H,f'ss{k}_{n}');se=m.new_int_var(0,H,f'se{k}_{n}');length=m.new_int_var(0,math.floor(s['max_service']),f'len{k}_{n}')
            m.add(length==se-ss);m.add(length>=1).only_enforce_if(on);m.add(ss==0).only_enforce_if(on.Not());m.add(se==0).only_enforce_if(on.Not())
            st=m.new_int_var(-2000,H,f'rs{k}_{n}');en=m.new_int_var(0,H+2000,f're{k}_{n}');m.add(st==ss-math.ceil(s['lead']));m.add(en==se+math.ceil(s['travel_back']));m.add(st>=0).only_enforce_if(on)
            rd=m.new_int_var(0,H+5000,f'rd{k}_{n}');re=m.new_int_var(0,H+5000,f'rend{k}_{n}');m.add(re==en+300);m.add(rd==re-st);rints.append(m.new_optional_interval_var(st,rd,re,on,f'riv{k}_{n}'))
            power=w.r.hover_power_kw+w.r.communication_power_kw;alpha=1300*power/(3600*w.r.energy_kwh);beta=500+1300*(s['travel_energy']+power*w.r.link_setup_s/3600)/w.r.energy_kwh
            charge=m.new_int_var(0,5000,f'charge{k}_{n}');m.add(10**6*charge>=math.ceil(alpha*10**6)*length+math.ceil(beta*10**6))
            ce=m.new_int_var(0,H+7000,f'ce{k}_{n}');cd=m.new_int_var(0,H+9000,f'cd{k}_{n}');m.add(ce==en+charge);m.add(cd==ce-st);cints.append(m.new_optional_interval_var(st,cd,ce,on,f'civ{k}_{n}'))
            effective=m.new_int_var(0,H+2000,f'eff{k}_{n}');m.add(effective==en).only_enforce_if(on);m.add(effective==0).only_enforce_if(on.Not())
            slots.append(dict(site=k,on=on,ss=ss,se=se,length=length,end=effective,uses=[]))
            relay_energies.append((s['travel_energy']+power*w.r.link_setup_s/3600)*on+power/3600*length)
            if prev is not None:m.add(on<=prev['on']);m.add(ss>=prev['se']).only_enforce_if(on)
            prev=slots[-1]
    for i,vs in enumerate(variants):
        st=starts[i];en=m.new_int_var(0,H+4000,f'end{i}');ends.append(en);picks=[]
        for j,v in enumerate(vs):
            use=m.new_bool_var(f'v{i}_{j}');picks.append(use);dur=math.ceil(v['duration']);m.add(en==st+dur).only_enforce_if(use)
            dr[v['model']].append(m.new_optional_interval_var(st,dur,en,use,f'iv{i}_{j}'))
            bd=math.ceil(v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]));be=m.new_int_var(0,H+9000,f'be{i}_{j}');bt[v['model']].append(m.new_optional_interval_var(st,bd,be,use,f'biv{i}_{j}'))
            energy_terms.append(v['energy']*use)
            for x,off in v['deliveries'].items():
                deadline=hard_deadline(w.boxes[x])
                if math.isfinite(deadline):m.add(st<=math.floor(deadline-off)).only_enforce_if(use)
                if w.boxes[x]['物资类型']!='医疗物资':
                    tard=m.new_int_var(0,H+10000,f'late{i}_{j}_{x}');m.add(tard>=st+math.ceil(off)-int(w.boxes[x]['期望送达时间（s）'])).only_enforce_if(use);m.add(tard==0).only_enforce_if(use.Not());late_terms.append(w.boxes[x]['应急优先系数']*tard)
            for z,c in enumerate(v['chunks']):
                assigns=[]
                for r in slots:
                    if r['site']!=c['site']:continue
                    a=m.new_bool_var(f'a{i}_{j}_{z}_{len(assigns)}');assigns.append(a);r['uses'].append(a);m.add(a<=r['on']);m.add(r['ss']<=st+math.floor(c['start'])).only_enforce_if(a);m.add(r['se']>=st+math.ceil(c['end'])).only_enforce_if(a)
                m.add(sum(assigns)==use)
        m.add_exactly_one(picks);chosen.append(picks)
    for r in slots:m.add(r['on']<=sum(r['uses']))
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:m.add_cumulative(dr[g],[1]*len(dr[g]),n);m.add_cumulative(bt[g],[1]*len(bt[g]),b)
    m.add_cumulative(rints,[1]*len(rints),2);m.add_cumulative(cints,[1]*len(cints),6)
    finish=m.new_int_var(0,H+2000,'finish');m.add_max_equality(finish,ends+[r['end'] for r in slots]);m.add(finish<=(finish_limit if finish_limit is not None else (12975 if question==3 else 8998)))
    den=sum(b['应急优先系数']*b['期望送达时间（s）'] for b in w.boxes.values() if b['物资类型']!='医疗物资')
    energy_den=70 if question==3 else 60;sortie_den=25 if question==3 else 18
    obj=.5/den*sum(late_terms)+.2/14400*finish+.2/energy_den*(sum(energy_terms)+sum(relay_energies))+.1/sortie_den*(27+sum(r['on'] for r in slots));m.minimize(obj)
    # Incumbent warm start from the already feasible CP reschedule, mapped by physical certificates.
    warm_path=OUT/('Q3_joint_cp' if finish_limit is not None and question==3 else ('Q3_cp_flex_cap' if question==3 else 'Q2_cp'))/'work/best.json'
    warm=json.loads(warm_path.read_text(encoding='utf8'))
    for i,vs in enumerate(variants):
        old=next(t for t in warm['transports'] if set(t['boxes'])==set(vs[0]['boxes']))
        best=next((j for j,v in enumerate(vs) if v['model']==old['model'] and v['stops']==old['stops'] and (question==2 or [(c['start'],c['end'],c['p0'],c['p1'],None if c['site']<0 else sites[c['site']]['point']) for c in v['certificates']]==[(c['start'],c['end'],c['p0'],c['p1'],None if c['site']<0 else warm['sites'][c['site']]['point']) for c in old['certificates']])),None)
        m.add_hint(starts[i],round(old['start']))
        if best is not None:
            for j,x in enumerate(chosen[i]):m.add_hint(x,int(j==best))
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds;solver.parameters.num_search_workers=8;solver.parameters.random_seed=20260924
    class Callback(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.last=-100
        def on_solution_callback(self):
            if self.wall_time-self.last>10:print('JOINT_INCUMBENT',round(self.wall_time,1),self.objective_value,flush=True);self.last=self.wall_time
    status=solver.solve(m,Callback());print('JOINT_STATUS',solver.status_name(status),solver.objective_value,solver.best_objective_bound,flush=True)
    if status not in [cp_model.OPTIMAL,cp_model.FEASIBLE]:return
    ts=[];rs=[]
    for i,vs in enumerate(variants):
        j=next(j for j,u in enumerate(chosen[i]) if solver.value(u));v=copy.deepcopy(vs[j]);v.pop('chunks',None);st=float(solver.value(starts[i]));v.update(start=st,end=st+v['duration'],base_index=i,battery_ready=st+v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]));ts.append(v)
    for r in slots:
        if not solver.value(r['on']):continue
        s=sites[r['site']];ss=float(solver.value(r['ss']));se=float(solver.value(r['se']));energy=s['travel_energy']+(se-ss+w.r.link_setup_s)*(w.r.hover_power_kw+w.r.communication_power_kw)/3600;end=se+s['travel_back'];soc=1-energy/w.r.energy_kwh
        rs.append(dict(site=r['site'],start=ss-s['lead'],service_start=ss,service_end=se,end=end,energy=energy,soc=soc,drone_ready=end+300,component_ready=end+f.charge_time_s(soc,1800)))
    rs.sort(key=lambda r:r['start'])
    for i,r in enumerate(rs):r['id']=f'Q3-R{i+1:03d}'
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:
        group=[t for t in ts if t['model']==g];color(group,'drone','start','end',{'A':['U01','U02','U03','U04'],'B':['U05','U06'],'C':['U07','U08']}[g]);color(group,'battery','start','battery_ready',[f'{g}-BAT-{i+1:02d}' for i in range(b)])
    color(rs,'drone','start','drone_ready',['R01','R02']);color(rs,'component','start','component_ready',[f'RE-{i+1:02d}' for i in range(6)])
    late=sum(w.boxes[x]['应急优先系数']*max(0,t['start']+off-w.boxes[x]['期望送达时间（s）']) for t in ts for x,off in t['deliveries'].items() if w.boxes[x]['物资类型']!='医疗物资');finish=max(r['end'] for r in ts+rs);te=sum(t['energy'] for t in ts);re=sum(r['energy'] for r in rs);score=.5*late/den+.2*finish/14400+.2*(te+re)/energy_den+.1*(len(ts)+len(rs))/sortie_den
    ans=dict(transports=ts,relays=rs,sites=sites,weighted_late=late,makespan=finish,transport_energy=te,relay_energy=re,score=score,solver_status=solver.status_name(status),restricted_objective=solver.objective_value,restricted_objective_bound=solver.best_objective_bound,scope='fixed 27 box groups; finite route/type/certified-site choices; <=3 relay sorties per site; conservative 1s intervals')
    ans['scope']='fixed 27 box groups; finite type and visit-order choices; conservative 1s intervals'+('; finite certified sites and <=3 relay sorties per site' if question==3 else '; communication excluded')
    ans['finish_limit']=finish_limit
    dest=OUT/(f'Q{question}_joint_cp'+(f'_cap{finish_limit}' if finish_limit is not None else ''));(dest/'work').mkdir(parents=True,exist_ok=True);(dest/'work/best.json').write_text(json.dumps(ans,ensure_ascii=False,indent=2),encoding='utf8');print('JOINT_RESULT',question,{k:v for k,v in ans.items() if k not in ['transports','relays','sites']},flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seconds',type=float,default=120);p.add_argument('--question',type=int,default=3,choices=[2,3]);p.add_argument('--finish-limit',type=int);a=p.parse_args();run(a.seconds,a.question,a.finish_limit)
