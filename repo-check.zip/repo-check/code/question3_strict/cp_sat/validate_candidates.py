from pathlib import Path
import sys,json,contextlib,io,argparse
BASE=Path(__file__).resolve().parent.parent.parent;OUT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(BASE/'question3_strict'))
import q3_validate_export as v,q3_independent_radio_check as radio,q3_release_audit as extra

def validate(name):
    out=OUT/name;d=json.loads((out/'work/best.json').read_text(encoding='utf8'))
    if name.startswith('Q3'):
        used=sorted({r['site'] for r in d['relays']});lookup={old:i for i,old in enumerate(used)};d['sites']=[d['sites'][i] for i in used]
        for t in d['transports']:
            for c in t['certificates']:
                if c['site']>=0:c['site']=lookup[c['site']]
        for r in d['relays']:r['site']=lookup[r['site']]
        (out/'work/best.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
        v.OUT=out;radio.OUT=out;extra.OUT=out
        with contextlib.redirect_stdout(io.StringIO()):v.main()
        radio.main();extra.main()
        summary_path=out/'Q3_summary.json';summary=json.loads(summary_path.read_text(encoding='utf8'));summary['scope']=d['scope'];summary['solver_status']=d.get('solver_status');summary['score']=d['score'];summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
        path=out/'work/workbook_data.json';payload=json.loads(path.read_text(encoding='utf8'));payload['summary']=summary;payload['solver_metadata']={k:v for k,v in d.items() if k not in ['transports','relays','sites']};path.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf8')
        print('Q3_VALIDATED',name,flush=True);return
    w=extra.World()
    for t in d['transports']:t['certificates']=[]
    checks=extra.audit_candidate(d,w);assert all(c['状态']=='PASS' for c in checks);flights=[];boxes=[];bats=[]
    for i,t in enumerate(d['transports'],1):
        ev=w.evaluate(t['boxes'],t['stops'],t['model']);id=f'Q2-CP-{i:03d}';assert ev and abs(t['end']-t['start']-ev['duration'])<1e-7
        flights.append(dict(架次编号=id,无人机编号=t['drone'],机型编号=t['model'],电池编号=t['battery'],开始时刻s=t['start'],访问服务区顺序='→'.join(t['stops']),返回O01时刻s=t['end'],架次能耗kWh=ev['energy'],货箱编号列表=','.join(t['boxes']),返航SOC=ev['soc']))
        bats.append(dict(电池编号=t['battery'],架次编号=id,占用开始s=t['start'],返回s=t['end'],充电结束s=t['battery_ready']))
        for x,off in ev['deliveries'].items():
            box=w.boxes[x];end=t['start']+off;deadline=v.hard_deadline(box);assert end<=deadline+1e-7
            boxes.append(dict(货箱编号=x,架次编号=id,服务区编号=box['服务区编号'],交付完成时刻s=end,期望时刻s=box['期望送达时间（s）'],加权迟到=0 if box['物资类型']=='医疗物资' else box['应急优先系数']*max(0,end-box['期望送达时间（s）'])))
    for file,rows in [('运输架次',flights),('逐箱交付',boxes),('电池占用',bats),('复核',checks)]:v.dumpcsv(out/f'Q2_{file}.csv',rows)
    summary={k:x for k,x in d.items() if k not in ['transports','sites','relays']};summary.update(sorties=len(flights),boxes=len(boxes),checks=len(checks),failed=0)
    (out/'Q2_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');(out/'work/workbook_data.json').write_text(json.dumps(dict(summary=summary,flights=flights,boxes=boxes,batteries=bats,checks=checks),ensure_ascii=False),encoding='utf8')
    print('Q2_VALIDATED',name,len(boxes),len(checks),sum(r['加权迟到'] for r in boxes),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('name');validate(p.parse_args().name)
