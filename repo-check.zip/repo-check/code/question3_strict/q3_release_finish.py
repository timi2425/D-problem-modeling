"""Write Q3 release documentation and verify saved deliverables."""
from pathlib import Path
import csv
import hashlib
import json
import math
from openpyxl import load_workbook
from q3_engine import World, dumpcsv, readcsv

OUT=Path(__file__).resolve().parent
VERSION='Q3-20260924-final'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def write_context():
    s=json.loads((OUT/'Q3_summary.json').read_text(encoding='utf8'))
    d=json.loads((OUT/'work/best.json').read_text(encoding='utf8'))
    prev=json.loads((OUT/'release/previous_summary.json').read_text(encoding='utf8'))
    w=World();den=sum(b['应急优先系数']*b['期望送达时间（s）'] for b in w.boxes.values() if b['物资类型']!='医疗物资')
    rows=[]
    for label,x in [('严格版前次发布',prev),('本次冻结发布',s)]:
        score=.5*x['weighted_tardiness']/den+.2*x['joint_finish_s']/14400+.2*x['joint_energy_kwh']/70+.1*(x['transport_sorties']+x['relay_sorties'])/25
        rows.append(dict(方案=label,运输架次=x['transport_sorties'],中继架次=x['relay_sorties'],完成时间s=x['joint_finish_s'],总能耗kWh=x['joint_energy_kwh'],加权迟到=x['weighted_tardiness'],迟到箱数=x['late_boxes'],综合评分=score))
    assert abs(rows[-1]['综合评分']-d['score'])<1e-10
    dumpcsv(OUT/'Q3_候选权衡.csv',rows)
    components=[dict(能源组件编号=r['component'],中继架次编号=r['id'],占用开始s=r['start'],返航s=r['end'],返航SOC=r['soc'],充电结束s=r['component_ready']) for r in d['relays']]
    dumpcsv(OUT/'Q3_中继能源组件.csv',components)
    supplemental=readcsv(OUT/'Q3_发布补充复核.csv')
    p=OUT/'work/workbook_data.json';wb=json.loads(p.read_text(encoding='utf8'));wb.update(comparison=rows,relay_components=components,release_version=VERSION,supplemental_checks=len(supplemental));p.write_text(json.dumps(wb,ensure_ascii=False),encoding='utf8')
    stamp=sha(OUT/'release/selected_candidate.json')
    note=f'''# 第三问冻结发布说明

版本 {VERSION}。80箱，27个运输架次，9个中继架次。联合完成时间{s['joint_finish_s']:.6f}秒，总能耗{s['joint_energy_kwh']:.6f}kWh，加权迟到{s['weighted_tardiness']:.6f}，普通物资迟到{s['late_boxes']}箱。

与上次同口径严格版相比，完成时间减少{prev['joint_finish_s']-s['joint_finish_s']:.3f}秒，加权迟到减少{prev['weighted_tardiness']-s['weighted_tardiness']:.3f}，能耗增加{s['joint_energy_kwh']-prev['joint_energy_kwh']:.6f}kWh。因此两者存在权衡；本版按已公布权重评分较低，不宣称逐指标支配或全局最优。

## 复核与适用条件

主验证器{s['checks']}项，补充编号与资源事件检查{len(supplemental)}项，以及855个端点/中点射线复核。连续通信依据285段保守区间界，不是由855个采样点推断。最小保证余量{s['min_link_margin_db']:.9f}dB；结论限于声明的DEM表面、确定性传播和能耗假设。

任务书未展开的水平能耗、爬升分量、DEM表面和逐箱交付策略均作为模型补充。悬停海拔不高于沿线DEM最大值+50米是本版固定航段构造的可行性限制；不把它另称为任务书单独规定的悬停上限。题目给定的悬停离地上限为300米。

通信表中的“中继”表示全区间保守预留保障源，区间内若直连可用则按题目采用直连。其含义不能改写成该区间每一时刻直连均不可用。未重新搜索连续坐标和所有组批，当前运输组批继承参考启发的第二问27组。

## 文件入口与第四问继承

- 问题三_运输通信联合优化.xlsx：完整方案、时序、组件、对比及复核。
- 问题三_结果提交模板.xlsx：第三问提交表；其他问题的空表不代表已完成全题提交。
- 问题三_模型与解答.md：模型、方法、结果和假设。
- Q3_运输架次.csv、Q3_逐箱交付.csv、Q3_中继架次.csv、Q3_通信保障.csv：第四问继承的同版数据。
- release/Q4_baseline.json：已经冻结的运输、中继、通信和充电时间线。第四问不得改变本版组批、服务顺序、时刻或保障关系。
- Q3_发布清单.json：输入及输出校验码；重跑后必须重新核查，不得仅凭历史COMPLETE文件判断。

冻结候选SHA256：{stamp}

旧发布版位于08_任务书严格修订/旧版备份/Q3_收尾前_20260924。本次只收尾第三问；第四问尚未求解。
'''
    (OUT/'第三问收尾说明.md').write_text(note,encoding='utf8')
    report=OUT/'问题三_模型与解答.md'
    text=report.read_text(encoding='utf8')
    text=text.replace('本次进行20个任务顺序，beam宽度10，随机种子9991','搜索程序配置最多20个任务顺序，beam宽度10，随机种子9991；本次发布从中断前已保存候选中选取，不认定全部搜索轮次已经完成')
    text=text.replace('每站装载、飞行、基础交接及逐箱交接均计时','O01出发前准备与逐箱装载、逐航段飞行、各服务区基础交接及逐箱交接均计时')
    text=text.replace('以本轮严格修订汇总指定文件为准','以第三问收尾说明.md及Q3_发布清单.json指定的冻结版本为准')
    comparison_text='与上次同口径严格版相比，'+note.split('与上次同口径严格版相比，')[1].split('\n\n##')[0]
    text+='\n## 发布比较\n\n'+comparison_text+'\n'
    report.write_text(text,encoding='utf8')
    (OUT/'复核后续优化说明.md').write_text(f'# 第三问状态\n\n本文件更新为{VERSION}。已完成严格航高修订后的候选选择、再验证和导出；旧的20运输架次、5中继架次和1443射线点记录仅属于历史版本。当前结果及限制见第三问收尾说明.md。进一步扩大候选集属于后续优化，并非本次冻结发布所必需。\n',encoding='utf8')
    (OUT/'运行说明.md').write_text('''# 第三问冻结版本复现

在本目录运行：

```powershell
python run_q3_release.py --node <node可执行文件完整路径>
```

运行前安装numpy、Pillow、openpyxl、matplotlib；Node需能导入@oai/artifact-tool。现有项目node_modules已连接Codex配套依赖。Python和Node路径不必与当前电脑相同。

默认原始数据位置是G:/数学建模大赛/中文题目/D，可用环境变量Q3_SOURCE_ROOT指定另一个包含任务书和数据目录的原始D目录。保留相邻01_数据与物理底座/q1_foundation.py及communication_parameters_raw.csv。

程序读取release/selected_candidate.json，重新规范站点编号、验证并生成CSV、报告、Excel和图，最后校验文件。它不会重新搜索，所以可以稳定复现已发布数值。--prepare-only仅生成表格输入和验证数据，不代表完整发布完成；完整运行后仍需人工查看导出的工作簿和三张图。

若研究更优解，在08_任务书严格修订中先生成strict_variants.json（strict_q3_v2.py），然后运行strict_fixed_sites.py；初筛依赖strict_sites.py和strict_early_pair.py。研究搜索可更新work/strict_best.json，但不会自动替换本次冻结候选。完整搜索是否结束应看实际运行日志，不能从配置轮数推断。

运输电池编号是按机型库存生成的A/B/C-BAT-xx，中继组件为RE-xx；实体无人机编号来自原始参数表。
''',encoding='utf8')


def finalize():
    d=json.loads((OUT/'work/workbook_data.json').read_text(encoding='utf8'))
    checks=[]
    def ck(label,ok):
        checks.append(dict(检查项=label,状态='PASS' if ok else 'FAIL'))
        if not ok:raise AssertionError(label)
    def same(a,b):
        if isinstance(b,(float,int)):
            return isinstance(a,(float,int)) and math.isfinite(a) and abs(a-b)<=max(1e-7,abs(b)*1e-12)
        return (a or '')==(b or '')
    book=load_workbook(OUT/'问题三_运输通信联合优化.xlsx',data_only=True)
    mappings=[('Q3运输架次','flights'),('Q3逐箱交付','boxes'),('Q3中继架次','relays'),('Q3通信保障','comms'),('运输电池','batteries'),('库存使用','resources'),('候选比较','comparison'),('中继能源组件','relay_components')]
    for name,key in mappings:
        rows=list(book[name].iter_rows(min_row=2,values_only=True));want=[list(r.values()) for r in d[key]]
        ck(name+'行列及逐值一致',len(rows)==len(want) and all(len(a)>=len(b) and all(same(x,y) for x,y in zip(a,b)) for a,b in zip(rows,want)))
    tpl=load_workbook(OUT/'问题三_结果提交模板.xlsx',data_only=True)
    for name,key,count in [('Q3_运输架次','flights',12),('Q3_逐箱交付','boxes',9),('Q3_中继架次','relays',11),('Q3_通信保障','comms',6)]:
        actual=[list(r)[:count] for r in tpl[name].iter_rows(min_row=2,values_only=True) if any(x is not None for x in r)]
        want=[list(r.values())[:count] for r in d[key]]
        ck(name+'提交逐值一致',len(actual)==len(want) and all(all(same(x,y) for x,y in zip(a,b)) for a,b in zip(actual,want)))
    for name in ['Q3_完整复核.csv','Q3_独立射线复核.csv','Q3_发布补充复核.csv']:
        records=readcsv(OUT/name);ck(name+'零失败',bool(records) and all(r['状态']=='PASS' for r in records))
    for filename,key in [('运输架次','flights'),('逐箱交付','boxes'),('中继架次','relays'),('通信保障','comms'),('区间证明','certs'),('运输电池','batteries'),('中继能源组件','relay_components'),('候选权衡','comparison')]:
        rows=readcsv(OUT/f'Q3_{filename}.csv');want=d[key]
        ck(filename+'CSV与快照一致',len(rows)==len(want) and all(all((abs(float(a[k])-v)<max(1e-7,abs(v)*1e-12)) if isinstance(v,(float,int)) else (a[k] or '')==(v or '') for k,v in b.items()) for a,b in zip(rows,want)))
    ck('快照与公开摘要一致',d['summary']==json.loads((OUT/'Q3_summary.json').read_text(encoding='utf8')))
    baseline=dict(version=VERSION,source_candidate_sha256=sha(OUT/'release/selected_candidate.json'),summary=d['summary'],flights=d['flights'],boxes=d['boxes'],relays=d['relays'],comms=d['comms'],certificates=d['certs'],transport_batteries=d['batteries'],relay_components=d['relay_components'])
    (OUT/'release/Q4_baseline.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2),encoding='utf8')
    dumpcsv(OUT/'Q3_最终文件一致性.csv',checks)
    visual_path=OUT/'release/visual_review.json'
    visual=json.loads(visual_path.read_text(encoding='utf8')) if visual_path.exists() else {}
    visual_ok=visual.get('passed') is True and len(visual.get('files',{}))>=5 and all((OUT/k).exists() and sha(OUT/k)==v for k,v in visual.get('files',{}).items())
    state=json.loads((OUT/'Q3_COMPLETE.json').read_text(encoding='utf8'));state.update(status='COMPLETE' if visual_ok else 'NUMERIC_CHECKS_PASSED_AWAITING_VISUAL_QA',version=VERSION,selected_candidate_sha256=baseline['source_candidate_sha256'],supplemental_checks=len(readcsv(OUT/'Q3_发布补充复核.csv')),file_consistency_checks=len(checks),visual_review_passed=visual_ok)
    (OUT/'Q3_COMPLETE.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf8')
    paths=[p for p in OUT.iterdir() if p.is_file() and p.suffix in {'.py','.mjs','.csv','.json','.md','.xlsx','.png','.pdf'} and p.name not in ['Q3_文件校验码.json','Q3_发布清单.json']]
    paths += list((OUT/'release').glob('*.json'))+list((OUT/'release').glob('*.mplstyle'))+[OUT/'work/best.json',OUT/'work/workbook_data.json']
    hashes={p.relative_to(OUT).as_posix():sha(p) for p in sorted(paths)}
    (OUT/'Q3_文件校验码.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2),encoding='utf8')
    from q3_engine import SOURCE,BASE
    source_files=list((SOURCE/'数据').rglob('*.xlsx'))+list((SOURCE/'数据').rglob('*.tif'))+list(SOURCE.glob('*.docx'))+[SOURCE/'结果提交模板.xlsx']
    external=[BASE/'01_数据与物理底座/q1_foundation.py',BASE/'01_数据与物理底座/communication_parameters_raw.csv',BASE/'08_任务书严格修订/write_strict_q3_report.py']
    manifest=dict(version=VERSION,summary=d['summary'],checks=state,files=hashes,source_files={str(p):sha(p) for p in source_files+external})
    (OUT/'Q3_发布清单.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
    print('RELEASE_FINALIZED',len(checks),'file gates; sha256',len(hashes),'files')


if __name__=='__main__':finalize()
