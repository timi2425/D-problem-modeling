from q3_engine import *
import json
from openpyxl import load_workbook
OUT=Path(__file__).resolve().parent
def main():
    d=json.loads((OUT/'work'/'workbook_data.json').read_text(encoding='utf8'));s=d['summary'];assert s['failed_checks']==0
    failures=[r for r in readcsv(OUT/'Q3_独立射线复核.csv') if r['状态']!='PASS'];assert not failures
    book=load_workbook(OUT/'问题三_运输通信联合优化.xlsx',read_only=False,data_only=True)
    for name,key in [('Q3运输架次','flights'),('Q3逐箱交付','boxes'),('Q3中继架次','relays'),('Q3通信保障','comms')]:
        ws=book[name];rows=list(ws.iter_rows(min_row=2,values_only=True));assert len(rows)==len(d[key])
        for actual,want in zip(rows,d[key]):
            for x,y in zip(actual,want.values()):
                if isinstance(y,(int,float)):assert abs(x-y)<1e-7
                else:assert (x or '')==(y or '')
    tpl=load_workbook(OUT/'问题三_结果提交模板.xlsx',data_only=True)
    assert tpl['Q3_中继架次'].cell(2,1).value=='Q3-R001'
    assert abs(sum(tpl['Q3_中继架次'].cell(r,11).value for r in range(2,len(d['relays'])+2))-sum(r['架次能耗kWh'] for r in d['relays']))<1e-8
    erosion=[]
    for delta in [0.,.05,.1,.5,1.,2.]:
        lost=[r for r in d['certs'] if r['余量下界dB']<delta]
        erosion.append(dict(额外损耗dB=delta,原证明失效区间数=len(lost),失去保证的运输累计秒=sum(r['结束s']-r['开始s'] for r in lost),解释='失去保守保证不等于实际必然断联；不是重新优化结果'))
    dumpcsv(OUT/'Q3_链路余量侵蚀分析.csv',erosion)
    result=dict(status='COMPLETE',checks=s['checks'],independent_points=len(readcsv(OUT/'Q3_独立射线复核.csv')),failed=0,workbook_values_match=True,continuous_certificate_scope='piecewise-constant DEM and specified propagation model',global_optimality_proved=False)
    (OUT/'Q3_COMPLETE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(result))
if __name__=='__main__':main()
