from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from q3_engine import World
OUT=Path(__file__).resolve().parent
def main():
    d=json.loads((OUT/'work'/'best.json').read_text(encoding='utf8'));w=World()
    plt.style.use(OUT/'release'/'nature-project.mplstyle')
    plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.labelsize':8,'axes.titlesize':8,'legend.fontsize':7,'pdf.fonttype':42})
    def save(fig,n):
        fig.canvas.draw();fig.savefig(OUT/(n+'.png'),dpi=300);fig.savefig(OUT/(n+'.pdf'));plt.close(fig)
    palette=['#4F86C6','#2A9D8F','#7B6FB3','#E08B3E','#8E6C4F','#C77DA5','#587D5A'];names=[f'P{i+1}' for i in range(len(d['sites']))]
    fig,ax=plt.subplots(figsize=(18/2.54,13/2.54));fig.subplots_adjust(left=.10,right=.86,bottom=.10,top=.97)
    dem=w.dem;im=ax.imshow(dem.array,extent=[dem.tie_lon-dem.pixel_lon/2,dem.tie_lon+(dem.width-.5)*dem.pixel_lon,dem.tie_lat-(dem.height-.5)*dem.pixel_lat,dem.tie_lat+dem.pixel_lat/2],cmap='Greys',alpha=.42,origin='upper')
    for t in d['transports']:
        ns=['O01']+t['stops']+['O01'];p=np.array([w.point(w.byid[x]) for x in ns]);ax.plot(p[:,0],p[:,1],color='#666666',lw=.5,alpha=.4)
    for n in w.nodes:
        p=w.point(n);ax.scatter(*p[:2],s=15,c='black' if n.node_id!='O01' else '#D73027',marker='o' if n.node_id!='O01' else '*');ax.annotate(n.node_id,p[:2],xytext=(4,4),textcoords='offset points',fontsize=7)
    for i,s in enumerate(d['sites']):
        ax.scatter(s['lon'],s['lat'],s=55,marker='^',c=palette[i],edgecolors='white',zorder=5)
        offset=(-18,7) if abs(s['lon']-109.237)<.001 else (6,-10)
        ax.annotate(names[i],(s['lon'],s['lat']),xytext=offset,textcoords='offset points',color=palette[i],fontsize=8)
        ax.plot([w.o[0],s['lon']],[w.o[1],s['lat']],ls='--',color=palette[i],lw=1)
    ax.set_aspect(1/np.cos(np.deg2rad(23.04)));ax.set_xlim(109.155,109.305);ax.set_ylim(22.995,23.09);ax.set_xlabel('Longitude (degrees E)');ax.set_ylabel('Latitude (degrees N)');ax.set_title('Transport routes and time-shared relay sites')
    cax=fig.add_axes([.89,.20,.02,.58]);fig.colorbar(im,cax=cax,label='Terrain elevation (m)');save(fig,'Q3_路线与中继点位')
    fig,ax=plt.subplots(figsize=(18/2.54,15/2.54));fig.subplots_adjust(left=.1,right=.98,bottom=.12,top=.85)
    rows=[f'U{i:02d}' for i in range(1,9)]+['R01','R02'];idx={x:i for i,x in enumerate(rows)}
    for j,t in enumerate(d['transports']):
        a=t['start']/3600;b=t['end']/3600;ax.barh(idx[t['drone']],b-a,left=a,height=.60,color='#98B7D0',edgecolor='white',lw=.5);ax.text((a+b)/2,idx[t['drone']],f'T{j+1:02d}',ha='center',va='center',fontsize=7)
    for r in d['relays']:
        y=idx[r['drone']];a,b,c,e=[r[x]/3600 for x in ['start','service_start','service_end','end']];ax.barh(y,e-a,left=a,height=.62,color='#DADADA',edgecolor='white');ax.barh(y,c-b,left=b,height=.62,color=palette[r['site']],edgecolor='white');ax.text((b+c)/2,y,'R'+str(int(r['id'].split('R')[-1])),fontsize=7,ha='center',va='center',color='white');ax.barh(y,300/3600,left=e,height=.62,color='white',edgecolor='#888888',hatch='///',lw=.4)
    ax.set_yticks(range(10),rows);ax.invert_yaxis();ax.set_xlabel('Time after emergency dispatch (h)');ax.set_title('Joint aircraft schedule including relay turnaround');ax.grid(axis='x',color='#eeeeee');ax.set_axisbelow(True)
    fig.legend(handles=[Patch(color='#98B7D0',label='Transport'),Patch(color='#DADADA',label='Relay travel / setup')]+[Patch(color=palette[i],label=names[i]+' service') for i in range(len(names))]+[Patch(facecolor='white',edgecolor='#888',hatch='///',label='Turnaround')],loc='upper center',bbox_to_anchor=(.5,.99),ncol=4,frameon=False);save(fig,'Q3_联合资源甘特图')
    fig,ax=plt.subplots(figsize=(18/2.54,15/2.54));fig.subplots_adjust(left=.12,right=.98,bottom=.1,top=.86)
    for i,t in enumerate(d['transports']):
        for c in t['certificates']:
            color='#BBBBBB' if c['site']<0 else palette[c['site']];ax.barh(i,(c['end']-c['start'])/3600,left=(t['start']+c['start'])/3600,height=.65,color=color,linewidth=0)
    ax.set_yticks(range(len(d['transports'])),[f'T{i+1:02d}' for i in range(len(d['transports']))]);ax.invert_yaxis();ax.set_xlabel('Time after emergency dispatch (h)');ax.set_title('Certified direct coverage and reserved relay support');ax.grid(axis='x',color='#eee');ax.set_axisbelow(True)
    fig.legend(handles=[Patch(color='#BBB',label='Direct')]+[Patch(color=palette[i],label=names[i]+' relay') for i in range(len(names))],loc='upper center',bbox_to_anchor=(.5,.99),ncol=4,frameon=False);save(fig,'Q3_连续通信保障图')
    print('THREE_FIGURES_EXPORTED')
if __name__=='__main__':main()
