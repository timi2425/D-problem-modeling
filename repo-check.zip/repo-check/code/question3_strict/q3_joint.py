"""Finite candidate-set joint heuristic; no global optimality assertion.
Uses continuous radio interval certificates, full aircraft/component schedules.
"""
from q3_solve import *
from collections import defaultdict, Counter

def relay_physics(w,s):
    p=np.array([s['lon'],s['lat'],s['altitude']]);ground=w.dem.nearest(*p[:2]);r=w.r
    if not 0<p[2]-ground<=r.max_hover_agl_m+1e-8:raise ValueError('AGL')
    H=w.terrain_max(w.o,p)+50
    if p[2]>H+1e-8:raise ValueError('Hover altitude exceeds stipulated DEM maximum + 50 m')
    d=float(w.dist(np.r_[w.o[:2],0],np.r_[p[:2],0]))
    up0=H-w.o[2];down0=H-p[2];up1=H-p[2];down1=H-w.o[2]
    tout=up0/r.climb_speed_mps+d/r.cruise_speed_mps+down0/r.descend_speed_mps
    tback=up1/r.climb_speed_mps+d/r.cruise_speed_mps+down1/r.descend_speed_mps
    E=2*r.cruise_power_kw*d/r.cruise_speed_mps/3600+r.takeoff_mass_kg*f.G*(up0+up1)/r.climb_efficiency/3600000
    watts=r.hover_power_kw+r.communication_power_kw
    capacity=((1-r.return_soc_min)*r.energy_kwh-E)*3600/watts-r.link_setup_s
    result=dict(s);result.update(point=p.tolist(),travel_out=tout,travel_back=tback,lead=r.prep_s+tout+r.link_setup_s,travel_energy=E,max_service=capacity,backhaul=w.certificate(w.gateway,p,p,'backhaul')[0]);return result

def certificates(w,v,sites):
    rows=[]
    def recurse(ph,t0,t1,a,b):
        d,proof=w.certificate(w.gateway,a,b,'direct')
        if d>=.02:
            rows.append(dict(phase=ph['phase'],start=t0,end=t1,site=-1,margin=d,proof=proof,p0=a.tolist(),p1=b.tolist()));return
        ms=[w.certificate(np.array(s['point']),a,b,'access') for s in sites]
        choices=[i for i in range(len(ms)) if min(ms[i][0],sites[i]['backhaul'])>=.02]
        # North is a fallback; prefer temporal subdivision before invoking it.
        if not choices and t1-t0>2:
            mid=(a+b)/2;t=(t0+t1)/2;recurse(ph,t0,t,a,mid);recurse(ph,t,t1,mid,b);return
        idx=max(choices or range(len(ms)),key=lambda i:min(ms[i][0],sites[i]['backhaul']))
        m=min(ms[idx][0],sites[idx]['backhaul'])
        if m>=.02:
            rows.append(dict(phase=ph['phase'],start=t0,end=t1,site=idx,margin=m,proof=ms[idx][1],p0=a.tolist(),p1=b.tolist()));return
        if t1-t0<.0625:raise ValueError('uncertified interval')
        mid=(a+b)/2;t=(t0+t1)/2;recurse(ph,t0,t,a,mid);recurse(ph,t,t1,mid,b)
    for ph in v['phases']:recurse(ph,ph['start'],ph['end'],np.array(ph['p0']),np.array(ph['p1']))
    return rows

def relay_schedule(w,transports,sites,gap=600):
    demands=defaultdict(list)
    for tr in transports:
        for c in tr['certificates']:
            if c['site']>=0:demands[c['site']].append((tr['start']+c['start'],tr['start']+c['end']))
    missions=[]
    for k,ints in demands.items():
        s=sites[k];merged=[]
        for a,b in sorted(ints):
            if merged and a<=merged[-1][1]+gap and max(b,merged[-1][1])-merged[-1][0]<=s['max_service']-1:
                merged[-1][1]=max(merged[-1][1],b)
            else:merged.append([a,b])
        for a,b in merged:
            if b-a>s['max_service']-1:return None
            begin=a-s['lead'];end=b+s['travel_back'];energy=s['travel_energy']+(b-a+w.r.link_setup_s)*(w.r.hover_power_kw+w.r.communication_power_kw)/3600
            if begin<-1e-7:return None
            soc=1-energy/w.r.energy_kwh
            missions.append(dict(site=k,start=max(begin,0),service_start=a,service_end=b,end=end,energy=energy,soc=soc,drone_ready=end+w.r.turnaround_s,component_ready=end+f.charge_time_s(soc,1800)))
    missions.sort(key=lambda m:m['start']);dr=[0.,0.];comp=[0.]*6
    for j,m in enumerate(missions):
        di=min(range(2),key=lambda i:dr[i]);ci=min(range(6),key=lambda i:comp[i])
        if dr[di]>m['start']+1e-7 or comp[ci]>m['start']+1e-7:return None
        dr[di]=m['drone_ready'];comp[ci]=m['component_ready'];m.update(id=f'Q3-R{j+1:03d}',drone=f'R{di+1:02d}',component=f'RE-{ci+1:02d}')
    return missions

def schedule(w,variants,sites,order,gap=600):
    dr={m:[0.]*n for m,n in [('A',4),('B',2),('C',2)]};bt={m:[0.]*n for m,n in [('A',6),('B',4),('C',4)]}
    full={'A':1800,'B':2400,'C':3000};names={'A':['U01','U02','U03','U04'],'B':['U05','U06'],'C':['U07','U08']};placed=[]
    for ix in order:
        options=[]
        for v in variants[ix]:
            g=v['model'];di=min(range(len(dr[g])),key=lambda i:dr[g][i]);bi=min(range(len(bt[g])),key=lambda i:bt[g][i])
            earliest=max(dr[g][di],bt[g][bi]);latest=min((hard_deadline(w.boxes[x])-t for x,t in v['deliveries'].items()),default=math.inf)
            lead=max([0.]+[sites[c['site']]['lead']-c['start'] for c in v['certificates'] if c['site']>=0]);earliest=max(earliest,lead)
            for t in np.arange(math.ceil(earliest/20)*20,min(latest,36000)+.1,20):
                tr=dict(v,start=float(t),end=float(t)+v['duration'],drone=names[g][di],battery=f'{g}-BAT-{bi+1:02d}',base_index=ix)
                relays=relay_schedule(w,placed+[tr],sites,gap)
                if relays is None:continue
                late=sum(b['应急优先系数']*max(0,t+v['deliveries'][x]-b['期望送达时间（s）']) for x,b in w.boxes.items() if x in v['deliveries'] and b['物资类型']!='医疗物资')
                joint=max([tr['end']]+[p['end'] for p in placed]+[r['end'] for r in relays])
                options.append((0,tr,di,bi,relays))
                break
        if not options:
            if getattr(w,'debug',False):print('FAILED route',ix,'placed',len(placed),'sites',[(i['stops'],set(c['site'] for c in i['certificates'])) for i in variants[ix]],flush=True)
            return None
        # candidate priority: tardiness, incremental work, and fleet finishing time.
        scored=[]
        for _,tr,di,bi,rr in options:
            late=sum(w.boxes[x]['应急优先系数']*max(0,tr['start']+off-w.boxes[x]['期望送达时间（s）']) for x,off in tr['deliveries'].items() if w.boxes[x]['物资类型']!='医疗物资')
            score=late/10000+tr['end']/200+tr['energy']*2+sum(r['energy'] for r in rr)
            scored.append((score,tr,di,bi,rr))
        _,tr,di,bi,rr=min(scored,key=lambda x:x[0]);g=tr['model'];dr[g][di]=tr['end'];bt[g][bi]=tr['end']+f.charge_time_s(tr['soc'],full[g]);placed.append(tr)
    relays=relay_schedule(w,placed,sites,gap)
    late=sum(w.boxes[x]['应急优先系数']*max(0,tr['start']+off-w.boxes[x]['期望送达时间（s）']) for tr in placed for x,off in tr['deliveries'].items() if w.boxes[x]['物资类型']!='医疗物资')
    makespan=max([p['end'] for p in placed]+[r['end'] for r in relays]);te=sum(t['energy'] for t in placed);re=sum(r['energy'] for r in relays)
    denom=sum(b['应急优先系数']*b['期望送达时间（s）'] for b in w.boxes.values() if b['物资类型']!='医疗物资')
    score=.5*late/denom+.2*makespan/14400+.2*(te+re)/70+.1*(len(placed)+len(relays))/25
    return dict(transports=placed,relays=relays,sites=sites,weighted_late=late,makespan=makespan,transport_energy=te,relay_energy=re,score=score,gap=gap)

def main():
    w=World();ss=json.loads((OUT/'work'/'sites.json').read_text(encoding='utf8'));sites=[relay_physics(w,s) for s in ss]
    variants=[];bases=q2_routes(w)
    for v in bases:
        vs=[]
        for m in w.mod:
            for perm in itertools.permutations(v['stops']):
                ev=w.evaluate(v['boxes'],perm,m)
                if ev:
                    try:ev['certificates']=certificates(w,ev,sites);vs.append(ev)
                    except ValueError:pass
        variants.append(vs)
    print('route alternatives',list(map(len,variants)),flush=True)
    best=None;history=[];rng=random.Random(20260924)
    for k in range(150):
        order=sorted(range(len(bases)),key=lambda i:(min(hard_deadline(w.boxes[x]) for x in bases[i]['boxes']),min(w.boxes[x]['期望送达时间（s）'] for x in bases[i]['boxes'])*rng.uniform(.7,1.3)))
        ans=schedule(w,variants,sites,order,gap=[0,120,300,600,1000][k%5])
        if ans:
            history.append(dict(iteration=k,score=ans['score'],makespan=ans['makespan'],weighted_late=ans['weighted_late'],energy=ans['transport_energy']+ans['relay_energy'],relay_sorties=len(ans['relays'])))
            if best is None or ans['score']<best['score']:
                best=ans;(OUT/'work'/'best.json').write_text(json.dumps(best,ensure_ascii=False,indent=2),encoding='utf8');print('best',history[-1],flush=True)
        if k%10==0:print('iteration',k,'feasible',len(history),flush=True)
    dumpcsv(OUT/'Q3_候选权衡.csv',history)
    if best is None:raise RuntimeError('No feasible joint schedule found')
    print('FINISHED',best['score'],flush=True)

if __name__=='__main__':
    import runpy
    runpy.run_path(str(BASE/'08_任务书严格修订'/'strict_fixed_sites.py'),run_name='__main__')
