"""Additional release gates independent of cached resource-ready fields."""
from pathlib import Path
import json
import math
from collections import defaultdict
from q3_engine import World, SOURCE, f, dumpcsv

OUT = Path(__file__).resolve().parent


def audit_candidate(d, w):
    checks = []

    def ck(name, passed, evidence):
        checks.append(dict(检查项=name, 状态='PASS' if passed else 'FAIL', 证据=str(evidence)))

    _, _, fleet, stock = f.parse_models(SOURCE)
    drone_models = {r['无人机编号']: r['机型编号'] for r in fleet if '无人机编号' in r}
    relay_ids = {r['中继无人机编号'] for r in fleet if '中继无人机编号' in r}
    battery_ids, full_times = {}, {}
    for r in stock:
        g = r['机型编号']
        full_times[g] = float(r['等效完全充电时间（s）'])
        if g != 'R':
            battery_ids[g] = {f'{g}-BAT-{i:02d}' for i in range(1, int(r['共享电池组总数（组）']) + 1)}
        else:
            component_ids = {f'RE-{i:02d}' for i in range(1, int(r['共享能源组件总数（组）']) + 1)}
    transport_intervals, energy_intervals = defaultdict(list), defaultdict(list)
    relay_intervals, component_intervals = defaultdict(list), defaultdict(list)
    delivered = []
    for i, t in enumerate(d['transports'], 1):
        tag = f'T{i:03d}'
        ck(tag+'实体机型匹配', drone_models.get(t['drone']) == t['model'], t['drone'])
        ck(tag+'电池机型及库存编号', t['battery'] in battery_ids[t['model']], t['battery'])
        ck(tag+'非负有限时间', all(math.isfinite(t[k]) for k in ['start', 'end']) and 0 <= t['start'] < t['end'], (t['start'], t['end']))
        dest = {w.boxes[x]['服务区编号'] for x in t['boxes']}
        ck(tag+'访问覆盖及无重复站', set(t['stops']) == dest and len(t['stops']) == len(dest), t['stops'])
        v = w.evaluate(t['boxes'], t['stops'], t['model'])
        ck(tag+'实际交付货箱集合', v is not None and set(v['deliveries']) == set(t['boxes']), len(t['boxes']))
        if v is None:
            continue
        delivered.extend(v['deliveries'])
        ck(tag+'缓存SOC一致', abs(v['soc'] - t['soc']) < 1e-9, v['soc'])
        transport_intervals[t['drone']].append((t['start'], t['start']+v['duration']))
        energy_intervals[t['battery']].append((t['start'], t['start']+v['duration']+f.charge_time_s(v['soc'], full_times[t['model']])))
        for c in t['certificates']:
            ck(tag+'通信区间正长度', c['end'] > c['start'], (c['start'], c['end']))
    ck('交付事件恰好覆盖原始80箱', len(delivered) == len(w.boxes) and len(set(delivered)) == len(w.boxes) and set(delivered) == set(w.boxes), len(delivered))
    for r in d['relays']:
        tag = r['id']
        ck(tag+'中继编号合法', r['drone'] in relay_ids, r['drone'])
        ck(tag+'组件编号合法', r['component'] in component_ids, r['component'])
        ck(tag+'任务时序合法', all(math.isfinite(r[k]) for k in ['start','service_start','service_end','end']) and 0 <= r['start'] < r['service_start'] < r['service_end'] < r['end'], r['start'])
        ck(tag+'周转截止独立重算', abs(r['drone_ready']-r['end']-w.r.turnaround_s)<1e-8, r['drone_ready'])
        soc = 1-r['energy']/w.r.energy_kwh
        ck(tag+'中继SOC及下限', abs(soc-r['soc'])<1e-9 and w.r.return_soc_min<=soc<=1, soc)
        relay_intervals[r['drone']].append((r['start'], r['end']+w.r.turnaround_s))
        component_intervals[r['component']].append((r['start'], r['end']+f.charge_time_s(soc,full_times['R'])))
    for label, groups in [('运输实体机',transport_intervals),('运输电池',energy_intervals),('中继实体机',relay_intervals),('中继组件',component_intervals)]:
        for key, ints in groups.items():
            ints.sort()
            ck(label+key+'独立占用重算', all(b[0]>=a[1]-1e-7 for a,b in zip(ints,ints[1:])), len(ints))
    ck('中继架次编号唯一', len({r['id'] for r in d['relays']})==len(d['relays']),len(d['relays']))
    return checks


def main():
    d=json.loads((OUT/'work/best.json').read_text(encoding='utf8'))
    checks=audit_candidate(d,World())
    dumpcsv(OUT/'Q3_发布补充复核.csv',checks)
    failures=[r for r in checks if r['状态']!='PASS']
    print('RELEASE_AUDIT',len(checks),'FAILED',len(failures))
    if failures: raise AssertionError(failures)


if __name__=='__main__':main()
