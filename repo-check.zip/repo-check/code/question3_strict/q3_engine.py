"""Q3 deterministic geometry, directional radio budgets and continuous interval certificates.

Coordinates for raster intersections are PixelIsPoint centers; each sample owns
a closed square +/-0.5 pixel. Terrain is piecewise constant at its DEM value.
No interpolation or real-world atmospheric effects beyond the task are added.
"""
from pathlib import Path
import sys, math, csv, os
import numpy as np
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'01_数据与物理底座'))
import q1_foundation as f
SOURCE=Path(os.environ.get('Q3_SOURCE_ROOT', r'G:\数学建模大赛\中文题目\D'))

def readcsv(p):
    with open(p,encoding='utf-8-sig',newline='') as h:return list(csv.DictReader(h))
def dumpcsv(p,rows):
    if not rows:return
    with open(p,'w',encoding='utf-8-sig',newline='') as h:
        w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

class World:
    def __init__(self):
        self.nodes=f.parse_nodes(SOURCE);self.byid={n.node_id:n for n in self.nodes}
        self.models,self.relays,_,_=f.parse_models(SOURCE);self.mod={m.model_id:m for m in self.models};self.r=self.relays[0]
        self.dem=f.DemGrid(next((SOURCE/'数据').rglob('*.tif')))
        self.o=self.point(self.byid['O01']);self.gateway=self.o.copy();self.gateway[2]+=20
        self.boxes={b['货箱编号']:b for b in f.parse_boxes(SOURCE)[1]}
        params=readcsv(BASE/'01_数据与物理底座'/'communication_parameters_raw.csv')
        self.params={(r['参数类别'],r['参数名称']):float(r['参数值']) for r in params}
        p=self.params
        self.freq=p['传播参数','载波频率（MHz）'];self.obs=p['传播参数','地形遮挡附加损耗（dB）']
        th=p['接收参数','接收灵敏度（dBm）']+p['接收参数','衰落裕量（dB）']
        self.budgets={};self.directional=[]
        for key,a,b in [('direct','运输无人机','固定网关 G01'),('access','运输无人机','中继接入端'),('backhaul','中继回传端','固定网关 G01')]:
            gains=p[a,'天线增益（dBi）']+p[b,'天线增益（dBi）']
            ab=p[a,'发射功率（dBm）']+gains-p['传播参数','系统损耗（dB）']-th
            ba=p[b,'发射功率（dBm）']+gains-p['传播参数','系统损耗（dB）']-th
            self.budgets[key]=min(ab,ba)
            self.directional.append(dict(link=key,forward_db=ab,reverse_db=ba,bidirectional_db=min(ab,ba)))
        self.arcs={};self.corrections=[]
        for a in self.nodes:
            for b in self.nodes:
                if a==b:continue
                old,n=self.dem.line_cells_max(a,b);mx=self.terrain_max(self.point(a),self.point(b))
                H=mx+50
                if H<max(a.operation_height_m,b.operation_height_m):raise ValueError('cruise below endpoint')
                self.arcs[a.node_id,b.node_id]=dict(from_node=a.node_id,to_node=b.node_id,horizontal_distance_m=f.horizontal_distance_m(a,b),max_dem_m=mx,cruise_altitude_m=H,climb_m=H-a.operation_height_m,descent_m=H-b.operation_height_m)
                if mx>old+1e-6:self.corrections.append(dict(start=a.node_id,end=b.node_id,old_max_m=old,new_max_m=mx,delta_m=mx-old))
    def point(self,n):return np.array([n.lon_deg,n.lat_deg,n.operation_height_m])
    def cell(self,p):return np.array(self.dem.index(p[0],p[1]))
    def geo(self,c,r,z):return np.array([self.dem.tie_lon+c*self.dem.pixel_lon,self.dem.tie_lat-r*self.dem.pixel_lat,z])
    def line_cells(self,p,q):
        a=self.cell(p);b=self.cell(q);delta=b-a;ts=[0.,1.]
        for k in (0,1):
            if abs(delta[k])<1e-12:continue
            lo,hi=sorted([a[k],b[k]])
            bounds=np.arange(math.ceil(lo-.5),math.floor(hi-.5)+1)+.5
            ts.extend(((bounds-a[k])/delta[k]).tolist())
        ts=np.unique(np.clip(ts,0,1));t=(ts[:-1]+ts[1:])/2
        # Interval interiors plus boundary contacts, including corner-touch cells.
        center=a[None,:]+t[:,None]*delta
        cells={tuple(x) for x in np.floor(center+.5).astype(int)}
        for ti in ts:
            pos=a+ti*delta
            xs={math.floor(pos[0]+.5),math.floor(pos[0]+.5-1e-10)}
            ys={math.floor(pos[1]+.5),math.floor(pos[1]+.5-1e-10)}
            cells.update((x,y) for x in xs for y in ys)
        cells=np.array(sorted(cells),int)
        if (cells[:,0]<0).any() or (cells[:,0]>=self.dem.width).any() or (cells[:,1]<0).any() or (cells[:,1]>=self.dem.height).any():raise ValueError('DEM out of bounds')
        return cells
    def terrain_max(self,p,q):
        # All questions share the same exact traversed-pixel implementation.
        a=f.Node('a','',float(p[0]),float(p[1]),float(p[2]),None,'origin');b=f.Node('b','',float(q[0]),float(q[1]),float(q[2]),None,'origin')
        cells=self.dem.line_cells(a,b);z=self.dem.array[cells[:,1],cells[:,0]]
        if not np.isfinite(z).all() or (z==-32767).any():raise ValueError('DEM NoData')
        return float(z.max())
    def dist(self,p,q):
        # Spherical horizontal metric consistent with the inherited physical engine.
        p=np.asarray(p);q=np.asarray(q)
        lat1=np.radians(p[...,1]);lat2=np.radians(q[...,1]);dl=np.radians(q[...,0]-p[...,0]);da=lat2-lat1
        h=2*f.EARTH_RADIUS_M*np.arcsin(np.sqrt(np.clip(np.sin(da/2)**2+np.cos(lat1)*np.cos(lat2)*np.sin(dl/2)**2,0,1)))
        return np.hypot(h,q[...,2]-p[...,2])
    def fspl(self,d):return 32.45+20*np.log10(self.freq)+20*np.log10(np.maximum(d,1e-6)/1000)
    def sample_margin(self,anchor,points,kind):
        # Fast screening only. Final feasibility uses swept-ray certificates below.
        points=np.asarray(points);a=self.cell(anchor);c=(points[:,0]-self.dem.tie_lon)/self.dem.pixel_lon;r=(self.dem.tie_lat-points[:,1])/self.dem.pixel_lat
        n=max(2,int(np.ceil(max(np.max(abs(c-a[0])),np.max(abs(r-a[1])))*4)))
        u=np.linspace(0,1,n+1)[None,:]
        cs=np.floor(a[0]+(c-a[0])[:,None]*u+.5).astype(int);rs=np.floor(a[1]+(r-a[1])[:,None]*u+.5).astype(int)
        land=self.dem.array[np.clip(rs,0,self.dem.height-1),np.clip(cs,0,self.dem.width-1)]
        z=anchor[2]+(points[:,2]-anchor[2])[:,None]*u
        blocked=np.any(land>z+1e-8,axis=1)
        return self.budgets[kind]-self.fspl(self.dist(anchor,points))-self.obs*blocked
    def certificate(self,anchor,p0,p1,kind):
        """Conservative bound for EVERY point on a moving affine trajectory interval.

        At ray parameter u, the ray to any moving endpoint lies inside the
        coordinatewise envelope anchor+u*[min(p0,p1)-anchor,max(p0,p1)-anchor].
        For each potentially intersected closed DEM cell find a superset u range.
        Lower-bound ray height over that range. If all cells clear, obstruction=0;
        otherwise charge 10 dB (safe even if an actual obstruction is absent).
        Spherical distance is bounded by a coordinate-line length with maximum
        cos(latitude) over the interval, plus vertical separation. No temporal
        gaps or empirical point-sampling continuity assumption are used.
        """
        a=self.cell(anchor);p=self.cell(p0);q=self.cell(p1)
        latmin=min(anchor[1],p0[1],p1[1]);latmax=max(anchor[1],p0[1],p1[1]);cosmax=1 if latmin<=0<=latmax else max(math.cos(math.radians(latmin)),math.cos(math.radians(latmax)))
        dx=max(abs(p0[0]-anchor[0]),abs(p1[0]-anchor[0]))*math.pi/180*f.EARTH_RADIUS_M*cosmax
        dy=max(abs(p0[1]-anchor[1]),abs(p1[1]-anchor[1]))*math.pi/180*f.EARTH_RADIUS_M
        dz=max(abs(p0[2]-anchor[2]),abs(p1[2]-anchor[2]));distmax=math.sqrt(dx*dx+dy*dy+dz*dz)
        fs=float(self.fspl(distmax));blocked_margin=self.budgets[kind]-fs-self.obs
        if blocked_margin>=0:return blocked_margin,'遮挡损耗上界'
        xmin,xmax=int(math.floor(min(a[0],p[0],q[0])+.5-1e-9)),int(math.floor(max(a[0],p[0],q[0])+.5))
        ymin,ymax=int(math.floor(min(a[1],p[1],q[1])+.5-1e-9)),int(math.floor(max(a[1],p[1],q[1])+.5))
        xmin=max(0,xmin);xmax=min(self.dem.width-1,xmax);ymin=max(0,ymin);ymax=min(self.dem.height-1,ymax)
        yy,xx=np.mgrid[ymin:ymax+1,xmin:xmax+1];lo=np.zeros(xx.shape);hi=np.ones(xx.shape)
        for grid,k in ((xx,0),(yy,1)):
            dmin=min(p[k],q[k])-a[k];dmax=max(p[k],q[k])-a[k]
            # u*dmax >= cell_low-a; u*dmin <= cell_high-a
            for coef,rhs,greater in ((dmax,grid-.5-a[k],True),(dmin,grid+.5-a[k],False)):
                if abs(coef)<1e-14:
                    hi=np.where((rhs<=1e-10) if greater else (rhs>=-1e-10),hi,-1)
                elif (coef>0)==greater:lo=np.maximum(lo,rhs/coef)
                else:hi=np.minimum(hi,rhs/coef)
        use=lo<=hi+1e-10
        zd=min(p0[2],p1[2])-anchor[2]
        zlow=anchor[2]+zd*(lo if zd>=0 else hi)
        ground=self.dem.array[ymin:ymax+1,xmin:xmax+1]
        clear=bool(np.all((ground<=zlow+1e-8)|~use))
        return self.budgets[kind]-fs-(0 if clear else self.obs),('全区间视距证明' if clear else '遮挡损耗上界')

    def evaluate(self,ids,stops,model_id):
        m=self.mod[model_id];load=sum(self.boxes[x]['单箱质量（kg）'] for x in ids);vol=sum(self.boxes[x]['单箱体积（m³）'] for x in ids)
        if load>m.max_payload_kg+1e-8 or vol>m.volume_m3+1e-10:return None
        now=m.prep_s+len(ids)*m.load_box_s;energy=0.;phases=[];deliveries={};current='O01'
        for dest in list(stops)+['O01']:
            arc=self.arcs[current,dest];p=self.point(self.byid[current]);q=self.point(self.byid[dest]);z=arc['cruise_altitude_m']
            highp=p.copy();highp[2]=z;highq=q.copy();highq[2]=z
            durations=[arc['climb_m']/m.climb_speed_mps,arc['horizontal_distance_m']/m.cruise_speed_mps,arc['descent_m']/m.descend_speed_mps]
            for name,a,b,dt in zip(['爬升','巡航','下降'],[p,highp,highq],[highp,highq,q],durations):
                if dt>1e-9:phases.append(dict(phase=name,start=now,end=now+dt,p0=a.tolist(),p1=b.tolist(),from_node=current,to_node=dest));now+=dt
            energy+=f.transport_segment_metrics(arc,m,max(load,0))['energy_kwh']
            if dest!='O01':
                group=[x for x in ids if self.boxes[x]['服务区编号']==dest]
                group.sort(key=lambda x:(hard_deadline(self.boxes[x]),self.boxes[x]['期望送达时间（s）'],-self.boxes[x]['应急优先系数'],x))
                begin=now;now+=m.handover_base_s
                for x in group:now+=m.handover_box_s;deliveries[x]=now;load-=self.boxes[x]['单箱质量（kg）']
                phases.append(dict(phase='投送交接',start=begin,end=now,p0=q.tolist(),p1=q.tolist(),from_node=dest,to_node=dest))
            current=dest
        if energy>(1-m.return_soc_min)*m.battery_kwh+1e-9:return None
        return dict(boxes=list(ids),stops=list(stops),model=model_id,duration=now,energy=energy,soc=1-energy/m.battery_kwh,deliveries=deliveries,phases=phases,mass=sum(self.boxes[x]['单箱质量（kg）'] for x in ids),volume=vol)

def hard_deadline(b):
    values=[]
    if b['物资类型']=='医疗物资':values.append(b['期望送达时间（s）'])
    if b['是否首批保障']=='是':values.append(b['首批截止时间（s）'])
    return min(values) if values else math.inf
