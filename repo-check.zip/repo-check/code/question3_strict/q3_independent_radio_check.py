"""Independent slab-intersection LOS check at endpoints and midpoints.
This cross-check supplements, and does not replace, the continuous certificate.
"""
from q3_engine import *
import json
OUT=Path(__file__).resolve().parent

def margin(w,a,b,kind):
    x=w.cell(a);y=w.cell(b);d=y-x;cells=w.line_cells(a,b);lo=np.zeros(len(cells));hi=np.ones(len(cells))
    for k in (0,1):
        if abs(d[k])<1e-12:
            hi=np.where((x[k]>=cells[:,k]-.5-1e-9)&(x[k]<=cells[:,k]+.5+1e-9),hi,-1)
        else:
            s=(cells[:,k]-.5-x[k])/d[k];t=(cells[:,k]+.5-x[k])/d[k];lo=np.maximum(lo,np.minimum(s,t));hi=np.minimum(hi,np.maximum(s,t))
    use=lo<=hi+1e-10
    heights=w.dem.array[cells[:,1],cells[:,0]];ray=np.minimum(a[2]+lo*(b[2]-a[2]),a[2]+hi*(b[2]-a[2]));blocked=bool(np.any((heights>ray+1e-8)&use))
    return w.budgets[kind]-float(w.fspl(w.dist(a,b)))-(w.obs if blocked else 0)

def main():
    w=World();d=json.loads((OUT/'work'/'best.json').read_text(encoding='utf8'));tests=[];minm=math.inf
    for t in d['transports']:
        for j,c in enumerate(t['certificates']):
            anchor=w.gateway if c['site']<0 else np.array(d['sites'][c['site']]['point']);kind='direct' if c['site']<0 else 'access'
            a=np.array(c['p0']);b=np.array(c['p1']);bound,_=w.certificate(anchor,a,b,kind)
            for u in (0.,.5,1.):
                actual=margin(w,anchor,a+(b-a)*u,kind);minm=min(minm,actual)
                tests.append(dict(原始运输序号=t['base_index'],区间=j,位置比例=u,独立链路余量dB=actual,全区间保证下界dB=bound,状态='PASS' if actual>=-1e-8 and actual>=bound-1e-7 else 'FAIL'))
    for s in d['sites']:
        m=margin(w,w.gateway,np.array(s['point']),'backhaul');assert m>=0
    # Analytical same-point and charge-boundary checks.
    assert abs(f.charge_time_s(.9,1800)-630)<1e-8
    assert f.charge_time_s(1.,1800)==0 and abs(f.charge_time_s(0.,1800)-1800)<1e-8
    assert [r['bidirectional_db'] for r in w.directional]==[122.,116.,126.]
    dumpcsv(OUT/'Q3_独立射线复核.csv',tests)
    print('independent points',len(tests),'failures',sum(t['状态']=='FAIL' for t in tests),'minimum_db',minm)
    assert all(t['状态']=='PASS' for t in tests)
if __name__=='__main__':main()
