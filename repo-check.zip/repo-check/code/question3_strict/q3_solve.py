from q3_engine import *
import json, itertools, random, time
OUT=Path(__file__).resolve().parent

def q2_routes(w):
    routes=[]
    for r in readcsv(BASE/'03_问题二'/'Q2_运输架次.csv'):
        v=w.evaluate(r['货箱编号列表'].split(','),r['访问服务区顺序'].split('→'),r['机型编号'])
        if v is None:raise ValueError('Q2 route no longer feasible under exact DEM')
        v['q2_id']=r['架次编号'];routes.append(v)
    return routes

def samples(routes,dt=15):
    pts=[]
    for v in routes:
        for ph in v['phases']:
            n=max(1,math.ceil((ph['end']-ph['start'])/dt))
            a=np.array(ph['p0']);b=np.array(ph['p1']);pts.extend(a+(b-a)*u for u in np.linspace(0,1,n+1))
    return np.unique(np.round(np.array(pts),9),axis=0)

def candidates(w,points):
    margins=w.sample_margin(w.gateway,points,'direct');need=points[margins<1]
    print('points',len(points),'potential relay points',len(need),'min direct',margins.min(),flush=True)
    records=[]
    # Screen 3 altitude levels on a 0.005-degree local grid, then refine best sites.
    for lon in np.arange(109.175,109.3001,.005):
        for lat in np.arange(23.000,23.0851,.005):
            ground=w.dem.nearest(lon,lat)
            for h in (150.,225.,300.):
                p=np.array([lon,lat,ground+h]);back=w.sample_margin(w.gateway,p[None,:],'backhaul')[0]
                if back<0:continue
                m=w.sample_margin(p,need,'access');cover=int(np.sum(m>=0));score=float(m.min())
                records.append(dict(lon=lon,lat=lat,ground=ground,agl=h,altitude=ground+h,covered=cover,total=len(need),min_access_db=score,backhaul_db=float(back)))
    records.sort(key=lambda x:(-x['covered'],-x['min_access_db'],x['agl']))
    dumpcsv(OUT/'Q3_中继选址初筛.csv',records)
    print('best sites',records[:3],flush=True)
    return records

if __name__=='__main__':
    import runpy
    runpy.run_path(str(BASE/'08_任务书严格修订'/'strict_sites.py'),run_name='__main__')
