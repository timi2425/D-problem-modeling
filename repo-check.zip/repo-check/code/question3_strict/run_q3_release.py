"""Rebuild the frozen Q3 release. This does not restart the heuristic search."""
from pathlib import Path
import argparse
import contextlib
import io
import json
import subprocess
import sys

OUT=Path(__file__).resolve().parent
BASE=OUT.parent


def prepare():
    (OUT/'Q3_COMPLETE.json').write_text(json.dumps(dict(status='REBUILDING',version='Q3-20260924-final'),ensure_ascii=False,indent=2),encoding='utf8')
    d=json.loads((OUT/'release/selected_candidate.json').read_text(encoding='utf8'))
    used=sorted({r['site'] for r in d['relays']});index={old:i for i,old in enumerate(used)}
    d['sites']=[d['sites'][i] for i in used]
    for t in d['transports']:
        for c in t['certificates']:
            if c['site']>=0:c['site']=index[c['site']]
    for r in d['relays']:r['site']=index[r['site']]
    (OUT/'work/best.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
    import q3_validate_export as validation
    with contextlib.redirect_stdout(io.StringIO()):validation.main()
    import q3_independent_radio_check as radio
    radio.main()
    import q3_release_audit as extra
    extra.main()
    sys.path.insert(0,str(BASE/'08_任务书严格修订'))
    import write_strict_q3_report as report
    report.main()
    import q3_release_finish as release
    release.write_context()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--node',help='Node executable with @oai/artifact-tool available through node_modules')
    p.add_argument('--prepare-only',action='store_true')
    args=p.parse_args()
    if not args.prepare_only:
        if not args.node:raise SystemExit('For a full rebuild, supply --node PATH')
        import matplotlib
    prepare()
    if args.prepare_only:return
    subprocess.run([args.node,str(OUT/'build_q3_workbooks.mjs')],cwd=OUT,check=True)
    import q3_figures
    q3_figures.main()
    import q3_final_check
    q3_final_check.main()
    import q3_release_finish
    q3_release_finish.finalize()


if __name__=='__main__':main()
