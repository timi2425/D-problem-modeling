r"""Exact solver for Question 1 of the UAV disaster-response problem.

The solver uses the shared physics engine in q1_foundation.py. For each service
zone it enumerates every non-empty box subset, keeps feasible direct round-trip
sorties, and solves an exact lexicographic set-partition problem with bitmask
dynamic programming:

    1. minimum number of sorties;
    2. minimum total transport energy;
    3. minimum cumulative operation time.

Outputs are written to G:\数学建模大赛\D题\02_问题一 by default.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, replace
from functools import lru_cache
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
FOUNDATION_CANDIDATES = [
    HERE / "q1_foundation.py",
    Path(r"G:\数学建模大赛\D题\01_数据与物理底座\q1_foundation.py"),
]
for candidate in FOUNDATION_CANDIDATES:
    if candidate.exists():
        sys.path.insert(0, str(candidate.parent))
        break

from q1_foundation import (  # noqa: E402
    DemGrid,
    Node,
    TransportModel,
    make_arcs,
    parse_boxes,
    parse_models,
    parse_nodes,
    transport_segment_metrics,
)


SAFETY_MARGINS = (0.10, 0.15, 0.20, 0.25, 0.30)
BASE_MARGIN = 0.20
MASS_TOL = 1e-8
VOLUME_TOL = 1e-10
ENERGY_TOL = 1e-9


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    for row in rows:
        for field in row:
            if field not in fields:
                fields.append(field)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


@dataclass(frozen=True)
class Candidate:
    mask: int
    model_id: str
    mass_kg: float
    volume_m3: float
    box_count: int
    energy_kwh: float
    total_time_s: float
    flight_time_s: float
    operation_time_s: float
    return_soc: float
    energy_limit_kwh: float
    safe_payload_kg: float

    @property
    def local_key(self) -> tuple[float, float, str]:
        return (self.energy_kwh, self.total_time_s, self.model_id)


def direct_trip_metrics(
    out_arc: dict[str, Any],
    back_arc: dict[str, Any],
    model: TransportModel,
    payload_kg: float,
    box_count: int,
) -> dict[str, float | bool]:
    outbound = transport_segment_metrics(out_arc, model, payload_kg)
    inbound = transport_segment_metrics(back_arc, model, 0.0)
    energy = float(outbound["energy_kwh"]) + float(inbound["energy_kwh"])
    flight_s = float(outbound["flight_time_s"]) + float(inbound["flight_time_s"])
    operation_s = (
        model.prep_s
        + box_count * model.load_box_s
        + model.handover_base_s
        + box_count * model.handover_box_s
    )
    energy_limit = (1.0 - model.return_soc_min) * model.battery_kwh
    return {
        "flight_time_s": flight_s,
        "operation_time_s": operation_s,
        "total_time_s": flight_s + operation_s,
        "energy_kwh": energy,
        "energy_limit_kwh": energy_limit,
        "return_soc": 1.0 - energy / model.battery_kwh,
        "feasible": energy <= energy_limit + ENERGY_TOL,
    }


def maximum_safe_payload(
    out_arc: dict[str, Any],
    back_arc: dict[str, Any],
    model: TransportModel,
) -> tuple[float, dict[str, float | bool], str]:
    zero = direct_trip_metrics(out_arc, back_arc, model, 0.0, 0)
    if not bool(zero["feasible"]):
        return 0.0, zero, "空载往返能量不可行"
    full = direct_trip_metrics(out_arc, back_arc, model, model.max_payload_kg, 0)
    if bool(full["feasible"]):
        return model.max_payload_kg, full, "额定载质量约束"
    low, high = 0.0, model.max_payload_kg
    for _ in range(80):
        mid = (low + high) / 2.0
        metrics = direct_trip_metrics(out_arc, back_arc, model, mid, 0)
        if float(metrics['energy_kwh']) <= float(metrics['energy_limit_kwh']):
            low = mid
        else:
            high = mid
    result = direct_trip_metrics(out_arc, back_arc, model, low, 0)
    return low, result, "返航安全能量约束"


def arrays_for_boxes(boxes: list[dict[str, Any]]) -> tuple[list[float], list[float], list[int]]:
    n = len(boxes)
    size = 1 << n
    masses = [0.0] * size
    volumes = [0.0] * size
    counts = [0] * size
    for mask in range(1, size):
        bit = mask & -mask
        idx = bit.bit_length() - 1
        prev = mask ^ bit
        masses[mask] = masses[prev] + float(boxes[idx]["单箱质量（kg）"])
        volumes[mask] = volumes[prev] + float(boxes[idx]["单箱体积（m³）"])
        counts[mask] = counts[prev] + 1
    return masses, volumes, counts


def build_candidates(
    boxes: list[dict[str, Any]],
    models: list[TransportModel],
    out_arc: dict[str, Any],
    back_arc: dict[str, Any],
    safe_payloads: dict[str, float],
) -> dict[int, Candidate]:
    masses, volumes, counts = arrays_for_boxes(boxes)
    candidates: dict[int, Candidate] = {}
    for mask in range(1, 1 << len(boxes)):
        mass = masses[mask]
        volume = volumes[mask]
        best: Candidate | None = None
        for model in models:
            if mass > model.max_payload_kg + MASS_TOL:
                continue
            if mass > safe_payloads[model.model_id] + MASS_TOL:
                continue
            if volume > model.volume_m3 + VOLUME_TOL:
                continue
            metrics = direct_trip_metrics(out_arc, back_arc, model, mass, counts[mask])
            if not bool(metrics["feasible"]):
                continue
            candidate = Candidate(
                mask=mask,
                model_id=model.model_id,
                mass_kg=mass,
                volume_m3=volume,
                box_count=counts[mask],
                energy_kwh=float(metrics["energy_kwh"]),
                total_time_s=float(metrics["total_time_s"]),
                flight_time_s=float(metrics["flight_time_s"]),
                operation_time_s=float(metrics["operation_time_s"]),
                return_soc=float(metrics["return_soc"]),
                energy_limit_kwh=float(metrics["energy_limit_kwh"]),
                safe_payload_kg=safe_payloads[model.model_id],
            )
            if best is None or candidate.local_key < best.local_key:
                best = candidate
        if best is not None:
            candidates[mask] = best
    return candidates


def solve_partition(boxes: list[dict[str, Any]], candidates: dict[int, Candidate]) -> tuple[tuple[int, float, float], list[Candidate]]:
    full_mask = (1 << len(boxes)) - 1

    @lru_cache(maxsize=None)
    def dp(mask: int) -> tuple[tuple[int, float, float, tuple[int, ...]], tuple[int, ...]] | None:
        if mask == 0:
            return (0, 0.0, 0.0, ()), ()
        pivot = mask & -mask
        best: tuple[tuple[int, float, float, tuple[int, ...]], tuple[int, ...]] | None = None
        subset = mask
        while subset:
            if subset & pivot and subset in candidates:
                remainder = dp(mask ^ subset)
                if remainder is not None:
                    tail_cost, tail_choice = remainder
                    candidate = candidates[subset]
                    signature = tuple(sorted((subset,) + tail_cost[3]))
                    cost = (
                        1 + tail_cost[0],
                        candidate.energy_kwh + tail_cost[1],
                        candidate.total_time_s + tail_cost[2],
                        signature,
                    )
                    choice = (subset,) + tail_choice
                    if best is None or cost < best[0]:
                        best = cost, choice
            subset = (subset - 1) & mask
        return best

    result = dp(full_mask)
    if result is None:
        raise RuntimeError("no feasible partition for service zone")
    cost, masks = result
    selected = [candidates[mask] for mask in masks]
    selected.sort(key=lambda c: (c.model_id, c.mask))
    return (cost[0], cost[1], cost[2]), selected


def mask_box_ids(mask: int, boxes: list[dict[str, Any]]) -> list[str]:
    return [str(boxes[idx]["货箱编号"]) for idx in range(len(boxes)) if mask & (1 << idx)]


def solve_margin(
    margin: float,
    service_boxes: dict[str, list[dict[str, Any]]],
    base_models: list[TransportModel],
    arc_by_pair: dict[tuple[str, str], dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], dict[str, list[Candidate]]]:
    models = [replace(model, return_soc_min=margin) for model in base_models]
    safe_rows: list[dict[str, Any]] = []
    service_rows: list[dict[str, Any]] = []
    plan_rows: list[dict[str, Any]] = []
    selected_by_service: dict[str, list[Candidate]] = {}
    for service_id in sorted(service_boxes):
        out_arc = arc_by_pair[("O01", service_id)]
        back_arc = arc_by_pair[(service_id, "O01")]
        safe_payloads: dict[str, float] = {}
        for model in models:
            payload, metrics, bottleneck = maximum_safe_payload(out_arc, back_arc, model)
            safe_payloads[model.model_id] = payload
            safe_rows.append({
                "安全余量比例": margin,
                "服务区编号": service_id,
                "机型编号": model.model_id,
                "额定最大载荷kg": model.max_payload_kg,
                "最大安全载荷kg": payload,
                "限制因素": bottleneck,
                "最大安全载荷往返能耗kWh": float(metrics["energy_kwh"]),
                "允许能耗kWh": float(metrics["energy_limit_kwh"]),
                "返航SOC": float(metrics["return_soc"]),
                "水平单程距离m": float(out_arc["horizontal_distance_m"]),
                "巡航海拔m": float(out_arc["cruise_altitude_m"]),
            })
        candidates = build_candidates(service_boxes[service_id], models, out_arc, back_arc, safe_payloads)
        cost, selected = solve_partition(service_boxes[service_id], candidates)
        selected_by_service[service_id] = selected
        model_counts = Counter(candidate.model_id for candidate in selected)
        service_rows.append({
            "安全余量比例": margin,
            "服务区编号": service_id,
            "货箱数": len(service_boxes[service_id]),
            "需求质量kg": sum(float(box["单箱质量（kg）"]) for box in service_boxes[service_id]),
            "需求体积m3": sum(float(box["单箱体积（m³）"]) for box in service_boxes[service_id]),
            "最优架次数": cost[0],
            "总能耗kWh": cost[1],
            "累计作业时间s": cost[2],
            "A型架次": model_counts.get("A", 0),
            "B型架次": model_counts.get("B", 0),
            "C型架次": model_counts.get("C", 0),
            "可行候选子集数": len(candidates),
        })
        for local_idx, candidate in enumerate(selected, 1):
            box_ids = mask_box_ids(candidate.mask, service_boxes[service_id])
            plan_rows.append({
                "安全余量比例": margin,
                "服务区编号": service_id,
                "服务区内架次序号": local_idx,
                "机型编号": candidate.model_id,
                "货箱编号列表": ",".join(box_ids),
                "货箱数": candidate.box_count,
                "总质量kg": candidate.mass_kg,
                "总体积m3": candidate.volume_m3,
                "飞行时间s": candidate.flight_time_s,
                "地面作业时间s": candidate.operation_time_s,
                "往返总时间s": candidate.total_time_s,
                "架次能耗kWh": candidate.energy_kwh,
                "允许能耗kWh": candidate.energy_limit_kwh,
                "返航SOC": candidate.return_soc,
                "最大安全载荷kg": candidate.safe_payload_kg,
                "质量余量kg": candidate.safe_payload_kg - candidate.mass_kg,
                "能量余量kWh": candidate.energy_limit_kwh - candidate.energy_kwh,
            })
    return safe_rows, service_rows, plan_rows, selected_by_service


def validate_base_plan(
    base_plan: list[dict[str, Any]],
    all_boxes: list[dict[str, Any]],
    models: list[TransportModel],
) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    expected_ids = [str(box["货箱编号"]) for box in all_boxes]
    delivered: list[str] = []
    model_map = {model.model_id: model for model in models}
    for trip in base_plan:
        delivered.extend(str(trip["货箱编号列表"]).split(","))
    checks.append({"检查项": "货箱覆盖数量", "状态": "PASS" if len(delivered) == len(expected_ids) else "FAIL", "观测值": len(delivered), "要求": len(expected_ids)})
    checks.append({"检查项": "货箱唯一交付", "状态": "PASS" if len(delivered) == len(set(delivered)) else "FAIL", "观测值": len(delivered) - len(set(delivered)), "要求": 0})
    checks.append({"检查项": "货箱集合一致", "状态": "PASS" if set(delivered) == set(expected_ids) else "FAIL", "观测值": len(set(delivered) ^ set(expected_ids)), "要求": 0})
    box_lookup={b['货箱编号']:b for b in all_boxes}
    crossing=sum(any(box_lookup[x]['服务区编号']!=trip['服务区编号'] for x in trip['货箱编号列表'].split(',')) for trip in base_plan)
    checks.append({"检查项": "不跨服务区组批", "状态": "PASS" if crossing==0 else "FAIL", "观测值": crossing, "要求": 0})
    mass_fail = sum(float(row["质量余量kg"]) < -MASS_TOL for row in base_plan)
    volume_fail = sum(float(row["总体积m3"]) > model_map[str(row["机型编号"])].volume_m3 + VOLUME_TOL for row in base_plan)
    energy_fail = sum(float(row["能量余量kWh"]) < -ENERGY_TOL for row in base_plan)
    soc_fail = sum(float(row["返航SOC"]) < BASE_MARGIN - 1e-9 for row in base_plan)
    checks += [
        {"检查项": "质量约束", "状态": "PASS" if mass_fail == 0 else "FAIL", "观测值": mass_fail, "要求": 0},
        {"检查项": "体积约束", "状态": "PASS" if volume_fail == 0 else "FAIL", "观测值": volume_fail, "要求": 0},
        {"检查项": "能量约束", "状态": "PASS" if energy_fail == 0 else "FAIL", "观测值": energy_fail, "要求": 0},
        {"检查项": "返航SOC约束", "状态": "PASS" if soc_fail == 0 else "FAIL", "观测值": soc_fail, "要求": 0},
    ]
    return checks


def run(root: Path, output_dir: Path) -> dict[str, Any]:
    nodes = parse_nodes(root)
    _, boxes = parse_boxes(root)
    models, _, _, _ = parse_models(root)
    dem = DemGrid(root / "数据" / "镇龙乡地理空间数据" / "镇龙乡及周边地理数据" / "数字高程模型数据（DEM）" / "镇龙乡及周边30米DEM.tif")
    arcs = make_arcs(nodes, dem)
    arc_by_pair = {(row["from_node"], row["to_node"]): row for row in arcs}
    service_boxes: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for box in boxes:
        service_boxes[str(box["服务区编号"])].append(box)
    for service_id in service_boxes:
        service_boxes[service_id].sort(key=lambda row: str(row["货箱编号"]))

    all_safe: list[dict[str, Any]] = []
    all_service: list[dict[str, Any]] = []
    base_plan: list[dict[str, Any]] = []
    sensitivity_summary: list[dict[str, Any]] = []
    for margin in SAFETY_MARGINS:
        safe_rows, service_rows, plan_rows, _ = solve_margin(margin, service_boxes, models, arc_by_pair)
        all_safe.extend(safe_rows)
        all_service.extend(service_rows)
        sensitivity_summary.append({
            "安全余量比例": margin,
            "总架次数": sum(int(row["最优架次数"]) for row in service_rows),
            "总能耗kWh": sum(float(row["总能耗kWh"]) for row in service_rows),
            "累计作业时间s": sum(float(row["累计作业时间s"]) for row in service_rows),
            "A型架次": sum(int(row["A型架次"]) for row in service_rows),
            "B型架次": sum(int(row["B型架次"]) for row in service_rows),
            "C型架次": sum(int(row["C型架次"]) for row in service_rows),
        })
        if abs(margin - BASE_MARGIN) < 1e-12:
            base_plan = plan_rows

    base_plan.sort(key=lambda row: (row["服务区编号"], row["服务区内架次序号"]))
    for idx, row in enumerate(base_plan, 1):
        row["架次编号"] = f"Q1-{idx:03d}"
    # Put the submission fields first without losing the extended audit fields.
    base_plan = [
        {
            "架次编号": row["架次编号"], "服务区编号": row["服务区编号"], "机型编号": row["机型编号"], "货箱编号列表": row["货箱编号列表"],
            "总质量kg": row["总质量kg"], "总体积m3": row["总体积m3"], "往返总时间s": row["往返总时间s"], "架次能耗kWh": row["架次能耗kWh"], "返航SOC": row["返航SOC"],
            **{key: value for key, value in row.items() if key not in {"架次编号", "服务区编号", "机型编号", "货箱编号列表", "总质量kg", "总体积m3", "往返总时间s", "架次能耗kWh", "返航SOC"}},
        }
        for row in base_plan
    ]
    checks = validate_base_plan(base_plan, boxes, models)
    if any(row["状态"] != "PASS" for row in checks):
        raise RuntimeError(f"base plan validation failed: {checks}")

    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "Q1_最大安全载荷_全部敏感性.csv", all_safe)
    write_csv(output_dir / "Q1_服务区优化汇总_全部敏感性.csv", all_service)
    write_csv(output_dir / "Q1_安全余量敏感性汇总.csv", sensitivity_summary)
    write_csv(output_dir / "Q1_单点组批_20pct.csv", base_plan)
    write_csv(output_dir / "Q1_约束检查.csv", checks)

    base_safe = [row for row in all_safe if abs(float(row["安全余量比例"]) - BASE_MARGIN) < 1e-12]
    base_service = [row for row in all_service if abs(float(row["安全余量比例"]) - BASE_MARGIN) < 1e-12]
    summary = {
        "method": "exhaustive feasible subset enumeration + exact bitmask dynamic programming",
        "objective_priority": ["minimum sortie count", "minimum total energy", "minimum cumulative operation time"],
        "base_safety_margin": BASE_MARGIN,
        "services": len(service_boxes),
        "boxes": len(boxes),
        "base_sorties": len(base_plan),
        "base_total_energy_kwh": sum(float(row["架次能耗kWh"]) for row in base_plan),
        "base_total_time_s": sum(float(row["往返总时间s"]) for row in base_plan),
        "min_safe_payload_kg": min(float(row["最大安全载荷kg"]) for row in base_safe),
        "max_safe_payload_kg": max(float(row["最大安全载荷kg"]) for row in base_safe),
        "service_summary": base_service,
        "checks": checks,
    }
    (output_dir / "Q1_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def self_test(root: Path) -> None:
    summary = run(root, Path(r"G:\数学建模大赛\D题\08_任务书严格修订\work\q1_solver_test_out"))
    assert summary["services"] == 15
    assert summary["boxes"] == 80
    assert summary["base_sorties"] > 0
    assert all(check["状态"] == "PASS" for check in summary["checks"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(r"G:\数学建模大赛\中文题目\D"))
    parser.add_argument("--output-dir", type=Path, default=Path(r"G:\数学建模大赛\D题\02_问题一\严格修订版"))
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test(args.root)
        print("SELF_TEST_PASS")
    result = run(args.root, args.output_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
