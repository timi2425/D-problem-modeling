from pathlib import Path
import sys,json,csv,shutil
BASE=Path(__file__).resolve().parent;OUT=BASE
sys.path.insert(0,str(BASE))
from physics import World,f
from validate import validate_candidate

def main():
    w=World();results=[]
    for path in sorted(OUT.glob('*/best.json')):
        if path.parent.name=='selected':continue
        summary=validate_candidate(path,w);assert summary['weighted_late']==0 and summary['failed']==0
        results.append((path,summary))
    assert results
    selected,s=min(results,key=lambda item:(item[1]['makespan'],item[1]['transport_energy'],item[1]['sorties']))
    dest=OUT/'selected';dest.mkdir(exist_ok=True)
    for p in selected.parent.iterdir():
        if p.is_file() and p.name!='search_status.json':shutil.copy2(p,dest/p.name)
    data=json.loads((dest/'workbook_data.json').read_text(encoding='utf8'))
    comparisons=[]
    for label,path in [('22架次低能耗方案',OUT/'results/22_sorties_best.json'),('23架次时间优先方案',OUT/'results/23_sorties_best.json')]:
        d=json.loads(path.read_text(encoding='utf8'));comparisons.append(dict(方案=label,架次数=d['sorties'],完成时间s=d['makespan'],完成时间min=d['makespan']/60,能耗kWh=d['transport_energy'],加权迟到=0,证据='本项目WGS84零迟到方案，已独立复核'))
    comparisons.append(dict(方案='用户提供的外部数字',架次数=24,完成时间s=6043.8,完成时间min=100.73,能耗kWh=67.11,加权迟到=None,证据='仅汇总数字，规则和可行性未知，不作为标准答案'))
    for path,r in results:comparisons.append(dict(方案=path.parent.name,架次数=r['sorties'],完成时间s=r['makespan'],完成时间min=r['makespan']/60,能耗kWh=r['transport_energy'],加权迟到=r['weighted_late'],证据='本轮独立WGS84物理与资源复核通过'))
    f.write_csv(OUT/'方案指标对照.csv',comparisons)
    logs=[]
    for path in OUT.glob('*/search_status.json'):
        d=json.loads(path.read_text(encoding='utf8'));logs.append(dict(搜索=path.parent.name,状态=d['status'],时间预算s=d['seconds'],候选数=d['pool_size'],候选模型时间下界s=d['bound'],能耗上限kWh=d['energycap'],架次上限=d['countcap'],时间上限s=d['timecap']))
    if logs:f.write_csv(OUT/'搜索范围与状态.csv',logs)
    old=next(r for r in comparisons if r['方案']=='23架次时间优先方案');table='\n'.join(f"|{r['方案']}|{r['架次数']}|{r['完成时间min']:.6f}|{r['能耗kWh']:.6f}|{r['加权迟到'] if r['加权迟到'] is not None else '未知'}|" for r in comparisons)
    report=f'''# 第二问速度与能耗联合改进

## 经验证结果

本轮推荐{selected.parent.name}：{s['sorties']}架次，完成时间{s['makespan']:.6f}秒（{s['makespan']/60:.6f}分钟），总能耗{s['transport_energy']:.6f}kWh，加权迟到0。完整80箱交付，医疗和首批硬时限、全部普通箱期望时间、载荷体积、逐像元净空、返航SOC、无人机和电池周转全部复核通过。

|方案|架次数|完成时间min|能耗kWh|加权迟到|
|---|---:|---:|---:|---:|
{table}

相较本项目此前最快零迟到方案，完成时间减少{old['完成时间s']-s['makespan']:.6f}秒（{100*(old['完成时间s']-s['makespan'])/old['完成时间s']:.3f}%），能耗减少{old['能耗kWh']-s['transport_energy']:.6f}kWh（{100*(old['能耗kWh']-s['transport_energy'])/old['能耗kWh']:.3f}%），架次由{old['架次数']}变为{s['sorties']}。和21架次低能耗方案仍存在权衡，不把更快称为所有指标更好。

用户提供的24架次、100.73分钟、67.11kWh只作为探索目标：对方实际规则与逐任务数据未知，无法审计其可行性。本方案的可行性来自对比赛原始数据和本项目物理规则的独立验证，而不是因为数字接近参考。若本方案时间和能耗较低，可报告数值对照，不能由此推断对方是否违规。

## 本轮改变了什么

此前重点围绕21架次、低能耗综合方案搜索，限制了愿意增加少量架次换取较快完成的方案。本轮使用epsilon约束法：将架次数≤24、能耗≤67.11kWh作为搜索预算，主目标最小化完成时间，并单独尝试时间≤6043秒的可行性。预算不是题目规定，而是探索不同权衡的设置；原题所有硬约束不变。

候选池来自14目录35726种计数路线，先删除同货箱计数组合/机型下被另一方案在能耗、时长和允许最迟开始时间上同时支配的路线。相同物理及时限属性箱子保持整数计数，可重复使用相同路线模式；解出后还原全部原始箱号。

直接将全部可选任务放入CP-SAT在限时内未找到新解。随后采用线性规划指导的候选筛选：在6043、6400、7000秒等时间预算下，以最小能耗和均衡机型工作量分别求连续松弛，保留正使用量路线及各货箱类、机型的低约化成本路线，并强制保留已有方案。筛选1858条候选，安全支配删除后实际候选约1572条，使完整资源排程更易搜索。

LP只用于选择有希望的路线；分数货箱、分数架次从不作为最终解。候选筛选可能遗漏其他好解，因此没有全局最优性保证。最终解由整数CP-SAT精确覆盖全部箱类，联合分配起始时间、机型、无人机与共享电池。

资源排程额外加入前缀工作量不等式：每个任务给定允许最迟开始L、占用时长d，在时刻h前至少必须占用min(d,max(0,h-L))秒；按机型汇总不得超过实体机或电池数量乘h。此类约束是原时间窗/资源规则的必要条件，不是额外收紧题目物理规则。它们能提前排除“总能耗低但时间窗内排不下”的组合。

最后对已确定的无人机与电池任务先后顺序做连续时间前移：每个任务从所有资源前驱真实可用时刻的最大值开始。电池前驱包括按实际SOC计算的完整充电时间；任务只提前、不推迟，并重新逐箱验证。由此去除部分保守整数取整空闲，不改变组批或能耗。不能把该固定资源顺序下的最早安排称为所有顺序全局最优。

另试验SCIP组批主问题与CP-SAT资源子问题分解，发现的资源不可行组合没有作为答案交付。UNKNOWN、求解中断、异常终止都不等于证明无解。历史和失败尝试留在搜索目录供审计，不把它们当全局界。

## 物理与验证口径

继续复用13目录WGS84椭球测地距离及逐行列栅格边界求交，不更改原始DEM、节点海拔、容量、速度和能耗参数。240条有向航段已按WGS84与独立GeographicLib复核；本轮所有使用航段在验证时再次独立求距、重组最高地形、飞行及交接时间、能耗与充电时长。

全部货箱期望送达时间均作为硬约束，首批截止更早时取更早者，保证加权迟到严格为0。箱子不可拆、原服务区不变；A/B/C实体机4/2/2、电池6/4/4；满充前不复用。任务准备、逐箱装载、每站基础交接和逐箱交接全部计时。每站交接后重新爬升，载荷随卸货更新，返航空载。末次返航后的充电不计入完成时间，但影响所有此前复用。

选定方案独立复核{s['checks']}项全部通过，最小硬截止余量{s['min_deadline_margin_s']:.6f}秒。用另一距离实现和独立标量公式复核实际任务，而非仅信任求解器缓存。

## 最优性与版本

原题全局最优未证明。CP-SAT状态仅适用于本次有限筛选候选与保守整数秒排程；其时间下界不能直接当原题全局下界。任务持续和电池占用向上取整，最迟开始向下取整，导出按实际非整数物理时间复核。最少迟到0已达非负目标下界，但不证明完成时间或能耗最优。

本轮新增的是速度—能耗折中方案，保留此前21架次低能耗备选。第三问和第四问未同步重算，不应直接移植为通信受限方案。selected/best.json是当前冻结的第二问速度优先方案，逐箱与资源CSV、工作簿和提交表均来自同一快照。

## 复现

Python安装ortools、numpy、Pillow、openpyxl、pyproj、geographiclib。先运行lp_shortlist.py，再运行search.py --pool lp_shortlist.json --name target --timecap 6043 --energycap 67.11 --countcap 24 --seconds 180；较宽松搜索使用--name frontier --timecap 7972。最后validate_report.py、Node build_workbook.mjs与final_check.py。原始数据仍位于G:/数学建模大赛/中文题目/D；依赖13目录物理/验证和14目录计数候选。多线程限时搜索不保证逐次得到相同候选，已有best.json可直接独立复核。
'''
    (OUT/'算法改进与结果说明.md').write_text(report,encoding='utf8')
    (OUT/'workbook_data.json').write_text(json.dumps(dict(selected=selected.parent.name,summary=s,comparisons=comparisons,searches=logs,data=data),ensure_ascii=False),encoding='utf8');print('SELECTED',selected.parent.name,s['sorties'],s['makespan'],s['transport_energy'],flush=True)

if __name__=='__main__':main()
