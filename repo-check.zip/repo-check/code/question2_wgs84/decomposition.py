"""SCIP route-pattern master + CP-SAT cumulative resource scheduling.
Master-only solutions are NOT feasible deliveries; core cuts preserve validity.
"""
from pathlib import Path
from collections import defaultdict,Counter
import sys,json,math,time,argparse
BASE=Path(__file__).resolve().parent;OUT=BASE
sys.path.insert(0,str(BASE))
from physics import World,deadline,f
from solve import color
from ortools.linear_solver import pywraplp
from ortools.sat.python import cp_model

def main(H,energycap,countcap,iterations):
    w=World();meta=json.loads((OUT/'data/count_metadata.json').read_text(encoding='utf8'));raw=json.loads((OUT/'lp_shortlist.json').read_text(encoding='utf8'))
    grouped=defaultdict(list)
    for v in raw:
        if v['duration']<=H:grouped[tuple(tuple(x) for x in v['counts']),v['model']].append(v)
    pool=[]
    for rows in grouped.values():
        kept=[]
        for v in sorted(rows,key=lambda r:(r['duration'],r['energy'],-r['latest'])):
            if not any(a['energy']<=v['energy'] and a['duration']<=v['duration'] and a['latest']>=v['latest'] for a in kept):kept.append(v)
        pool+=kept
    solver=pywraplp.Solver.CreateSolver('SCIP');solver.SetNumThreads(2);solver.SetTimeLimit(20000);solver.SetSolverSpecificParametersAsString('limits/gap = 0.04')
    xs=[];maxs=[];cover=defaultdict(list);dr=defaultdict(list);prefix=defaultdict(list);energy=[];mastercost=[]
    bounds=sorted(set([1500,1800,2100,2400,2700,3000,3300,3600,3900,4200,4500,4800,5100,5400,5700,6000,H]))
    for i,v in enumerate(pool):
        dur=math.ceil(v['duration']);latest=math.floor(min(v['latest'],H-dur));mx=min(meta['demand'][k]//n for k,n in v['counts']);x=solver.IntVar(0,mx,'x'+str(i));xs.append(x);maxs.append(mx)
        for k,n in v['counts']:cover[k].append(n*x)
        dr[v['model']].append(dur*x);energy.append(v['energy']*x);mastercost.append((v['energy']+.025)*x)
        bd=math.ceil(v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]))
        for h in bounds:
            must=min(dur,max(0,h-latest));bmust=min(bd,max(0,h-latest))
            if must:prefix['d',v['model'],h].append(must*x)
            if bmust:prefix['b',v['model'],h].append(bmust*x)
    for k,n in enumerate(meta['demand']):solver.Add(solver.Sum(cover[k])==n)
    for g,n in [('A',4),('B',2),('C',2)]:solver.Add(solver.Sum(dr[g])<=n*H)
    for (kind,g,h),terms in prefix.items():solver.Add(solver.Sum(terms)<=({'A':4,'B':2,'C':2}[g] if kind=='d' else {'A':6,'B':4,'C':4}[g])*h)
    solver.Add(solver.Sum(xs)<=countcap);solver.Add(solver.Sum(energy)<=energycap);solver.Minimize(solver.Sum(mastercost))
    out=OUT/f'decomp_H{H}';out.mkdir(parents=True,exist_ok=True);history=[]
    for iteration in range(iterations):
        status=solver.Solve()
        if status not in [pywraplp.Solver.OPTIMAL,pywraplp.Solver.FEASIBLE]:print('SCIP_STOP',H,status,flush=True);break
        selected=[i for i,x in enumerate(xs) for _ in range(round(x.solution_value()))];print('MASTER',H,iteration,len(selected),sum(pool[i]['energy'] for i in selected),'masterbound',solver.Objective().BestBound(),flush=True)
        m=cp_model.CpModel();starts=[];ons=[];drints=defaultdict(list);btints=defaultdict(list)
        for j,i in enumerate(selected):
            v=pool[i];dur=math.ceil(v['duration']);latest=math.floor(min(v['latest'],H-dur));on=m.new_bool_var(f'x{j}');m.add_assumption(on);ons.append(on);st=m.new_int_var(0,latest,f's{j}');en=m.new_int_var(0,H,f'e{j}');m.add(en==st+dur);starts.append(st);drints[v['model']].append(m.new_optional_interval_var(st,dur,en,on,'d'+str(j)))
            bd=math.ceil(v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]));be=m.new_int_var(0,H+bd,f'be{j}');btints[v['model']].append(m.new_optional_interval_var(st,bd,be,on,'b'+str(j)))
        for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:m.add_cumulative(drints[g],[1]*len(drints[g]),n);m.add_cumulative(btints[g],[1]*len(btints[g]),b)
        cp=cp_model.CpSolver();cp.parameters.num_search_workers=1;cp.parameters.max_time_in_seconds=8;result=cp.solve(m)
        print('RESOURCE_STATUS',iteration,cp.status_name(result),flush=True)
        history.append(dict(iteration=iteration,status=cp.status_name(result),energy=sum(pool[i]['energy'] for i in selected),n=len(selected)))
        if result in [cp_model.OPTIMAL,cp_model.FEASIBLE]:
            cursor=[0]*len(meta['classes']);ts=[]
            for j,i in sorted(enumerate(selected),key=lambda ji:(cp.value(starts[ji[0]]),ji[0])):
                v=pool[i];ids=[]
                for k,n in v['counts']:ids+=meta['classes'][k]['ids'][cursor[k]:cursor[k]+n];cursor[k]+=n
                t=w.evaluate(ids,v['stops'],v['model']);st=float(cp.value(starts[j]));assert t
                t.update(start=st,end=st+t['duration'],battery_ready=st+t['duration']+f.charge_time_s(t['soc'],{'A':1800,'B':2400,'C':3000}[t['model']]),base_index=j);ts.append(t)
            assert cursor==meta['demand']
            for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:
                rows=[t for t in ts if t['model']==g];color(rows,'drone','end',{'A':['U01','U02','U03','U04'],'B':['U05','U06'],'C':['U07','U08']}[g]);color(rows,'battery','battery_ready',[f'{g}-BAT-{j+1:02d}' for j in range(b)])
            end=max(t['end'] for t in ts);en=sum(t['energy'] for t in ts);ans=dict(transports=ts,sites=[],relays=[],makespan=end,transport_energy=en,relay_energy=0,weighted_late=0,sorties=len(ts),score=end/72000+en/300+len(ts)/180,solver_status='VALIDATED_SUBPROBLEM_FEASIBLE',objective='minimum master energy under time/count budget + exact resource check',global_optimality_proven=False,zero_lateness_hard=True,distance_model='WGS84 ellipsoid',terrain_check='unchanged geodesic pixel crossings',H=H,energy_cap=energycap,sortie_cap=countcap)
            (out/'best.json').write_text(json.dumps(ans,ensure_ascii=False,indent=2),encoding='utf8');print('DECOMP_FOUND',H,end,en,len(ts),flush=True);break
        counts=Counter(selected)
        if result==cp_model.INFEASIBLE:
            core=set(cp.sufficient_assumptions_for_infeasibility());sub=[selected[j] for j,on in enumerate(ons) if on.index in core]
            if sub:counts=Counter(sub)
            print('CORE',len(sub),'/',len(selected),flush=True)
        # UNKNOWN cut is a diversity exclusion only, not an infeasibility proof.
        z=[]
        for i,n in counts.items():
            v=solver.BoolVar(f'cut{iteration}_{i}');solver.Add(xs[i]<=n-1+maxs[i]*(1-v));z.append(v)
        solver.Add(solver.Sum(z)>=1)
        (out/'history.json').write_text(json.dumps(history,indent=2),encoding='utf8')
    (out/'history.json').write_text(json.dumps(history,indent=2),encoding='utf8')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--horizon',type=int,default=6043);p.add_argument('--energycap',type=float,default=67.11);p.add_argument('--countcap',type=int,default=24);p.add_argument('--iterations',type=int,default=8);a=p.parse_args();main(a.horizon,a.energycap,a.countcap,a.iterations)
