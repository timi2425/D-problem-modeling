"""LP-guided candidate shortlist for feasible schedule discovery only.
Reduced-cost filtering is a heuristic and not a proof of excluded routes.
"""
from pathlib import Path
from collections import defaultdict
import sys,json,math,time
BASE=Path(__file__).resolve().parent;OUT=BASE
sys.path.insert(0,str(BASE))
from physics import World,f
from ortools.linear_solver import pywraplp

def main():
    w=World();meta=json.loads((OUT/'data/count_metadata.json').read_text(encoding='utf8'));pool=json.loads((OUT/'data/count_pool.json').read_text(encoding='utf8'));chosen=set();report=[]
    for H in [6043,6400,7000]:
        for mode in ['energy','work']:
            lp=pywraplp.Solver.CreateSolver('GLOP');vs=[];cover=defaultdict(list);work=defaultdict(list);prefix=defaultdict(list);energy=[]
            for i,v in enumerate(pool):
                dur=math.ceil(v['duration']);latest=math.floor(min(v['latest'],H-dur));mx=min(meta['demand'][k]//n for k,n in v['counts']);x=lp.NumVar(0,mx if latest>=0 else 0,'x'+str(i));vs.append(x)
                for k,n in v['counts']:cover[k].append(n*x)
                work[v['model']].append(dur*x);energy.append(v['energy']*x)
                bd=math.ceil(v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]))
                for h in [2400,3000,3600,4200,4800,5400,H]:
                    for kind,length in [('d',dur),('b',bd)]:
                        must=min(length,max(0,h-latest))
                        if must:prefix[kind,v['model'],h].append(must*x)
                lp.Objective().SetCoefficient(x,v['energy'] if mode=='energy' else dur/{'A':4,'B':2,'C':2}[v['model']]/100)
            for k,n in enumerate(meta['demand']):lp.Add(lp.Sum(cover[k])==n)
            for g,n in [('A',4),('B',2),('C',2)]:lp.Add(lp.Sum(work[g])<=n*H)
            for (kind,g,h),terms in prefix.items():lp.Add(lp.Sum(terms)<=({'A':4,'B':2,'C':2}[g] if kind=='d' else {'A':6,'B':4,'C':4}[g])*h)
            lp.Add(lp.Sum(vs)<=24);lp.Add(lp.Sum(energy)<=67.11);lp.Objective().SetMinimization();lp.SetTimeLimit(15000);status=lp.Solve()
            print('LP',H,mode,status,lp.Objective().Value(),flush=True)
            if status!=pywraplp.Solver.OPTIMAL:continue
            ranked=defaultdict(list)
            for i,(x,v) in enumerate(zip(vs,pool)):
                if x.solution_value()>1e-7:chosen.add(i)
                if v['duration']>H:continue
                rc=x.reduced_cost()
                for k,n in v['counts']:ranked[k,v['model']].append((rc,i))
            for pairs in ranked.values():chosen.update(i for _,i in sorted(pairs)[:15])
            report.append(dict(H=H,mode=mode,lp_value=lp.Objective().Value(),selected=len(chosen)))
    # Preserve all incumbent patterns even if reduced-cost shortlist excludes them.
    from collections import Counter
    seedkeys=set()
    for p in [OUT/'results/22_sorties_best.json',OUT/'results/23_sorties_best.json']:
        for t in json.loads(p.read_text(encoding='utf8'))['transports']:seedkeys.add((tuple(sorted(Counter(meta['boxclass'][x] for x in t['boxes']).items())),t['model'],tuple(t['stops'])))
    for i,v in enumerate(pool):
        if (tuple(tuple(x) for x in v['counts']),v['model'],tuple(v['stops'])) in seedkeys:chosen.add(i)
    (OUT/'lp_shortlist.json').write_text(json.dumps([pool[i] for i in sorted(chosen)],ensure_ascii=False),encoding='utf8');(OUT/'lp_shortlist_log.json').write_text(json.dumps(report,indent=2),encoding='utf8');print('SHORTLIST',len(chosen),flush=True)

if __name__=='__main__':main()
