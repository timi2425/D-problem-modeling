# 問題二：WGS84 零遲到搜索

代碼采用 WGS84 橢球距離、逐像元測地線邊界求交、整箱覆蓋、全部期望時限硬約束、資源周轉和獨立 GeographicLib 驗證。

結果快照：

- `results/22_sorties_best.json`: 22 架次，5792.089 s，66.516884 kWh，零遲到。
- `results/23_sorties_best.json`: 23 架次，5693.831 s，67.066017 kWh，零遲到。

搜索使用 `lp_shortlist.py` 生成候選池，再使用 `search.py` 的 CP-SAT 排程。`count_pool.json` 是候選模式池，不是分數解；最終結果始終是整數架次并經獨立驗證。

原始數據位置由環境變量 `D_SOURCE_ROOT` 指定。示例：

```powershell
$env:D_SOURCE_ROOT = "G:/數學建模大賽/中文題目/D"
python lp_shortlist.py
python search.py --name trial --timecap 6000 --energycap 67.11 --countcap 24 --seconds 300
python validate_report.py
```

有限候選搜索沒有原問題全局最優性證明。
