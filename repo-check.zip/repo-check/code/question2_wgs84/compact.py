from pathlib import Path
import sys,json,copy
BASE=Path(__file__).resolve().parent;OUT=BASE
sys.path.insert(0,str(BASE))
from physics import World,deadline,f

def main():
    sources=[p for p in OUT.glob('*/best.json') if p.parent.name not in ['selected','compact']]
    path=min(sources,key=lambda p:json.loads(p.read_text(encoding='utf8'))['makespan']);d=json.loads(path.read_text(encoding='utf8'));before=d['makespan'];w=World();dr={};bt={}
    for t in sorted(d['transports'],key=lambda r:r['start']):
        v=w.evaluate(t['boxes'],t['stops'],t['model']);assert v
        start=max(dr.get(t['drone'],0.),bt.get(t['battery'],0.));assert start<=t['start']+1e-6
        t.update(v,start=start,end=start+v['duration'],battery_ready=start+v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]))
        assert all(start+off<=deadline(w.boxes[x])+1e-7 for x,off in v['deliveries'].items())
        dr[t['drone']]=t['end'];bt[t['battery']]=t['battery_ready']
    d['makespan']=max(t['end'] for t in d['transports']);d['transport_energy']=sum(t['energy'] for t in d['transports']);d['score']=d['makespan']/72000+d['transport_energy']/300+d['sorties']/180
    d.update(compaction_source=str(path),pre_compaction_makespan=before,solver_status='EARLIEST_CONTINUOUS_FOR_FIXED_RESOURCE_ORDER',global_optimality_proven=False)
    out=OUT/'compact';out.mkdir(exist_ok=True);(out/'best.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');print('COMPACT',d['makespan'],d['transport_energy'],d['sorties'])

if __name__=='__main__':main()
