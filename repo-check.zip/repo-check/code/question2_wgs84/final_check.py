from pathlib import Path
import json,hashlib,sys
from openpyxl import load_workbook
BASE=Path(__file__).resolve().parent;OUT=BASE
sys.path.insert(0,str(BASE))
from physics import SOURCE,f

def main():
    d=json.loads((OUT/'workbook_data.json').read_text(encoding='utf8'));p=d['data'];w=load_workbook(OUT/'第二问_速度能耗联合改进.xlsx',data_only=True);checks=[];cells=0
    def ck(n,ok):
        checks.append(dict(检查=n,状态='PASS' if ok else 'FAIL'))
        if not ok:raise AssertionError(n)
    def eq(a,b):
        if isinstance(b,(int,float)):return isinstance(a,(int,float)) and abs(a-b)<max(1e-7,abs(b)*1e-12)
        return (a or '')==(b or '')
    for tab,rows in [('指标对照',d['comparisons']),('搜索状态',d['searches']),('运输架次',p['trips']),('逐箱交付',p['boxes']),('电池占用',p['batteries']),('航段物理',p['legs']),('独立复核',p['checks'])]:
        a=list(w[tab].iter_rows(min_row=2,values_only=True));ck(tab+'行数',len(a)==len(rows));ck(tab+'表头',[c.value for c in w[tab][1]]==list(rows[0]))
        for x,r in zip(a,rows):assert all(eq(y,z) for y,z in zip(x,r.values())),tab;cells+=len(r)
    tpl=load_workbook(OUT/'第二问_速度能耗改进提交表.xlsx',data_only=True)
    expected={'Q2_运输架次':[[r[k] for k in ['架次编号','无人机编号','机型编号','电池编号','开始时刻s','访问服务区顺序','返回O01时刻s','能耗kWh']] for r in p['trips']],'Q2_逐箱交付':[[r[k] for k in ['货箱编号','架次编号','服务区编号','交付完成时刻s']] for r in p['boxes']]}
    for tab,rows in expected.items():
        a=[r for r in tpl[tab].iter_rows(min_row=2,values_only=True) if any(x is not None for x in r)];ck(tab+'逐值一致',len(a)==len(rows) and all(all(eq(x,y) for x,y in zip(b,c)) for b,c in zip(a,rows)))
    for tab in tpl.sheetnames:
        if tab not in expected:ck(tab+'未填其他问题',not any(any(x is not None for x in r) for r in tpl[tab].iter_rows(min_row=2,values_only=True)))
    ck('80箱零迟到',len(p['boxes'])==80 and len({b['货箱编号'] for b in p['boxes']})==80 and all(r['加权迟到']==0 and r['期望余量s']>=0 for r in p['boxes']))
    ck('独立验证通过',all(r['状态']=='PASS' for r in p['checks']))
    ck('汇总一致',abs(sum(r['能耗kWh'] for r in p['trips'])-d['summary']['transport_energy'])<1e-8 and abs(max(r['返回O01时刻s'] for r in p['trips'])-d['summary']['makespan'])<1e-7)
    f.write_csv(OUT/'最终文件检查.csv',checks)
    files=[p for p in OUT.rglob('*') if p.is_file() and 'node_modules' not in p.parts and 'QA' not in p.parts and '__pycache__' not in p.parts and not p.name.endswith('.ndjson') and p.name!='发布校验.json']
    sources=[OUT/'physics.py',OUT/'validate.py',OUT/'q1_foundation.py',OUT/'data/count_metadata.json',OUT/'data/count_pool.json']+list((SOURCE/'数据').rglob('*.xlsx'))+list((SOURCE/'数据').rglob('*.tif'))
    manifest=dict(status='PASS',version='Q2-WGS84-ZERO-SPEED-ENERGY',selected=d['selected'],summary=d['summary'],final_checks=len(checks),workbook_cells=cells,global_optimality_proven=False,sha256={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (OUT/'发布校验.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8');print('FINAL_PASS',len(checks),cells)

if __name__=='__main__':main()
