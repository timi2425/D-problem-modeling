"""Zero-late WGS84 scheduling, speed under explicit energy/sortie budgets.
Identical box-class integer counts; re-expand actual IDs and validate.
"""
from pathlib import Path
from collections import defaultdict,Counter
import sys,json,math,copy,argparse
BASE=Path(__file__).resolve().parent;OUT=BASE
sys.path.insert(0,str(BASE))
from physics import World,deadline,f
from solve import color
from ortools.sat.python import cp_model

def main(seconds,energycap,countcap,timecap,seedfile,name,region=None,pool_path=None):
    OUT.mkdir(exist_ok=True);w=World();meta=json.loads((OUT/'data/count_metadata.json').read_text(encoding='utf8'));raw=json.loads((pool_path or OUT/'data/count_pool.json').read_text(encoding='utf8'));seed=json.loads(seedfile.read_text(encoding='utf8'))
    groups=defaultdict(list)
    for v in raw:groups[(tuple(tuple(x) for x in v['counts']),v['model'])].append(v)
    pool=[]
    for key,rows in groups.items():
        # At zero tardiness, latest start summarizes all box-specific deadlines.
        # Same class counts/type with shorter duration, less energy and later
        # latest start dominates including recharge duration.
        kept=[]
        for v in sorted(rows,key=lambda r:(r['duration'],r['energy'],-r['latest'])):
            if any(a['duration']<=v['duration'] and a['energy']<=v['energy'] and a['latest']>=v['latest'] for a in kept):continue
            kept.append(v)
        pool+=kept
    hints=defaultdict(list)
    for t in sorted(seed['transports'],key=lambda r:r['start']):hints[(tuple(sorted(Counter(meta['boxclass'][x] for x in t['boxes']).items())),t['model'],tuple(t['stops']))].append(t)
    fixed=set()
    if region:
        allowed=set(region.split(','));fixed={k for k in hints if not set(k[2])<=allowed}
        pool=[v for v in pool if set(v['stops'])<=allowed or (tuple(tuple(x) for x in v['counts']),v['model'],tuple(v['stops'])) in fixed]
    scale=1000000;H=math.ceil(timecap);m=cp_model.CpModel();cover=defaultdict(list);dr=defaultdict(list);bt=defaultdict(list);work=defaultdict(list);prefix=defaultdict(list);choices=[];energy=[]
    C=m.new_int_var(0,H,'finish');boundaries=[1800,2400,3000,3600,4200,4800,5400,6000,H]
    for v in pool:
        dur=math.ceil(v['duration']);latest=math.floor(min(v['latest'],H-dur));
        if latest<0:continue
        counts=tuple(tuple(x) for x in v['counts']);key=(counts,v['model'],tuple(v['stops']));copies=min(meta['demand'][k]//n for k,n in counts);previous=None
        bd=math.ceil(v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]))
        for j in range(copies):
            tag=f'{v["pattern_id"]}_{j}';on=m.new_bool_var('x'+tag);st=m.new_int_var(0,latest,'s'+tag);end=m.new_int_var(0,H+dur,'e'+tag);m.add(end==st+dur);m.add(st==0).only_enforce_if(on.Not());m.add(C>=end).only_enforce_if(on)
            dr[v['model']].append(m.new_optional_interval_var(st,dur,end,on,'d'+tag));be=m.new_int_var(0,H+bd,'be'+tag);bt[v['model']].append(m.new_optional_interval_var(st,bd,be,on,'b'+tag))
            work[v['model']].append(dur*on)
            for h in boundaries:
                must=min(dur,max(0,h-latest));bmust=min(bd,max(0,h-latest))
                if must:prefix['d',v['model'],h].append(must*on)
                if bmust:prefix['b',v['model'],h].append(bmust*on)
            if previous:m.add(on<=previous[0]);m.add(st>=previous[1]).only_enforce_if(on)
            previous=(on,st)
            for k,n in counts:cover[k].append(n*on)
            energy.append(math.ceil(v['energy']*scale)*on);choices.append((on,st,v))
            ht=hints.get(key,[]);hint=ht[j] if j<len(ht) else None;m.add_hint(on,int(hint is not None));m.add_hint(st,min(latest,math.ceil(hint['start'])) if hint else 0)
            if key in fixed:m.add(on==int(hint is not None))
    for k,n in enumerate(meta['demand']):m.add(sum(cover[k])==n)
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:m.add_cumulative(dr[g],[1]*len(dr[g]),n);m.add_cumulative(bt[g],[1]*len(bt[g]),b);m.add(sum(work[g])<=n*C)
    for (kind,g,h),terms in prefix.items():m.add(sum(terms)<=({'A':4,'B':2,'C':2}[g] if kind=='d' else {'A':6,'B':4,'C':4}[g])*h)
    N=sum(x for x,_,_ in choices);E=sum(energy);m.add(N<=countcap);m.add(E<=math.floor(energycap*scale));m.minimize(C)
    solver=cp_model.CpSolver();solver.parameters.num_search_workers=8;solver.parameters.max_time_in_seconds=seconds;solver.parameters.random_seed=2026092415
    history=[]
    class CB(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.last=-100
        def on_solution_callback(self):
            history.append(dict(elapsed=self.wall_time,time=self.value(C),energy=self.value(E)/scale,count=self.value(N),bound=self.best_objective_bound))
            if self.wall_time-self.last>=15:print('SPEED_INCUMBENT',name,history[-1],flush=True);self.last=self.wall_time
    print('MODEL',name,'patterns',len(pool),'intervals',len(choices),'caps',energycap,countcap,H,flush=True)
    status=solver.solve(m,CB());print('STATUS',name,solver.status_name(status),solver.objective_value,solver.best_objective_bound,flush=True)
    dest=OUT/name;dest.mkdir(exist_ok=True);(dest/'search_status.json').write_text(json.dumps(dict(status=solver.status_name(status),seconds=seconds,pool_size=len(pool),history=history,bound=solver.best_objective_bound,energycap=energycap,countcap=countcap,timecap=H,region=region),ensure_ascii=False,indent=2),encoding='utf8')
    if status not in [cp_model.OPTIMAL,cp_model.FEASIBLE]:return
    selected=sorted([(float(solver.value(st)),v) for on,st,v in choices if solver.value(on)],key=lambda x:(x[0],x[1]['pattern_id']));cursor=[0]*len(meta['classes']);ts=[]
    for i,(start,v) in enumerate(selected):
        ids=[]
        for k,n in v['counts']:ids+=meta['classes'][k]['ids'][cursor[k]:cursor[k]+n];cursor[k]+=n
        t=w.evaluate(ids,v['stops'],v['model']);assert t and abs(t['energy']-v['energy'])<1e-8
        assert all(start+off<=deadline(w.boxes[x])+1e-7 for x,off in t['deliveries'].items())
        t.update(start=start,end=start+t['duration'],battery_ready=start+t['duration']+f.charge_time_s(t['soc'],{'A':1800,'B':2400,'C':3000}[t['model']]),base_index=i);ts.append(t)
    assert cursor==meta['demand']
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:
        rows=[t for t in ts if t['model']==g];color(rows,'drone','end',{'A':['U01','U02','U03','U04'],'B':['U05','U06'],'C':['U07','U08']}[g]);color(rows,'battery','battery_ready',[f'{g}-BAT-{j+1:02d}' for j in range(b)])
    finish=max(t['end'] for t in ts);en=sum(t['energy'] for t in ts);assert en<=energycap+1e-8 and len(ts)<=countcap
    ans=dict(transports=ts,sites=[],relays=[],sorties=len(ts),makespan=finish,transport_energy=en,relay_energy=0,weighted_late=0,score=finish/72000+en/300+len(ts)/180,objective='minimum makespan within energy/sortie budgets',solver_status=solver.status_name(status),pool_time_bound=solver.best_objective_bound,global_optimality_proven=False,zero_lateness_hard=True,distance_model='WGS84 ellipsoid',terrain_check='unchanged geodesic exact cell boundary crossings',energy_cap=energycap,sortie_cap=countcap,search_seconds=seconds)
    (dest/'best.json').write_text(json.dumps(ans,ensure_ascii=False,indent=2),encoding='utf8');print('RESULT',name,len(ts),finish,en,ans['score'],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seconds',type=float,default=300);p.add_argument('--energycap',type=float,default=67.11);p.add_argument('--countcap',type=int,default=24);p.add_argument('--timecap',type=float,default=7972);p.add_argument('--seed',type=Path,default=OUT/'results/22_sorties_best.json');p.add_argument('--name',default='budget24');p.add_argument('--region');p.add_argument('--pool',type=Path);a=p.parse_args();main(a.seconds,a.energycap,a.countcap,a.timecap,a.seed,a.name,a.region,a.pool)
