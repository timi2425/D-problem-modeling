"""Zero lateness hard constrained CP-SAT, WGS84 and exact cell traversal.
Finite candidates, integer conservative time; no global proof assertion.
"""
import json,math,time,copy,argparse
from collections import defaultdict
from physics import World,OUT,BASE,deadline,f
from ortools.sat.python import cp_model

def color(rows,key,end,names):
    ready={x:0. for x in names}
    for t in sorted(rows,key=lambda r:r['start']):
        name=min(ready,key=ready.get);assert ready[name]<=t['start']+1e-7
        t[key]=name;ready[name]=t[end]

def solve(objective,seconds,fixed=False,seed_path=None):
    w=World();candidates=json.loads((OUT/'route_pool_wgs84.json').read_text(encoding='utf8'))
    seed=json.loads((seed_path or OUT/'results/22_sorties_best.json').read_text(encoding='utf8'))
    if fixed:
        groups={tuple(sorted(t['boxes'])) for t in seed['transports']};candidates=[v for v in candidates if tuple(sorted(v['boxes'])) in groups]
    # Deterministically forward-repair incumbent resource order with new distances.
    baseline=[];dr={};bt={};baseline_ok=True
    for t in sorted(seed['transports'],key=lambda t:t['start']):
        v=w.evaluate(t['boxes'],t['stops'],t['model'])
        if v is None:baseline_ok=False;break
        start=math.ceil(max(t['start'],dr.get(t['drone'],0),bt.get(t['battery'],0)))
        if any(start+off>deadline(w.boxes[x])+1e-8 for x,off in v['deliveries'].items()):baseline_ok=False
        charge=f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]);dr[t['drone']]=start+math.ceil(v['duration']);bt[t['battery']]=start+math.ceil(v['duration']+charge)
        baseline.append(dict(v,start=start,drone=t['drone'],battery=t['battery']))
    print('SOLVE',objective,'fixed',fixed,'pool',len(candidates),'baseline_feasible',baseline_ok,flush=True)
    m=cp_model.CpModel();H=24000;cover=defaultdict(list);drints=defaultdict(list);btints=defaultdict(list);picks=[];ends=[];energy=[]
    hints={(tuple(sorted(t['boxes'])),t['model'],tuple(t['stops'])):t for t in baseline}
    for i,v in enumerate(candidates):
        latest=math.floor(min(deadline(w.boxes[x])-off for x,off in v['deliveries'].items()))
        dur=math.ceil(v['duration']);on=m.new_bool_var(f'x{i}');st=m.new_int_var(0,max(latest,0),f's{i}');en=m.new_int_var(0,H+dur,f'e{i}');m.add(en==st+dur);m.add(st==0).only_enforce_if(on.Not())
        if latest<0:m.add(on==0)
        drints[v['model']].append(m.new_optional_interval_var(st,dur,en,on,f'd{i}'))
        bd=math.ceil(v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]));be=m.new_int_var(0,H+bd,f'be{i}');btints[v['model']].append(m.new_optional_interval_var(st,bd,be,on,f'b{i}'))
        ee=m.new_int_var(0,H,'effective'+str(i));m.add(ee==en).only_enforce_if(on);m.add(ee==0).only_enforce_if(on.Not());ends.append(ee)
        for x in v['boxes']:cover[x].append(on)
        energy.append(v['energy']*on);picks.append((on,st))
        hint=hints.get((tuple(sorted(v['boxes'])),v['model'],tuple(v['stops'])))
        if baseline_ok:m.add_hint(on,int(hint is not None));m.add_hint(st,min(max(latest,0),hint['start']) if hint else 0)
    for x in w.boxes:m.add_exactly_one(cover[x])
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:m.add_cumulative(drints[g],[1]*len(drints[g]),n);m.add_cumulative(btints[g],[1]*len(btints[g]),b)
    finish=m.new_int_var(0,H,'finish');m.add_max_equality(finish,ends);n=sum(on for on,_ in picks);E=sum(energy)
    # Delay is constrained to zero; keep historical remaining weights unchanged.
    objective_expr={'balanced':(.2/14400)*finish+(.2/60)*E+(.1/18)*n,'time':finish,'energy':E}[objective];m.minimize(objective_expr)
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds;solver.parameters.num_search_workers=8;solver.parameters.random_seed=20260924
    class Watch(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.last=-100
        def on_solution_callback(self):
            if self.wall_time-self.last>15:print('INCUMBENT',objective,fixed,round(self.wall_time,1),self.objective_value,flush=True);self.last=self.wall_time
    status=solver.solve(m,Watch());print('STATUS',objective,fixed,solver.status_name(status),solver.objective_value,solver.best_objective_bound,flush=True)
    if status not in [cp_model.FEASIBLE,cp_model.OPTIMAL]:return
    ts=[]
    for i,(on,st) in enumerate(picks):
        if not solver.value(on):continue
        v=copy.deepcopy(candidates[i]);start=float(solver.value(st));v.update(start=start,end=start+v['duration'],battery_ready=start+v['duration']+f.charge_time_s(v['soc'],{'A':1800,'B':2400,'C':3000}[v['model']]),base_index=i);ts.append(v)
    for g,n,b in [('A',4,6),('B',2,4),('C',2,4)]:
        rows=[t for t in ts if t['model']==g];color(rows,'drone','end',{'A':['U01','U02','U03','U04'],'B':['U05','U06'],'C':['U07','U08']}[g]);color(rows,'battery','battery_ready',[f'{g}-BAT-{i+1:02d}' for i in range(b)])
    end=max(t['end'] for t in ts);energy=sum(t['energy'] for t in ts);delay=sum(w.boxes[x]['应急优先系数']*max(0,t['start']+off-w.boxes[x]['期望送达时间（s）']) for t in ts for x,off in t['deliveries'].items());assert delay==0
    ans=dict(transports=ts,sites=[],relays=[],makespan=end,transport_energy=energy,relay_energy=0,weighted_late=delay,score=.2*end/14400+.2*energy/60+.1*len(ts)/18,sorties=len(ts),objective=objective,fixed_groups=fixed,solver_status=solver.status_name(status),solver_objective=solver.objective_value,pool_bound=solver.best_objective_bound,seconds=seconds,candidates=len(candidates),zero_lateness_hard=True,distance_model='WGS84 ellipsoidal geodesic',terrain_check='all intersected cells via geodesic boundary crossings',global_optimality_proven=False)
    name=('fixed_'+objective if fixed else objective)+('_refined' if fixed and seed_path else '')
    path=OUT/name;path.mkdir(exist_ok=True);(path/'best.json').write_text(json.dumps(ans,ensure_ascii=False,indent=2),encoding='utf8')
    print('RESULT',objective,fixed,end,energy,len(ts),ans['score'],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--objective',choices=['balanced','time','energy'],default='balanced');p.add_argument('--seconds',type=float,default=180);p.add_argument('--fixed',action='store_true');p.add_argument('--seed');a=p.parse_args();from pathlib import Path
    solve(a.objective,a.seconds,a.fixed,Path(a.seed) if a.seed else None)
