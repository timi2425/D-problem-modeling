"""WGS84 ellipsoidal Q2 physics, geodesic cell-boundary traversal.
Source files and previous spherical releases are not modified.
"""
from pathlib import Path
import sys,json,math,hashlib,os
import numpy as np
from pyproj import Geod
from geographiclib.geodesic import Geodesic
BASE=Path(__file__).resolve().parent;OUT=BASE
sys.path.insert(0,str(BASE))
import q1_foundation as f
SOURCE=Path(os.environ.get('D_SOURCE_ROOT',r'G:\数学建模大赛\中文题目\D'))
GEOD=Geod(ellps='WGS84')

class World:
    def __init__(self):
        self.nodes=f.parse_nodes(SOURCE);self.byid={n.node_id:n for n in self.nodes};self.models,_,self.fleet,self.stock=f.parse_models(SOURCE);self.mod={m.model_id:m for m in self.models}
        self.boxes={b['货箱编号']:b for b in f.parse_boxes(SOURCE)[1]};self.dem=f.DemGrid(next((SOURCE/'数据').rglob('*.tif')))
        self.arcs={};self.cellsets={};self.geometry_checks=[]
        for i,a in enumerate(self.nodes):
            for b in self.nodes[i+1:]:
                az,_,dist=GEOD.inv(a.lon_deg,a.lat_deg,b.lon_deg,b.lat_deg)
                cells=self.geodesic_cells(a,b,az,dist);land=self.dem.array[cells[:,1],cells[:,0]]
                assert np.isfinite(land).all() and not (land==-32767).any();highest=float(land.max());H=highest+50
                assert H>=max(a.operation_height_m,b.operation_height_m)
                for start,end in [(a,b),(b,a)]:
                    self.arcs[start.node_id,end.node_id]=dict(from_node=start.node_id,to_node=end.node_id,horizontal_distance_m=dist,max_dem_m=highest,cruise_altitude_m=H,climb_m=H-start.operation_height_m,descent_m=H-end.operation_height_m,dem_cells=len(cells))
                    self.cellsets[start.node_id,end.node_id]=cells.tolist()
                independent=Geodesic.WGS84.Inverse(a.lat_deg,a.lon_deg,b.lat_deg,b.lon_deg)['s12']
                assert abs(independent-dist)<1e-6
                # Independent distance library plus 1 m trace cross-check.
                p=np.linspace(0,dist,max(2,math.ceil(dist)+1));lon,lat,_=GEOD.fwd(np.full(len(p),a.lon_deg),np.full(len(p),a.lat_deg),np.full(len(p),az),p)
                dense=set(zip(np.floor((lon-self.dem.tie_lon)/self.dem.pixel_lon+.5).astype(int),np.floor((self.dem.tie_lat-lat)/self.dem.pixel_lat+.5).astype(int)))
                exact={tuple(c) for c in cells};assert dense<=exact
                oldmx,_=self.dem.line_cells_max(a,b)
                self.geometry_checks.append(dict(起点=a.node_id,终点=b.node_id,WGS84距离m=dist,距离独立误差m=abs(independent-dist),经过像元数=len(cells),米级复核全部覆盖=dense<=exact,原经纬直线最高m=oldmx,椭球测地线最高m=highest,最高高程差m=highest-oldmx))
    def geodesic_cells(self,a,b,az,dist):
        """Enumerate every grid crossing, not equal-distance samples.
        Local routes have monotonic lon/lat; explicitly check this premise.
        Root locations are solved to ~submicrometre path distance.
        """
        lo0=a.lon_deg;la0=a.lat_deg
        probes=np.linspace(0,dist,33);lon,lat,back=GEOD.fwd(np.full(33,lo0),np.full(33,la0),np.full(33,az),probes)
        assert np.all(np.diff(lon)*np.sign(b.lon_deg-a.lon_deg)>=-1e-12)
        assert np.all(np.diff(lat)*np.sign(b.lat_deg-a.lat_deg)>=-1e-12)
        # Forward azimuth components must keep their signs (no turning latitude).
        rad=np.deg2rad(np.asarray(back)+180);assert np.all(np.sin(rad)*np.sign(b.lon_deg-a.lon_deg)>=-1e-10);assert np.all(np.cos(rad)*np.sign(b.lat_deg-a.lat_deg)>=-1e-10)
        start=np.array(self.dem.index(a.lon_deg,a.lat_deg));end=np.array(self.dem.index(b.lon_deg,b.lat_deg));crossings=[0.,dist]
        for axis in [0,1]:
            low,high=sorted([start[axis],end[axis]]);bounds=np.arange(math.ceil(low-.5),math.floor(high-.5)+1)+.5
            if not len(bounds):continue
            left=np.zeros(len(bounds));right=np.full(len(bounds),dist);direction=np.sign(end[axis]-start[axis])
            for _ in range(48):
                mid=(left+right)/2;x,y,_=GEOD.fwd(np.full(len(mid),lo0),np.full(len(mid),la0),np.full(len(mid),az),mid)
                v=(np.asarray(x)-self.dem.tie_lon)/self.dem.pixel_lon if axis==0 else (self.dem.tie_lat-np.asarray(y))/self.dem.pixel_lat
                lt=(v-bounds)*direction<0;left=np.where(lt,mid,left);right=np.where(lt,right,mid)
            crossings.extend(((left+right)/2).tolist())
        crossings=np.unique(crossings);positions=np.r_[crossings,(crossings[:-1]+crossings[1:])/2]
        lon,lat,_=GEOD.fwd(np.full(len(positions),lo0),np.full(len(positions),la0),np.full(len(positions),az),positions)
        col=(np.asarray(lon)-self.dem.tie_lon)/self.dem.pixel_lon;row=(self.dem.tie_lat-np.asarray(lat))/self.dem.pixel_lat;cells=set()
        # +/-1e-8 pixel tolerance includes boundary contacts conservatively.
        for x,y in zip(col,row):
            for c in {math.floor(x+.5-1e-8),math.floor(x+.5+1e-8)}:
                for r in {math.floor(y+.5-1e-8),math.floor(y+.5+1e-8)}:cells.add((c,r))
        result=np.array(sorted(cells),int)
        assert np.all(result[:,0]>=0) and np.all(result[:,0]<self.dem.width) and np.all(result[:,1]>=0) and np.all(result[:,1]<self.dem.height)
        return result
    def evaluate(self,ids,stops,g):
        ids=list(ids);stops=list(stops);m=self.mod[g]
        if len(ids)!=len(set(ids)) or set(stops)!={self.boxes[x]['服务区编号'] for x in ids} or len(stops)!=len(set(stops)):return None
        mass=sum(self.boxes[x]['单箱质量（kg）'] for x in ids);volume=sum(self.boxes[x]['单箱体积（m³）'] for x in ids)
        if mass>m.max_payload_kg+1e-8 or volume>m.volume_m3+1e-10:return None
        load=mass;time=m.prep_s+len(ids)*m.load_box_s;energy=0.;deliveries={};legs=[];current='O01'
        for dest in stops+['O01']:
            arc=self.arcs[current,dest];v=f.transport_segment_metrics(arc,m,max(load,0));time+=v['flight_time_s'];energy+=v['energy_kwh']
            legs.append(dict(start=current,end=dest,load=load,distance=arc['horizontal_distance_m'],cruise=arc['cruise_altitude_m'],energy=v['energy_kwh'],flight_s=v['flight_time_s']))
            if dest!='O01':
                group=sorted([x for x in ids if self.boxes[x]['服务区编号']==dest],key=lambda x:(deadline(self.boxes[x]),self.boxes[x]['期望送达时间（s）'],-self.boxes[x]['应急优先系数'],x))
                time+=m.handover_base_s
                for x in group:time+=m.handover_box_s;deliveries[x]=time;load-=self.boxes[x]['单箱质量（kg）']
            current=dest
        if energy>(1-m.return_soc_min)*m.battery_kwh+1e-9:return None
        return dict(boxes=ids,stops=stops,model=g,duration=time,energy=energy,soc=1-energy/m.battery_kwh,deliveries=deliveries,mass=mass,volume=volume,legs=legs)

def deadline(b):
    # User requires ALL expected deliveries on time, plus original first-batch cutoffs.
    return min(float(b['期望送达时间（s）']),float(b['首批截止时间（s）']) if b['是否首批保障']=='是' else math.inf)

if __name__=='__main__':
    w=World();f.write_csv(OUT/'WGS84_240航段.csv',list(w.arcs.values()));f.write_csv(OUT/'地理计算独立复核.csv',w.geometry_checks)
    (OUT/'航段逐像元集合.json').write_text(json.dumps({a+'->'+b:c for (a,b),c in w.cellsets.items()}),encoding='utf8')
    print('GEOMETRY',len(w.arcs),'max distance independent error',max(r['距离独立误差m'] for r in w.geometry_checks),'changed terrain',sum(abs(r['最高高程差m'])>1e-9 for r in w.geometry_checks),flush=True)
