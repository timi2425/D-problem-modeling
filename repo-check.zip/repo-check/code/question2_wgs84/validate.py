"""Independent scalar route reconstruction with GeographicLib distances.
Deadline/resource validation does not use the optimizer's cached costs.
"""
from pathlib import Path
from collections import defaultdict
import json,math,hashlib
from geographiclib.geodesic import Geodesic
from physics import World,OUT,BASE,SOURCE,deadline,f

def reconstruct(w,t):
    m=w.mod[t['model']];load=sum(w.boxes[x]['单箱质量（kg）'] for x in t['boxes']);volume=sum(w.boxes[x]['单箱体积（m³）'] for x in t['boxes']);mass=load;now=m.prep_s+len(t['boxes'])*m.load_box_s;energy=0.;delivered={};legs=[];a='O01'
    for b in t['stops']+['O01']:
        p=w.byid[a];q=w.byid[b];dist=Geodesic.WGS84.Inverse(p.lat_deg,p.lon_deg,q.lat_deg,q.lon_deg)['s12'];arc=w.arcs[a,b]
        cells=w.cellsets[a,b];highest=max(float(w.dem.array[y,x]) for x,y in cells);H=highest+50;up=H-p.operation_height_m;down=H-q.operation_height_m
        duration=up/m.climb_speed_mps+dist/m.cruise_speed_mps+down/m.descend_speed_mps
        L=m.empty_range_m-(m.empty_range_m-m.full_range_m)*(max(load,0)/m.max_payload_kg)**1.5
        E=m.battery_kwh*dist/L+(m.empty_mass_kg+max(load,0))*f.G*up/(m.climb_efficiency*3600000)
        if m.descend_efficiency:E+=(m.empty_mass_kg+max(load,0))*f.G*down/(m.descend_efficiency*3600000)
        legs.append(dict(起点=a,终点=b,WGS84距离m=dist,最高地形m=highest,巡航海拔m=H,剩余载荷kg=load,航段时间s=duration,航段能耗kWh=E,经过像元数=len(cells)))
        now+=duration;energy+=E
        if b!='O01':
            group=sorted([x for x in t['boxes'] if w.boxes[x]['服务区编号']==b],key=lambda x:(deadline(w.boxes[x]),w.boxes[x]['期望送达时间（s）'],-w.boxes[x]['应急优先系数'],x));now+=m.handover_base_s
            for x in group:now+=m.handover_box_s;delivered[x]=t['start']+now;load-=w.boxes[x]['单箱质量（kg）']
        a=b
    return dict(mass=mass,volume=volume,energy=energy,duration=now,soc=1-energy/m.battery_kwh,deliveries=delivered,legs=legs)

def charge(soc,full):
    assert 0<=soc<=1
    return full*(.65*(.9-soc)/.9+.35) if soc<.9 else full*.35*(1-soc)/.1

def validate_candidate(path,w):
    data=json.loads(path.read_text(encoding='utf8'));checks=[];trips=[];boxes=[];batteries=[];legs=[];resources=defaultdict(list);seen=[]
    def ck(name,ok,evidence=''):
        checks.append(dict(检查=name,状态='PASS' if ok else 'FAIL',证据=str(evidence)))
        if not ok:raise AssertionError((name,evidence))
    fleet={r['无人机编号']:r['机型编号'] for r in w.fleet if '无人机编号' in r}
    for i,t in enumerate(data['transports'],1):
        id=f'W84-T{i:03d}';m=w.mod[t['model']];v=reconstruct(w,t);end=t['start']+v['duration'];ready=end+charge(v['soc'],{'A':1800,'B':2400,'C':3000}[t['model']])
        ck(id+'编号机型',fleet.get(t['drone'])==t['model'])
        ck(id+'电池库存编号',t['battery'] in [f'{t["model"]}-BAT-{k+1:02d}' for k in range({'A':6,'B':4,'C':4}[t['model']])])
        ck(id+'非负时刻',t['start']>=0 and end>t['start'])
        ck(id+'目的地覆盖',set(t['stops'])=={w.boxes[x]['服务区编号'] for x in t['boxes']} and len(set(t['stops']))==len(t['stops']))
        ck(id+'质量体积',v['mass']<=m.max_payload_kg+1e-8 and v['volume']<=m.volume_m3+1e-10)
        ck(id+'返航电量',v['soc']>=m.return_soc_min-1e-10,v['soc'])
        ck(id+'独立能耗时间',abs(v['energy']-t['energy'])<1e-8 and abs(end-t['end'])<1e-6)
        ck(id+'独立满充',abs(ready-t['battery_ready'])<1e-6)
        trips.append(dict(架次编号=id,无人机编号=t['drone'],机型编号=t['model'],电池编号=t['battery'],开始时刻s=t['start'],访问服务区顺序='→'.join(t['stops']),返回O01时刻s=end,能耗kWh=v['energy'],返航SOC=v['soc'],质量kg=v['mass'],体积m3=v['volume'],货箱编号列表=','.join(t['boxes'])))
        batteries.append(dict(电池编号=t['battery'],架次编号=id,占用开始s=t['start'],返航s=end,剩余SOC=v['soc'],满充结束s=ready))
        resources[t['drone']].append((t['start'],end));resources[t['battery']].append((t['start'],ready))
        for x,at in v['deliveries'].items():
            b=w.boxes[x];ck(x+'全部时限',at<=deadline(b)+1e-7,(at,deadline(b)));seen.append(x)
            boxes.append(dict(货箱编号=x,架次编号=id,服务区编号=b['服务区编号'],物资类型=b['物资类型'],交付完成时刻s=at,期望时刻s=b['期望送达时间（s）'],首批截止s=b['首批截止时间（s）'],期望余量s=b['期望送达时间（s）']-at,加权迟到=b['应急优先系数']*max(0,at-b['期望送达时间（s）'])))
        legs.extend(dict(架次编号=id,**leg) for leg in v['legs'])
    ck('80箱唯一完整',len(seen)==80 and len(set(seen))==80 and set(seen)==set(w.boxes))
    for name,spans in resources.items():
        spans.sort();ck(name+'占用不重叠',all(b[0]>=a[1]-1e-6 for a,b in zip(spans,spans[1:])))
    late=sum(b['加权迟到'] for b in boxes);ck('全部期望时间零迟到',late==0,late)
    summary={k:v for k,v in data.items() if k not in ['transports','sites','relays']};summary.update(makespan=max(t['返回O01时刻s'] for t in trips),transport_energy=sum(t['能耗kWh'] for t in trips),weighted_late=late,boxes=len(boxes),checks=len(checks),failed=0,min_deadline_margin_s=min(deadline(w.boxes[x])-at for t in data['transports'] for x,at in reconstruct(w,t)['deliveries'].items()))
    ck('汇总一致',abs(summary['makespan']-data['makespan'])<1e-6 and abs(summary['transport_energy']-data['transport_energy'])<1e-8)
    summary['checks']=len(checks)
    for name,rows in [('运输架次',trips),('逐箱交付',boxes),('电池占用',batteries),('航段明细',legs),('独立复核',checks)]:f.write_csv(path.parent/f'Q2_{name}.csv',rows)
    (path.parent/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    (path.parent/'workbook_data.json').write_text(json.dumps(dict(summary=summary,trips=trips,boxes=boxes,batteries=batteries,legs=legs,checks=checks),ensure_ascii=False),encoding='utf8');print('VERIFIED',path.parent.name,summary['makespan'],summary['transport_energy'],late,len(checks),flush=True)
    return summary

def main():
    w=World()
    for p in sorted(OUT.glob('*/best.json')):validate_candidate(p,w)

if __name__=='__main__':main()
